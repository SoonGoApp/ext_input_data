""" Collaborators

Defines columns used across to characterize collaborators
"""
from data_models.base import BaseModel, DataColumn

from utils.type import (
    convert_string, convert_date, convert_boolean
)


class CollaboratorsModel(BaseModel):
    collaborator_id: DataColumn = DataColumn(
        raw_name='collaborator_id',
        dtype='string',
        name='collaborator_id',
        description='SoonGo db uuid identifying the organization employee',
    )
    employee_id: DataColumn = DataColumn(
        raw_name='employee_id',
        dtype='string',
        name='employee_id',
        description='SoonGo generated customer organization employee id'
    )
    employee_entry_date = DataColumn(
        raw_name='Date ancienneté groupe ',
        name='employee_entry_date',
        dtype='datetime64[ns]',
    )
    employee_exit_date = DataColumn(
        raw_name='Date sortie physique ',
        name='employee_exit_date',
        dtype='datetime64[ns]',
    )
    alternative_names: DataColumn = DataColumn(
        raw_name='alternative_names',
        dtype='string',
        name='alternative_names',
        description='Comma separated alternative names sets'
    )
    employee_last_name: DataColumn = DataColumn(
        raw_name='Nom',
        dtype='string',
        post_processing=convert_string,
        name='employee_last_name',
    )
    employee_first_name: DataColumn = DataColumn(
        raw_name='Prénom',
        dtype='string',
        post_processing=convert_string,
        name='employee_first_name',
    )
    employee_full_name: DataColumn = DataColumn(
        raw_name='Collaborateur',
        dtype='string',
        name='employee_full_name',
    )
    work_location: DataColumn = DataColumn(
        raw_name='Site de rattachement',
        dtype='string',
        post_processing=convert_string,
        name='work_location',
    )
    organization_employee_id: DataColumn = DataColumn(
        raw_name='Matricule',
        dtype='string',
        post_processing=convert_string,
        name='organization_employee_id',
    )
    employee_role: DataColumn = DataColumn(
        raw_name="Fonction actuelle",
        dtype='string',
        post_processing=convert_string,
        name='employee_role',
    )
    employee_internal_category = DataColumn(
        raw_name="Catégorie interne (Collaborateur)",
        dtype='Int64',
        name='organization_employee_category',  # Distinguish from SoonGo's
    )
    employee_category_name = DataColumn(
        raw_name="Catégorie > Libellé",
        dtype='string',
        name='employee_category_name',  # Distinguish from SoonGo's
    )
    employee_title: DataColumn = DataColumn(
        raw_name="Civilité conducteur",
        dtype='string',
        post_processing=convert_string,
        name='employee_title',
    )
    employee_entity: DataColumn = DataColumn(
        raw_name='Entité Collaborateur',
        dtype='string',
        post_processing=convert_string,
        name='employee_entity',
    )
    employee_address: DataColumn = DataColumn(
        raw_name='Collaborateur : Adresse (ligne 1)',
        dtype='string',
        name='employee_address',
    )
    employee_postal_code: DataColumn = DataColumn(
        raw_name='Collaborateur : Code Postal',
        dtype='Int64',
        name='employee_postal_code',
    )
    employee_city: DataColumn = DataColumn(
        raw_name='Collaborateur : Ville',
        dtype='string',
        name='employee_city',
    )
    employee_country: DataColumn = DataColumn(
        raw_name='Collaborateur : Pays',
        dtype='string',
        name='employee_country',
    )
    employee_avg_monthly_mileage = DataColumn(
        raw_name="Moyenne kilométrique du collaborateur (Km (s) par mois)",
        dtype="Int64",
        name='employee_avg_monthly_mileage',
    )
    is_validated_driving_license = DataColumn(
        raw_name='Collaborateur : Permis attesté valide',
        dtype="boolean",
        name='is_validated_driving_license',
        post_processing=convert_boolean,
    )
    employee_email = DataColumn(
        raw_name='Collaborateur : Email',
        dtype='string',
        name='employee_email',
    )
    driving_licence_validation_date = DataColumn(
        raw_name='Collaborateur : Permis attesté le',
        dtype='datetime64[ns]',
        name='driving_licence_validation_date',
        post_processing=lambda x: convert_date(x, date_format=r'%d/%m/%Y'),
    )
    driving_licence_number = DataColumn(
        raw_name='Numéro de permis',
        dtype='string',
        post_processing=convert_string,
        name='driving_licence_number',
    )
    licence_issuance_date: DataColumn = DataColumn(
        raw_name="Collaborateur : Délivré le",
        dtype="datetime64[ns]",
        name="licence_issuance_date",
        post_processing=lambda x: convert_date(x, date_format=r'%d/%m/%Y'),
    )
