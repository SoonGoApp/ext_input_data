""" ClaimsModel

Defines columns used across all fleet connectors datasets
"""
from data_models.base import BaseModel, DataColumn

from utils.enums import (
    ExpenseStatus, ExpenseType, mapper_factory
)
from utils.type import (
    convert_date
)


class ClaimsModel(BaseModel):
    approbation_status: DataColumn = DataColumn(
        raw_name="Statut de l'approbation",
        dtype='string',
        post_processing=mapper_factory(ExpenseStatus),
        name='approbation_status'
    )
    claim_name: DataColumn = DataColumn(
        raw_name="Nom de la note de frais",
        dtype='string',
        name='claim_name'
    )
    claim_ref: DataColumn = DataColumn(
        raw_name="Identifiant de la note de frais",
        dtype='string',
        name='claim_ref'
    )
    expense_date: DataColumn = DataColumn(
        raw_name="Date de la transaction",
        dtype='datetime64[ns]',
        name='expense_date'
    )
    currency: DataColumn = DataColumn(
        raw_name="Devise du reporting",
        dtype='string',
        name='currency'
    )
    expense_type: DataColumn = DataColumn(
        raw_name="Type de frais",
        dtype='string',
        name='expense_type',
        post_processing=mapper_factory(ExpenseType)
    )
    professional_mileage: DataColumn = DataColumn(
        'Distance professionnelle',
        dtype='Int64',
        name='professional_mileage'
    )
    reimbursed_amount: DataColumn = DataColumn(
        'Montant remboursé',
        dtype='float64',
        name='reimbursed_amount'
    )
    submission_date: DataColumn = DataColumn(
        raw_name='Date de première soumission',
        dtype='datetime64[ns]',
        post_processing=convert_date,
        name='submission_date'
    )
    amount_tax_exc: DataColumn = DataColumn(
        raw_name='Montant HT',
        dtype='float64',
        name='amount_tax_exc',
    )
    amount_tax_inc: DataColumn = DataColumn(
        raw_name='Montant TTC',
        dtype='float64',
        name='amount_tax_inc',
    )
    net_amount = DataColumn(
        raw_name='net_amount',
        dtype='float64',
        name='net_amount',
        description='Amount, all taxes included, deductible VAT deducted.'
    )
    payment_date = DataColumn(
        raw_name="Date d'envoi pour paiement",
        dtype='datetime64[ns]',
        post_processing=convert_date,
        name='payment_date'
    )
    deductible_vat = DataColumn(
        raw_name='deductible_vat',
        dtype='float64',
        name='deductible_vat',
        description='Amount of deductible VAT.'
    )
