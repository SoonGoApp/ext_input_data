""" SoonGoRecordModel

Defines columns used across all Gac datasets
"""
from data_models.base import BaseModel, DataColumn

from utils.type import convert_date, convert_string
from utils.enums import mapper_factory, SynchronizationTypes


class SoonGoRecordsModel(BaseModel):
    organization_id: DataColumn = DataColumn(
        raw_name='organization_id',
        dtype='string',
        name='organization_id',
        description='SoonGo database uuid associated with the organization',
    )
    record_date: DataColumn = DataColumn(
        raw_name='record_date',
        dtype='datetime64[ns]',
        name='record_date',
        description='Minimum date at which the row was recorded'
    )
    source_dataset: DataColumn = DataColumn(
        raw_name='source_dataset',
        dtype='string',
        name='source_dataset',
        description='Dataset name the data was sourced from'
    )
    source_connector: DataColumn = DataColumn(
        raw_name='source_connector',
        dtype='string',
        name='source_connector',
        description='Name of the connector the data was sourced from'
    )
    source_table: DataColumn = DataColumn(
        raw_name='source_table',
        dtype='string',
        name='source_table',
        description='Name of the table the data was sourced from'
    )
    document_date: DataColumn = DataColumn(
        raw_name='Date pièce',
        dtype='datetime64[ns]',
        name='document_date',
        post_processing=convert_date,
    )
    synchronisation_id: DataColumn = DataColumn(
        raw_name='synchronisation_id',
        dtype='string',
        name='synchronisation_id',
        description='Synchronisation uuid, unique per connector',
    )
    synchronisation_type: DataColumn = DataColumn(
        raw_name='synchronisation_type',
        dtype='string',
        name='synchronisation_type',
        post_processing=mapper_factory(SynchronizationTypes),
        description='Synchronisation type see SynchronizationTypes enum',
    )
    ext_api_id: DataColumn = DataColumn(
        raw_name='ext_api_id',
        name='ext_api_id',
        dtype='string',
        post_processing=convert_string,
        description='External API id used to retrieve the data',
    )
