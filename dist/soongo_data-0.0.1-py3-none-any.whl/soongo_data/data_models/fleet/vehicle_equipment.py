""" BusinessUnitsModel

Defines columns used across all fleet connectors datasets
"""
from data_models.base import BaseModel, DataColumn

from utils.type import (
    convert_string, convert_date
)


class VehicleEquipmentsModel(BaseModel):
    equipment_ref: DataColumn = DataColumn(
        raw_name="Carte / Equipement",
        dtype='string',
        post_processing=convert_string,
        name='equipment_ref'
    )
    equipment_family = DataColumn(
        raw_name="Famille d'équipement",
        dtype='string',
        post_processing=convert_string,
        name='equipment_family'
    )
    equipment_type = DataColumn(
        raw_name="Type d'équipement",
        dtype='string',
        post_processing=convert_string,
        name='equipment_type'
    )
    equipment_name = DataColumn(
        raw_name="Libellé",
        dtype='string',
        post_processing=convert_string,
        name='equipment_name'
    )
    internal_reference = DataColumn(
        raw_name="Référence interne",
        dtype='string',
        post_processing=convert_string,
        name='internal_reference'
    )
    equipment_status = DataColumn(
        raw_name='Statut',
        dtype='string',
        post_processing=convert_string,
        name='equipement_status'
    )
    equipment_status_date = DataColumn(
        raw_name="Date d'effet",
        dtype='string',
        post_processing=convert_string,
        name='equipement_status_date',
    )
    supplier_reference = DataColumn(
        raw_name='Référence fournisseur',
        dtype='string',
        post_processing=convert_string,
        name='supplier_reference'
    )
    equipment_start_date = DataColumn(
        raw_name='Date de début',
        dtype='datetime64[ns]',
        post_processing=convert_date,
        name='equipment_start_date',
    )
    equipment_end_date = DataColumn(
        raw_name='Date de fin',
        dtype='datetime64[ns]',
        post_processing=convert_date,
        name='equipment_end_date',
    )
    comment_1: DataColumn = DataColumn(
        raw_name='Commentaire (Equipement)',
        dtype='string',
        post_processing=convert_string,
        name='comment_1',
    )
    comment_2: DataColumn = DataColumn(
        raw_name='Mention supplémentaire',
        dtype='string',
        post_processing=convert_string,
        name='comment_2',
    )
    comment_3: DataColumn = DataColumn(
        raw_name='Mention Complémentaire',
        dtype='string',
        post_processing=convert_string,
        name='comment_3',
    )
    equipment_supplier = DataColumn(
        raw_name='Fournisseur',
        dtype='string',
        post_processing=convert_string,
        name='equipment_supplier',
    )
