
""" FuelCards

Defines columns used across all Gac datasets
"""
from data_models.base import BaseModel, DataColumn

from utils.enums import (
     mapper_factory, FuelTypes, GazStationType
)
from utils.type import (
    convert_string, convert_date, convert_boolean
)


class FuelCardsModel(BaseModel):
    gaz_station = DataColumn(
        raw_name="Site : Libellé",
        name="gaz_station",
        dtype='string',
    )
    gaz_station_ref = DataColumn(
        raw_name="Site : Code site",
        name="gaz_station_ref",
        dtype='string',
        post_processing=convert_string,
    )
    fuel_card_supplier: DataColumn = DataColumn(
        raw_name='Fournisseur de carte carburant',
        dtype='string',
        post_processing=convert_string,
        name='fuel_card_supplier',
    )
    fuel_card_ref: DataColumn = DataColumn(
        raw_name='Référence de la carte',
        dtype='string',
        post_processing=convert_string,
        name='fuel_card_ref',
    )
    ticket_number: DataColumn = DataColumn(
        raw_name='N° Ticket',
        dtype='string',
        post_processing=convert_string,
        name='ticket_number',
    )
    fuel_card_product: DataColumn = DataColumn(
        raw_name='Produit de la carte',
        dtype='string',
        post_processing=convert_string,
        name='fuel_card_product',
    )
    fuel_type: DataColumn = DataColumn(
        raw_name='Produit',
        dtype='string',
        name='fuel_type',
        post_processing=mapper_factory(FuelTypes)
    )
    secret_code_type = DataColumn(
        raw_name='Type de code confidentiel',
        dtype='string',
        post_processing=convert_string,
        name='secret_code_type',
    )
    secret_code = DataColumn(
        raw_name='Code confidentiel',
        dtype="Int64",
        name='secret_code',
    )
    driver_code = DataColumn(
        raw_name='Code chauffeur',
        dtype='string',
        post_processing=convert_string,
        name='driver_code',
    )
    fuel_card_status_date = DataColumn(
        raw_name="Date d'effet",
        dtype='datetime64[ns]',
        post_processing=convert_date,
        name='fuel_card_status_date',
    )
    fuel_card_status = DataColumn(
        raw_name='Statut',
        dtype='string',
        post_processing=convert_string,
        name='fuel_card_status',
    )
    creation_date: DataColumn = DataColumn(
        raw_name="Création du support",
        dtype='datetime64[ns]',
        post_processing=convert_date,
        name='creation_date',
    )
    update_date: DataColumn = DataColumn(
        raw_name='Date de màj',
        dtype='datetime64[ns]',
        post_processing=convert_date,
        name='update_date',
    )
    fuel_card_provider: DataColumn = DataColumn(
        raw_name='Enseigne',
        dtype='string',
        post_processing=convert_string,
        name='fuel_card_provider',
    )
    fuel_card_type: DataColumn = DataColumn(
        raw_name='Carte : Type de carte',
        dtype='string',
        post_processing=convert_string,
        name='fuel_card_type',
    )
    fuel_card_end_date: DataColumn = DataColumn(
        raw_name='Carte : Date de validité',
        dtype='string',
        post_processing=lambda x: convert_date(
            convert_string(x) + '-01',
            date_format=r'%m-%y-%d'
        ),
        name='fuel_card_end_date',
    )
    gaz_station_type: DataColumn = DataColumn(
        raw_name='Site : Type du site',
        dtype='string',
        post_processing=mapper_factory(GazStationType),
        name='gaz_station_type',
    )
    was_approved: DataColumn = DataColumn(
        raw_name='Code réponse',
        dtype='string',
        post_processing=lambda x: convert_boolean(
            x,
            pos_value="acceptée",
            neg_value="refusée",
        ),
        name='was_approved',
    )
    approval_type: DataColumn = DataColumn(
        raw_name="Motif d'autorisation",
        dtype='string',
        post_processing=convert_string,
        name='approval_type',
    )
