""" VehicleMaintenanceModel

Defines columns used across all fleet connectors datasets
"""
from data_models.base import BaseModel, DataColumn

from utils.type import (
    convert_string, convert_date, convert_numeric
)


class VehicleMaintenanceModel(BaseModel):
    maintenance_type = DataColumn(
        raw_name='Type',
        dtype='string',
        post_processing=convert_string,
        name='maintenance_type',
    )
    intervention_number = DataColumn(
        raw_name="N° d'intervention",
        dtype='Int64',
        name='intervention_number'
    )
    target_date = DataColumn(
        raw_name='Date cible',
        dtype='datetime64[ns]',
        post_processing=convert_date,
        name='target_date',
    )
    target_mileage = DataColumn(
        raw_name='km cible',
        dtype='float64',
        post_processing=convert_numeric,
        name='target_mileage',
    )
    maintenance_date = DataColumn(
        raw_name='Réalisé le',
        dtype='datetime64[ns]',
        post_processing=convert_date,
        name='maintenance_date',
    )
    maintenance_mileage = DataColumn(
        raw_name='Réalisé à',
        dtype='Int64',
        name='maintenance_mileage',
        post_processing=convert_numeric,
    )
    periodicity = DataColumn(
        raw_name='Périodicité',
        dtype='string',
        post_processing=convert_string,
        name='periodicity',
    )
    maintenance_status = DataColumn(
        raw_name='Statut',
        dtype='string',
        post_processing=convert_string,
        name='maintenance_status',
    )
    operation_description = DataColumn(
        raw_name='Description',
        dtype='string',
        post_processing=convert_string,
        name='operation_description'
    )
    maintenance_supplier = DataColumn(
        raw_name='Fournisseur',
        dtype='string',
        post_processing=convert_string,
        name='maintenance_supplier',
    )
