""" ExpenseModels

Defines columns used across all fleet connectors datasets
"""
import pandas as pd

from data_models.base import BaseModel, DataColumn
from utils.enums import (
    CostCategory, mapper_factory, BillType
)
from utils.type import (
    convert_date, convert_numeric, convert_string, convert_boolean
)


def convert_dot_decimal_number(series: pd.Series) -> pd.Series:
    return convert_numeric(series, decimal='.')


class ExpensesModel(BaseModel):
    expense_reference: DataColumn = DataColumn(
        raw_name='Référence GAC',
        dtype='string',
        post_processing=convert_string,
        name='expense_reference',
    )
    billing_date: DataColumn = DataColumn(
        raw_name='Facturation',
        dtype='datetime64[ns]',
        post_processing=convert_date,
        name='billing_date',
    )
    purchase_date: DataColumn = DataColumn(
        raw_name="Date d'achat",
        dtype='datetime64[ns]',
        post_processing=convert_date,
        name='purchase_date',
    )
    amount_tax_exc: DataColumn = DataColumn(
        raw_name='Montant HT',
        dtype='float64',
        name='amount_tax_exc',
    )
    amount_tax_inc: DataColumn = DataColumn(
        raw_name='Montant TTC',
        dtype='float64',
        name='amount_tax_inc',
    )
    net_amount = DataColumn(
        raw_name='net_amount',
        dtype='float64',
        name='net_amount',
        description='Amount, all taxes included, deductible VAT deducted.'
    )
    deductible_vat_rate = DataColumn(
        raw_name='TVA déductible (%)',
        dtype="Int64",
        name='deductible_vat_rate'
    )
    deductible_vat = DataColumn(
        raw_name='deductible_vat',
        dtype='float64',
        name='deductible_vat',
        description='Amount of deductible VAT.'
    )
    vat_amount = DataColumn(
        raw_name='Montant TVA',
        dtype='float64',
        name='vat_amount'
    )
    vat_rate = DataColumn(
        raw_name='Taux TVA (%)',
        dtype='float64',
        post_processing=convert_dot_decimal_number,
        name='vat_rate'
    )
    amount_tax_exc_loc: DataColumn = DataColumn(
        raw_name='Montant HT monnaie locale',
        dtype='float64',
        name='amount_tax_exc_loc',
    )
    amount_tax_inc_loc: DataColumn = DataColumn(
        raw_name='Montant TTC monnaie locale',
        dtype='float64',
        name='amount_tax_inc_loc',
    )
    discount_rate = DataColumn(
        raw_name='Taux de remise',
        dtype='float64',
        name='discount_rate',
    )
    discount_value = DataColumn(
        raw_name='Montant remisé',
        dtype='float64',
        name='discount_value',
    )
    amount_final: DataColumn = DataColumn(
        raw_name='Montant NET',
        dtype='float64',
        name='amount_final',
    )
    category_1: DataColumn = DataColumn(
        raw_name='Catégorie 1',
        dtype='string',
        post_processing=convert_string,
        name='category_1',
    )
    category_2: DataColumn = DataColumn(
        raw_name='Catégorie 2',
        dtype='string',
        post_processing=convert_string,
        name='category_2',
    )
    category_3: DataColumn = DataColumn(
        raw_name='Catégorie 3',
        dtype='string',
        post_processing=convert_string,
        name='category_3',
    )
    product: DataColumn = DataColumn(
        raw_name='Produit',
        dtype='string',
        post_processing=convert_string,
        name='product',
    )
    product_ref: DataColumn = DataColumn(
        raw_name='Code produit',
        dtype='string',
        post_processing=convert_string,
        name='product_ref',
    )
    spent_tag: DataColumn = DataColumn(
        raw_name='Étiquette de dépense',
        dtype='string',
        post_processing=convert_string,
        name='spent_tag',
    )
    source: DataColumn = DataColumn(
        raw_name='Source / Origine',
        dtype='string',
        post_processing=convert_string,
        name='source',
    )
    organization_employee_id: DataColumn = DataColumn(
        raw_name='Matricule',
        dtype='Int64',
        post_processing=convert_numeric,
        name='organization_employee_id',
    )
    expense_category: DataColumn = DataColumn(
        raw_name='expense_category',
        dtype='string',
        name='expense_category',
        description=(
            'SoonGo category; categories correspond to a ExpenseCategory'
        ),
        post_processing=mapper_factory(CostCategory)
    )
    unit_price: DataColumn = DataColumn(
        raw_name="Prix unitaire",
        name="unit_price",
        dtype="float64",
    )
    quantity: DataColumn = DataColumn(
        raw_name="Quantité",
        name="quantity",
        dtype="float64",
    )
    expense_description: DataColumn = DataColumn(
        raw_name='Description',
        dtype='string',
        post_processing=convert_string,
        name='expense_description'
    )
    billing_ref: DataColumn = DataColumn(
        raw_name='Numéro de facture',
        dtype='string',
        post_processing=convert_string,
        name='billing_ref',
    )
    billing_account: DataColumn = DataColumn(
        raw_name='Compte facturé',
        dtype="Int64",
        name='billing_account',
    )
    expense_location: DataColumn = DataColumn(
        raw_name='Lieu',
        dtype='string',
        post_processing=convert_string,
        name='expense_location',
    )
    expense_department_code: DataColumn = DataColumn(
        raw_name='Département',
        dtype='string',
        name='expense_department_code',
        post_processing=convert_string,
    )
    expense_country: DataColumn = DataColumn(
        raw_name='Pays de la transaction',
        dtype='string',
        name='expense_country',
        post_processing=convert_string,
    )
    supplier: DataColumn = DataColumn(
        raw_name='Fournisseur',
        dtype='string',
        post_processing=convert_string,
        name='supplier',
    )
    billing_start_date: DataColumn = DataColumn(
        raw_name='Facture > Début de période',
        name='billing_start_date',
        dtype='datetime64[ns]',
    )
    billing_end_date: DataColumn = DataColumn(
        raw_name='Facture > Fin de période',
        name='billing_end_date',
        dtype='datetime64[ns]',
    )
    currency: DataColumn = DataColumn(
        raw_name="Devise du reporting",
        dtype='string',
        name='currency'
    )
    billing_type: DataColumn = DataColumn(
        raw_name='Facture > Type',
        dtype='string',
        name='billing_type',
        post_processing=mapper_factory(BillType),
    )
    is_anomalous: DataColumn = DataColumn(
        raw_name="Facture > Présence d'anomalie",
        dtype='boolean',
        name='is_anomalous',
        post_processing=convert_boolean,
    )
    anomaly_description: DataColumn = DataColumn(
        raw_name="Anomalie(s)",
        dtype='string',
        name='anomaly_description',
        post_processing=convert_string,
    )
