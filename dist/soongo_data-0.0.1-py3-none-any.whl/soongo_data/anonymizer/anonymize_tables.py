""" Anonymizer - generate anonymized data from actual tables
"""
import argparse
import logging
import os
import random
import typing

import pandas as pd
import numpy as np

from data_models import (
    TrainPlaneTravelModel, CollaboratorsModel, VehiclesModel,
    BusinessUnitsModel, ExpensesModel, VehicleAssociationsModel
)
from utils.logging import gen_logger


class Anonymizer:

    def __init__(
        self: typing.Self,
        name_lexicon: list,
        logger: logging.Logger,
        seed: int = 13,
    ):
        random.seed(seed)
        self.logger = logger
        self.name_substitution_dict = dict()
        self.combined_substitution_dict = self.gen_combined_substitution_dict(
            self.gen_letter_substitution_dict(),
            self.gen_number_substitution_dict(),
        )
        self.name_lexicon = name_lexicon
        random.shuffle(self.name_lexicon)
        np.random.seed(seed)

    def anonymize_folder(
        self: typing.Self,
        folder_to_anon: str,
        output_folder: str,
    ) -> None:
        """ Anonymize target folder

        :param folder_to_anon: path to a folder to anonymize
        :param output_folder: path to a folder to store the anonymized tables
        """
        folder_to_anon = os.path.expanduser(folder_to_anon)
        if not os.path.isdir(folder_to_anon):
            raise FileNotFoundError(
                f'Provided folder {folder_to_anon} does not exist'
            )

        output_folder = os.path.expanduser(output_folder)
        if not os.path.isdir(os.path.dirname(output_folder)):
            raise FileNotFoundError(
                f'The provided output_folder {output_folder} does not point'
                f' to a valid directory'
            )

        if not os.path.isdir(output_folder):
            os.mkdir(output_folder)

        tables_to_anon = [
            file for file in os.listdir(folder_to_anon)
            if file.endswith(r'csv')
        ]
        if not tables_to_anon:
            raise FileNotFoundError(
                'There are no csv table in the provided folder '
                f'{folder_to_anon}'
            )

        for table in tables_to_anon:
            input_path = os.path.join(folder_to_anon, table)
            self.logger.info(
                'Fetching data from table %s',
                input_path,
            )
            input_table = pd.read_csv(
                input_path,
                sep=';',
            )
            anon_table = self.anonymize_table(table=input_table)
            output_path = os.path.join(output_folder, table)
            anon_table.to_csv(
               output_path,
               sep=';',
               index=False,
            )
            self.logger.info(
                'Saved anonymized table under %s',
                output_path,
            )

    def anonymize_table(
        self: typing.Self,
        table: pd.DataFrame,
    ) -> pd.DataFrame:
        """ Anonymize table

        :param table: pandas DataFrame to anonymize
        """
        personal_cols = {
            CollaboratorsModel.employee_first_name.name,
            CollaboratorsModel.employee_last_name.name,
            CollaboratorsModel.employee_full_name.name,
            VehiclesModel.plate_number.name,
            CollaboratorsModel.employee_id.name,
            BusinessUnitsModel.business_unit.name,
            CollaboratorsModel.alternative_names.name,
            TrainPlaneTravelModel.approver.name,
        }
        cols_to_anonymize = personal_cols.intersection(table.columns)
        self.logger.info(
            'Anonymizing columns %s',
            cols_to_anonymize,
        )

        if VehiclesModel.plate_number.name in table.columns:
            cols_to_anonymize.remove(VehiclesModel.plate_number.name)
            table[VehiclesModel.plate_number.name] = self.anonymize_plate(
                table[VehiclesModel.plate_number.name]
            )

        if BusinessUnitsModel.business_unit.name in table.columns:
            cols_to_anonymize.remove(BusinessUnitsModel.business_unit.name)
            table[BusinessUnitsModel.business_unit.name] = self.anonymize_bu(
                table[BusinessUnitsModel.business_unit.name]
            )

        for name_col in cols_to_anonymize:
            table[name_col] = self.anonymize_name(table[name_col])

        amount_cols = {
            ExpensesModel.amount_tax_exc.name,
            ExpensesModel.deductible_vat.name,
            ExpensesModel.net_amount.name,
            ExpensesModel.rebate_price_ttc.name,
            VehicleAssociationsModel.daily_participation.name,
        }
        cols_to_anonymize = amount_cols.intersection(table.columns)
        self.logger.info(
            'Introducing noise in columns %s value',
            cols_to_anonymize,
        )
        for name_col in cols_to_anonymize:
            table[name_col] = table[name_col] * (
                np.random.randint(90, 110) / 100
            )

        return table

    def anonymize_name(
        self: typing.Self,
        name_col: pd.Series,
    ) -> pd.Series:
        """ Anonymize names using a lexicon, updating substitution dict to
        record substitutions

        :param name_col: Series of individual names
        :param name_lexicon: list of names to substitute with
        :param substitution_dict: dictionary of names to substitute

        :returns: new series with anonymized names, and updates substitution
        """
        # Identify unique names in name_col
        name_df = name_col.str.split(expand=True)
        name_set = set()
        for col in name_df:
            name_set.update(name_df[col].str.lower())

        # Enrich subsitution_dict if necessary
        for new_name in name_set.difference(self.name_substitution_dict):
            if new_name not in ('', None):
                self.name_substitution_dict[new_name] = self.name_lexicon.pop()

        # Update names
        new_name_df = name_df.map(
            lambda x: self.name_substitution_dict.get(
                x.lower() if isinstance(x, str) else x
            )
        ).fillna('')
        for col in new_name_df.columns:
            new_name_df[col] = new_name_df[col].str.strip()
        return new_name_df.agg(' '.join, axis=1)

    def anonymize_plate(
        self,
        plate_col: pd.Series,
    ) -> pd.Series:
        """ Plate number anonymizer

        :param plate_col: Series of plate number
        :param substitution_dict: dictionary of plate_number to substitute

        :returns: substituted plate numbers
        """
        return plate_col.str.lower().str.translate(
            str.maketrans(self.combined_substitution_dict)
        ).str.upper()

    def anonymize_bu(
        self,
        bu_col: pd.Series,
    ) -> pd.Series:
        """ Business units anonymizer

        :param bu_col: Series of business units
        :param substitution_dict: dictionary of plate_number to substitute

        :returns: substituted plate numbers
        """
        bu_dict = {
            'QUARTUS': 'Ouléa',
            'Atrium': 'Maraxa',
            'Via Terra': 'Nymerius',
            'Residentiel': 'Core',
            'Ensemblier urbain': 'Growth',
            'QR Direction': 'ONM Direction',
            'DG QR': 'DG ONM',
        }
        for original_bu, repl_bu in bu_dict.items():
            bu_col = bu_col.str.replace(
                original_bu,
                repl_bu,
                case=False,
                regex=True,
            )

        return bu_col

    @staticmethod
    def gen_letter_substitution_dict():
        letters = 'azertyuiopqsdfghjklmwxcvbn'
        letters_to_substitute = list(letters)
        random.shuffle(letters_to_substitute)
        return dict(zip(letters, letters_to_substitute))

    @staticmethod
    def gen_number_substitution_dict():
        numbers = '0123456789'
        numbers_to_substitute = list(numbers)
        random.shuffle(numbers_to_substitute)
        return dict(zip(numbers, numbers_to_substitute))

    @staticmethod
    def gen_combined_substitution_dict(letter_dict, number_dict) -> dict:
        combined_dict = letter_dict
        combined_dict.update(
            number_dict
        )
        combined_dict['-'] = '-'
        return combined_dict


def extract_name_set(lexicon_path: str) -> list:
    """ Extract name set from lexicon path"""
    lexicon_table = pd.read_csv(lexicon_path, sep=";")
    name_set = list(lexicon_table['preusuel'].unique())
    name_set.remove('_PRENOMS_RARES')
    return name_set


def parse_args():
    """ Parse arguments passed to the Anonymizer
    """
    parser = argparse.ArgumentParser(
        description='Anonymize tables in a folder.'
    )

    parser.add_argument(
        '-t',
        '--target',
        type=str,
        help='Path to the folder containing tables to anonymize.',
    )
    parser.add_argument(
        '-o',
        '--output',
        type=str,
        help='Path to the folder where to store the anonymized tables.',
    )
    parser.add_argument(
        '-n',
        '--name_lexicon',
        type=str,
        default='~/Documents/Data/Other/nat2022.csv',
        required=False,
        help='Path to fetch a name lexicon',
    )
    parser.add_argument(
        '-s',
        '--seed',
        type=int,
        default=13,
        required=False,
        help='Random seed for anonymization. Default is 13.',
    )

    args = parser.parse_args()
    return args


if __name__ == '__main__':
    args = parse_args()
    logger = gen_logger('anonymizer')
    anonymizer = Anonymizer(
        name_lexicon=extract_name_set(args.name_lexicon),
        logger=logger,
        seed=args.seed,
    )
    anonymizer.anonymize_folder(
        folder_to_anon=args.target,
        output_folder=args.output,
    )
