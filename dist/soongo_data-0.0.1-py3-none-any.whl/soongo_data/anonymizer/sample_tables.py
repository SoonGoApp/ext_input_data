""" Sampler - generate synthetic data from actual tables
"""
import argparse
import logging
import os
import random
import typing
import yaml
import dataclasses
import uuid

import pandas as pd

from data_models import VehiclesModel, CollaboratorsModel
from input_tables.accident_table import ACCIDENT_TABLE
from input_tables.employees_table import EMPLOYEE_TABLE
from input_tables.expense_claims import EXPENSE_CLAIMS_TABLE
from input_tables.expense_table import EXPENSE_TABLE
from input_tables.hotels_table import HOTELS_TABLE
from input_tables.mileage_table import MILEAGE_TABLE
from input_tables.rental_cars import RENTAL_CARS_TABLE
from input_tables.taxes_table import TAXES_TABLE
from input_tables.train_plane import TRAIN_PLANES_TABLE
from input_tables.vehicle_associations import ASSOCIATIONS_TABLE
from input_tables.vehicles_table import VEHICLES_TABLE
from input_tables.table_utils import InputTable
from utils.logging import gen_logger
from utils.type import str_is_nan, convert_date


TABLE_LST = [
    ACCIDENT_TABLE,
    EMPLOYEE_TABLE,
    EXPENSE_CLAIMS_TABLE,
    EXPENSE_TABLE,
    HOTELS_TABLE,
    MILEAGE_TABLE,
    RENTAL_CARS_TABLE,
    TAXES_TABLE,
    TRAIN_PLANES_TABLE,
    ASSOCIATIONS_TABLE,
    VEHICLES_TABLE,
]


@dataclasses.dataclass
class InputTables:

    def __init__(self: typing.Self, folder_path: str) -> typing.Self:
        self.folder_path = folder_path

        for table in TABLE_LST:

            table_df = pd.read_csv(
                    os.path.join(
                        folder_path,
                        table.name + '_table.csv',
                    ),
                    sep=';',
                    index_col=False,
                )

            col_lst = [
                col for col in table.columns if col.name in table_df.columns
            ]
            for col in col_lst:

                if pd.api.types.is_datetime64_any_dtype(col.dtype):
                    table_df[col.name] = convert_date(table_df[col.name])

                table_df[col.name] = table_df[col.name].astype(col.dtype)

            setattr(
                self,
                table.name,
                table_df,
            )

    def get(self: typing.Self, table_name: str):
        return getattr(self, table_name)

    def __iter__(self):
        for table in TABLE_LST:
            yield table.name, self.get(table.name)


class Sampler:
    TABLE_NAMES = [table.name for table in TABLE_LST]
    ANON_PLATE_COL = 'anon_plate_number'
    ANON_EMPLOYEE_COL = 'anon_employee_col'
    LETTERS = tuple('azertyuiopqsdfghjklmwxcvbn')
    NUMBERS = tuple('0123456789')
    UNIQUE_CONSTRAINTS = {
        'expenses': ['expense_reference'],
    }

    def __init__(
        self,
        logger: logging.Logger,
        input_tables: InputTables,
        name_lexicon: str,
        config: dict,
        seed: int = 13,
    ):
        """ Selects plates to sample to generate additional cars

        :param config_path: str path to the sampling config
        :param input_tables: InputTable object with all data
        """
        self.sample_params = config['sampling']
        self.input_tables = input_tables
        self.plate_lst = self.input_tables.get(
            VEHICLES_TABLE.name
        )[VehiclesModel.plate_number.name].unique().tolist()
        self.employee_lst = self.input_tables.get(
            EMPLOYEE_TABLE.name
        )[CollaboratorsModel.plate_number.name].unique().tolist()
        self.logger = logger
        self.sampled_associations = []
        self.seed = seed
        self.name_lexicon = self.extract_name_set(name_lexicon)
        self.choice_set = self.gen_choice_set()
        self.pick_associations()

    def pick_associations(self):
        sample_count = 0
        for sample in self.sample_params:
            logger.info(
                'Sampling associations for sampling %s',
                sample_count,
            )
            eligible_vehicles = self.return_eligible_plate_numbers(
                condition_lst=sample.get('conditions', [])
            )

            eligible_associations = self.input_tables.get(
                ASSOCIATIONS_TABLE.name
            )
            eligible_associations = eligible_associations.loc[
                eligible_associations[VehiclesModel.plate_number.name].isin(
                    eligible_vehicles
                ),
                [
                    VehiclesModel.plate_number.name,
                    CollaboratorsModel.plate_number.name,
                ]
            ].drop_duplicates()
            sampled_associations = eligible_associations.sample(
                    sample['nb_sampling'],
                    random_state=self.seed,
                    replace=True,
                )
            sampled_associations[self.ANON_PLATE_COL] = self.anonymize_plates(
                sampled_associations[VehiclesModel.plate_number.name]
            )
            assert sampled_associations[self.ANON_PLATE_COL].unique
            sampled_associations[self.ANON_EMPLOYEE_COL] = self.anonymize_name(
                sampled_associations[CollaboratorsModel.plate_number.name]
            )
            assert sampled_associations[self.ANON_EMPLOYEE_COL].unique
            assert len(sampled_associations) == sample['nb_sampling']
            self.sampled_associations.append(
                (sampled_associations, sample.get('changes', []))
            )
            sample_count += 1

    def anon_table(
        self,
        table: InputTable,
    ) -> pd.DataFrame:
        """ Over sample and anonymize table.

        Three scenarios: both plate and employee id non na, merge
        using both m:m, substitute plate_col and employee id by anon version
        plate_col only available, merge using plate_col only m:m
        employee only available, merge using employee_id only m:m

        :param table_df: input table to over sample and anonymize
        """
        table_df = self.input_tables.get(table.name)
        table_cols = list(table_df.columns)
        set_id_cols = {
            VehiclesModel.plate_number.name,
            CollaboratorsModel.plate_number.name
        }
        sampling_cols = set_id_cols.intersection(table_cols)
        mask = table_df.any(axis=1)
        for col in sampling_cols:
            mask = mask & ~str_is_nan(table_df[col])
        available_df = table_df.loc[mask, ]

        sample_lst = []
        for sampled_df, changes in self.sampled_associations:
            oversampled_df = available_df.merge(
                right=sampled_df,
                on=list(sampling_cols),
                how='inner',  # Selection
            )
            for change in changes:
                if table.name in change['table_name']:
                    change_col_name = change['column_name']
                    if change_col_name not in oversampled_df.columns:
                        raise ValueError(
                            f'Col {change_col_name} was passed but no such'
                            f'column on table {table.name}'
                        )
                    cat_choices = change.get('categorical_values')
                    if cat_choices:
                        oversampled_df[change_col_name] = (
                            oversampled_df[change_col_name].apply(
                                lambda x: random.choice(cat_choices)
                            )
                        )
                    else:
                        raise NotImplementedError(
                            'Other change options not yet implemented!'
                        )

            unique_constraints = self.UNIQUE_CONSTRAINTS.get(table.name, [])
            for constraint in unique_constraints:
                oversampled_df[constraint] = oversampled_df[constraint].apply(
                    lambda x: str(uuid.uuid4())
                )

            sample_lst.append(oversampled_df)

        both_available_sampled = pd.concat(
            sample_lst,
            axis=0,
        )

        if VehiclesModel.plate_number.name in both_available_sampled.columns:
            both_available_sampled[VehiclesModel.plate_number.name] = (
                both_available_sampled[self.ANON_PLATE_COL]
            )
        if (
            CollaboratorsModel.plate_number.name
            in both_available_sampled.columns
        ):
            both_available_sampled[CollaboratorsModel.plate_number.name] = (
                both_available_sampled[self.ANON_EMPLOYEE_COL]
            )

        return both_available_sampled[table_cols]

    def check_directories(self, output_folder):
        folder_to_anon = os.path.expanduser(self.input_tables.folder_path)
        if not os.path.isdir(folder_to_anon):
            raise FileNotFoundError(
                f'Provided folder {folder_to_anon} does not exist'
            )
        output_folder = os.path.expanduser(output_folder)
        if not os.path.isdir(os.path.dirname(output_folder)):
            raise FileNotFoundError(
                f'The provided output_folder {output_folder} does not point'
                f' to a valid directory'
            )
        if not os.path.isdir(output_folder):
            os.mkdir(output_folder)

    def anonymize_name(
        self: typing.Self,
        name_col: pd.Series,
    ) -> pd.Series:
        """ Anonymize names using a lexicon, updating substitution dict to
        record substitutions

        :param name_col: Series of individual names
        :param name_lexicon: list of names to substitute with
        :param substitution_dict: dictionary of names to substitute

        :returns: new series with anonymized names, and updates substitution
        """
        anon_name_col = name_col
        while anon_name_col.isin(self.employee_lst).any():
            # Identify unique names in name_col
            name_df = name_col.str.split(expand=True)

            # Update names
            new_name_df = name_df.map(
                lambda x: random.choice(self.name_lexicon)
            ).fillna('')
            for col in new_name_df.columns:
                new_name_df[col] = new_name_df[col].str.strip()

            anon_name_col = anon_name_col.mask(
                anon_name_col.isin(self.employee_lst),
                new_name_df.agg(' '.join, axis=1).str.strip()
            )

        return anon_name_col

    def anonymize_plates(
        self: typing.Self,
        plate_col: pd.Series,
    ) -> pd.Series:
        return plate_col.apply(self.anonymize_individual_plate)

    def anonymize_individual_plate(
        self,
        plate_col: str,
    ) -> str:
        """ Individual_plate_anonymizer

        :param plate_col: Series of plate number

        :returns: substituted plate numbers
        """
        anon_plate_col = plate_col
        while anon_plate_col in self.plate_lst:
            anon_plate_col = (
                ''.join(
                    random.choice(self.choice_set[charac])
                    for charac in plate_col.lower()
                )
            )

        return anon_plate_col

    def return_eligible_plate_numbers(self, condition_lst: list) -> pd.Series:
        """ Return eligible plate numbers

        :param condition_lst: list of conditions
        """
        if not condition_lst:
            return self.plate_lst

        table_names_set = {
            table for condition in condition_lst
            for table in condition['table_name']
        }
        if len(table_names_set) > 1:
            raise ValueError(
                f'No support for multi tables conditions and '
                f'{table_names_set} passed'
            )
        cond_table = table_names_set.pop()
        if cond_table not in self.TABLE_NAMES:
            raise ValueError(
                f'{cond_table} not in {self.TABLE_NAMES}'
            )
        table_df = self.input_tables.get(cond_table)
        if VehiclesModel.plate_number.name not in table_df.columns:
            raise ValueError(
                'The specified cond table must have a plate number col'
            )
        conds = ~str_is_nan(table_df[VehiclesModel.plate_number.name])
        for condition in condition_lst:
            cond_col = condition['column_name']
            if cond_col not in table_df.columns:
                raise ValueError(
                    f'The condition column name {cond_col} does not '
                    f'exist in table {cond_table}'
                )
            conds = conds & apply_conditions(
                col_series=table_df[cond_col],
                categorical_values=condition.get('categorical_values'),
                min_value=condition.get('min_value'),
                max_value=condition.get('max_value'),
            )

        return table_df.loc[
            conds,
            VehiclesModel.plate_number.name,
        ].unique().tolist()

    @staticmethod
    def extract_name_set(lexicon_path: str) -> list:
        """ Extract name set from lexicon path"""
        lexicon_table = pd.read_csv(lexicon_path, sep=";")
        name_set = list(lexicon_table['preusuel'].unique())
        name_set.remove('_PRENOMS_RARES')
        return name_set

    @classmethod
    def gen_choice_set(cls):
        choice_set = {letter: cls.LETTERS for letter in cls.LETTERS}
        choice_set.update(
            {number: cls.NUMBERS for number in cls.NUMBERS}
        )
        choice_set['-'] = tuple('-')
        return choice_set


def apply_scenarios(
    input_tables: InputTables,
    config: dict,
    logger: logging.Logger,
):
    """ Apply scenarios specified in config

    :param input_tables: input_tables instantiated targeting the output folder
    :param config: dictionary containing scenarios configurations
    """
    scenario_count = 0
    for scenario in config['scenario']:
        target_params = scenario['target']
        logger.info('Applying scenario %s', scenario_count)

        for target_table_name in target_params['table_name']:
            target_df = input_tables.get(target_table_name)

            # Compute conditions
            conditions = scenario.get('condition', [])
            mask = pd.notna(target_df).max(axis=1)
            for condition in conditions:
                cond_table_name = condition['table_name']
                cond_col_name = condition['column_name']
                if cond_col_name not in target_df.columns:
                    raise ValueError(
                        f'Specified a condition on {cond_col_name} but not '
                        f'available across target table {target_table_name}: '
                        f'{target_df.columns}'
                    )

                if cond_table_name == target_table_name:
                    mask = mask & apply_conditions(
                        col_series=target_df[cond_col_name],
                        categorical_values=condition.get('categorical_values'),
                        min_value=condition.get('min_value'),
                        max_value=condition.get('max_value'),
                    )

                elif condition.get('join'):
                    cond_table = input_tables.get(cond_table_name)
                    if cond_col_name not in cond_table.columns:
                        raise ValueError(
                            f'Specified a condition on {cond_col_name} but not'
                            f' available across target table {cond_table_name}'
                            f': {cond_table.columns}'
                        )
                    # Rename to avoid clashing with same name cols
                    join_cols = condition.get('join')
                    cond_table = cond_table[join_cols + [cond_col_name]]
                    cond_table = cond_table.rename(
                        columns={cond_col_name: '_cond_col'},
                    )
                    original_cols = list(target_df.columns)
                    original_len = len(target_df)
                    target_df = target_df.merge(
                        right=cond_table,
                        on=join_cols,
                        how='left',
                        validate='m:1',  # Forbidden to increase len
                    )
                    assert len(target_df) == original_len
                    mask = mask & apply_conditions(
                        col_series=target_df['_cond_col'],
                        categorical_values=condition.get('categorical_values'),
                        min_value=condition.get('min_value'),
                        max_value=condition.get('max_value'),
                    )
                    target_df = target_df[original_cols]

            # Apply changes
            target_columns = set(target_params['column_name'])
            relative_change = target_params.get('relative_change', [1])
            absolute_change = target_params.get('absolute_change', [0])
            categorical_change = target_params.get('categorical_change')
            available_cols = target_columns.intersection(target_df.columns)
            for col in available_cols:
                if categorical_change:
                    target_df[col] = target_df[col].apply(
                        lambda _: random.choice(categorical_change)
                    )
                else:
                    target_df[col] = target_df[col].apply(
                        lambda x: (
                            random.choice(relative_change) * x +
                            random.choice(absolute_change)
                        )
                    )

            logger.info(
                'Saving table %s after applying changes',
                target_table_name,
            )
            target_df.to_csv(
                os.path.join(
                    input_tables.folder_path,
                    f'{target_table_name}_table.csv',
                ),
                index=False,
                sep=';',
            )

        scenario_count += 1


def apply_conditions(
    col_series: pd.Series,
    categorical_values: typing.Optional[typing.Iterable],
    min_value: typing.Optional[float],
    max_value: typing.Optional[float],
) -> pd.Series:
    if categorical_values:
        return col_series.isin(categorical_values)

    if (min_value is None) and (max_value is None):
        raise ValueError(
            'Condition must specify one of '
            'categorical_values, min_value, max_value '
            'but none were passed'
        )
    if not (
        pd.api.types.is_numeric_dtype(
            col_series.dtype
        ) or
        pd.api.types.is_datetime64_any_dtype(
            col_series.dtype
        )
    ):
        raise ValueError(
            f'Cannot interpret min and/or max value condition '
            f'because column {col_series.name} (dtype '
            f'{col_series.dtype}) is not numeric'
        )

    if min_value is None:
        try:
            return col_series <= max_value
        except TypeError:
            return col_series <= pd.Timestamp(max_value)

    elif max_value is None:
        try:
            return col_series >= min_value

        except TypeError:
            return col_series >= pd.Timestamp(min_value)

    else:
        try:
            return (
                (col_series >= min_value) &
                (col_series <= max_value)
            )

        except TypeError:
            return (
                (col_series >= pd.Timestamp(min_value)) &
                (col_series <= pd.Timestamp(max_value))
            )


def load_config() -> list:
    """ Load the Sampler yaml config from the given path

    :param config_path: path

    :returns: list
    """
    with open(
        os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            'sampler_config.yaml',
        )
    ) as config_file:
        return yaml.safe_load(config_file)


def parse_args():
    """ Parse arguments passed to the Sampler
    """
    parser = argparse.ArgumentParser(
        description='Sample tables in a folder, creating synthetic data.'
    )

    parser.add_argument(
        '-t',
        '--target',
        type=str,
        help='Path to the folder containing tables to anonymize.',
    )
    parser.add_argument(
        '-o',
        '--output',
        type=str,
        help='Path to the folder where to store the anonymized tables.',
    )
    parser.add_argument(
        '-n',
        '--name-lexicon',
        type=str,
        default='~/Documents/Data/Other/nat2022.csv',
        required=False,
        help='Path to fetch a name lexicon',
    )
    parser.add_argument(
        '-s',
        '--seed',
        type=int,
        default=13,
        required=False,
        help='Random seed for anonymization. Default is 13.',
    )

    args = parser.parse_args()
    return args


def extract_name_set(lexicon_path: str) -> list:
    """ Extract name set from lexicon path"""
    lexicon_table = pd.read_csv(lexicon_path, sep=";")
    name_set = list(lexicon_table['preusuel'].unique())
    name_set.remove('_PRENOMS_RARES')
    return name_set


if __name__ == '__main__':
    args = parse_args()
    logger = gen_logger('sampler')
    config = load_config()
    sampler = Sampler(
        logger=logger,
        input_tables=InputTables(args.target),
        name_lexicon=args.name_lexicon,
        config=config,
    )
    for table in TABLE_LST:
        anon_table = sampler.anon_table(table)
        anon_table.to_csv(
            os.path.join(
                args.output,
                f'{table.name}_table.csv',  # End in _table for InputTables
            ),
            index=False,
            sep=';',
        )

    # Apply scenarios
    apply_scenarios(
        input_tables=InputTables(args.output),
        config=config,
        logger=logger,
    )
