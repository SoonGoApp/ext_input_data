""" Script to inject data from the input tables csv / dfs into a local database
"""
import json
import os
import typing
import yaml
from contextlib import contextmanager
from functools import cached_property, lru_cache

import pandas as pd
from sqlalchemy import create_engine
from sqlalchemy.engine import Engine
from sqlalchemy.orm import sessionmaker, Session

from sql_mappings import OrganizationsTable, KpisTable


# Update db_config file to update database
def gen_engine(
    db_username: typing.Optional[str] = None,
    db_password: typing.Optional[str] = None,
    db_host: typing.Optional[str] = None,
    db_port: typing.Optional[str] = None,
    db_name: typing.Optional[str] = None,
) -> Engine:
    """ Generate an SQLAlchemy database engine object to connect to the local
    soongo database.

    :returns: SQLAlchemy engine connected to the SoonGo local db
    """
    db_config = {
        'db_username': db_username,
        'db_password': db_password,
        'db_host': db_host,
        'db_port': db_port,
        'db_name': db_name,
    }
    filtered_arg_lst = [
        arg for arg in db_config.values() if arg
    ]
    if (
        any(filtered_arg_lst) and
        len(filtered_arg_lst) != len(db_config.values())
    ):
        raise ValueError(
            'Passed db_connection argument may either be all None or all'
            'provided'
        )

    if not any(filtered_arg_lst):
        with open(
            os.path.join(
                os.path.dirname(__file__),
                'db_config.yaml',
            )
        ) as file:
            db_config = yaml.safe_load(file)

    # Create a connection string
    connection_string = (
        'postgresql://{db_username}:{db_password}@{db_host}:{db_port}/'
        '{db_name}'.format(**db_config)
    )

    # Create an engine object
    return create_engine(connection_string)


def gen_session(
    db_username: typing.Optional[str] = None,
    db_password: typing.Optional[str] = None,
    db_host: typing.Optional[str] = None,
    db_port: typing.Optional[str] = None,
    db_name: typing.Optional[str] = None,
) -> Session:
    """ Generate an SQLAlchemy session object to connect to the local
    soongo database.

    :returns: SQLAlchemy session connected to the SoonGo local db
    """

    return sessionmaker(
        bind=gen_engine(
            db_username=db_username,
            db_password=db_password,
            db_host=db_host,
            db_port=db_port,
            db_name=db_name,
        )
    )()


@contextmanager
def session_scope(
    db_username: typing.Optional[str] = None,
    db_password: typing.Optional[str] = None,
    db_host: typing.Optional[str] = None,
    db_port: typing.Optional[str] = None,
    db_name: typing.Optional[str] = None,
):
    """Provide a transactional scope around a series of operations."""
    session = gen_session(
        db_username=db_username,
        db_password=db_password,
        db_host=db_host,
        db_port=db_port,
        db_name=db_name,
    )
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


@lru_cache
def get_organization_id(
    organization_name: str,
    db_username: typing.Optional[str] = None,
    db_password: typing.Optional[str] = None,
    db_host: typing.Optional[str] = None,
    db_port: typing.Optional[str] = None,
    db_name: typing.Optional[str] = None,
) -> str:
    """ Get organization uuid id from db

    :param organization_name: str name of the organization whose id should be
        returned
    """
    with session_scope(
        db_username=db_username,
        db_password=db_password,
        db_host=db_host,
        db_port=db_port,
        db_name=db_name,
    ) as session:
        organization_id = session.query(OrganizationsTable.id).filter(
            OrganizationsTable.name == organization_name
        ).scalar()
        if organization_id is None:
            raise ValueError(
                f'There are no organization named {organization_name} in '
                'database'
            )
        return organization_id


@lru_cache
def get_kpi_id(
    kpi_name: str,
    db_username: typing.Optional[str] = None,
    db_password: typing.Optional[str] = None,
    db_host: typing.Optional[str] = None,
    db_port: typing.Optional[str] = None,
    db_name: typing.Optional[str] = None,
) -> str:
    """ Get kpi uuid id

    :param kpi_name: str display name of the kpi
    """
    with session_scope(
        db_username=db_username,
        db_password=db_password,
        db_host=db_host,
        db_port=db_port,
        db_name=db_name,
    ) as session:
        kpi_id = session.query(KpisTable.id).filter(
            KpisTable.display_name == kpi_name
        ).one_or_none()
        if kpi_id is None:
            raise ValueError(
                f'There are no kpi named {kpi_name} in database'
            )
        return kpi_id


class Perimeter:

    def __init__(
        self,
        filter_values: typing.Optional[typing.Dict[str, typing.List]] = None,
        extra_args: typing.Optional[typing.Dict[str, typing.Any]] = None,
    ):
        self.filter_values = filter_values if filter_values else {}
        self.extra_args = extra_args if extra_args else {}

    @cached_property
    def json(self) -> typing.Dict:
        return_dict = {'extra': self.extra_args}
        return_dict.update(self.filter_values)
        return json.dumps(return_dict)


def compute_kpi_value(
    kpi_name: str,
    start_date: pd.Timestamp,
    end_date: pd.Timestamp,
    organization_name: str,
    perimeter: Perimeter,
):
    """ Compute kpi value on a start and end date, an organization_name and
        perimeter value.

        :param kpi_name: string name of the kpi to compute
        :param start_date: date to start computing it from
        :param end_date: date to compute it until
        :param organization_name: organization to compute it for
        :param perimeter: perimeter to subset it to.
    """
    # TODO: Convert to SQLAlchemy
    # Define the subquery to select the specific row
    from sqlalchemy import text
    organization_id = get_organization_id(organization_name)
    with session_scope() as session:
        return session.execute(
            text(
                f"""
                SELECT value from publ.kpis_value(
                        (
                            SELECT k FROM publ.kpis k
                            WHERE k.display_name = '{kpi_name}'
                        ),
                        '{start_date}'::date,
                        '{end_date}'::date,
                        '{organization_id}'::uuid,
                        '{perimeter.json}'::json,
                        NULL::uuid
                );
                """
            )
        ).scalar()


if __name__ == '__main__':
    session = gen_session()

    # Execute the query using the session
    print(
        compute_kpi_value(
            kpi_name='TCO (new)',
            start_date='2023-01-01',
            end_date='2023-12-31',
            organization_name='Quartus',
            perimeter=Perimeter(),
        )
    )
