""" List utility functions used across different gac modules"""
import logging
import os
import re
import typing
import multiprocessing
from collections import Counter
from dataclasses import dataclass
from datetime import datetime

import numpy as np
import pandas as pd
import pdfplumber
import pytesseract
import requests
from pdf2image import convert_from_path

from data_models.base import DataColumn
from data_models import SoonGoRecordsModel, ExpensesModel, CollaboratorsModel
from utils.type import (
    series_is_nan, convert_string, get_dtype_null, convert_names, str_is_nan
)
from utils.logging import gen_logger
from utils.enums import SynchronizationTypes


connector_dict = {}


def add_connector(connector_class: typing.Type):

    def decorator():
        connector_dict[connector_class.SOURCE_CONNECTOR] = connector_class
        return connector_class

    return decorator()


@dataclass
class PDFParsingParams:

    cols: typing.Collection[DataColumn]
    match_func: typing.Callable
    scope: str = 'line'

    def __post_init__(self):
        """ Run post initialization attribute value checks

        :raise ValueError: if scope is not page, or line
        """
        authorized_scopes = ('page', 'line')
        if self.scope not in authorized_scopes:
            raise ValueError(
                f'Scope value must be one of {authorized_scopes} '
                f'but {self.scope} was passed'
            )


class UnauthorizedOverwrite(Exception):

    def __init__(
        self: typing.Self,
        field_value: typing.Any,
        field_name: str,
        previous_value: typing.Any,
    ):
        message = (
            f'Trying to set value {field_value} on col {field_name} '
            f'but value {previous_value} had already been set'
        )
        super().__init__(message)


class MissingColumnError(Exception):

    def __init__(
        self: typing.Self,
        col_name: str,
    ):
        message = (
            f'Column {col_name} is mandatory but absent in df'
        )
        super().__init__(message)


class PDFInput:
    """ A PDFInput is a class which collects DataFrame information from pdf
    file(s).

    It is initiated from a list of ParsingParams, which contains a list of
    DataColumns to match, a scope attribute (whether they apply on a text
    line or a page), and a matching function (generally a regex) which returns
    values for these DataColumns upon a match.

    At init, the PDFInput stores page level ParsingParams and line level
    parsing params in a dictionary params_dict. When parsing a document,
    load_pdf first call update_values with a page scope passing it the page as
    text, and the text inputs stores the values for all the page scope parsing
    params, and the same applies then to parsing params with a line scope on a
    line by line basis. When all information for mandatory data column is com
    plete, the PDFInput stores the dataframe line in a data_lst as a dictionary
    erases data column with no memorization options and move on to the next
    line until the document is over and all data was stored in data_lst.
    PDFInput can then be turned into a dataframe using the method to_df.
    """

    def __init__(
        self: typing.Self,
        parsing_params: typing.Collection[PDFParsingParams],
        logger: logging.Logger,
    ):
        """ Generates hidden attributes for memorization and DataFrame
        construction"""
        self.logger: logging.Logger = logger
        self.memorized_values: typing.Dict[str, typing.Any] = {}
        self.col_lst: typing.List[DataColumn] = []
        self.no_mem_col_lst: typing.List[DataColumn] = []
        self.page_mem_col_lst: typing.List[DataColumn] = []
        self.params_dict: typing.Dict[str, typing.List[PDFParsingParams]] = {}
        for param in parsing_params:
            self.col_lst.extend(param.cols)
            self.no_mem_col_lst.extend(
                 [col for col in param.cols if col.memorization is None]
            )
            self.page_mem_col_lst.extend(
                 [col for col in param.cols if col.memorization == 'page']
            )
            self.params_dict[param.scope] = self.params_dict.get(
                param.scope,
                [],
            ) + [param]

        self.mandatory_col_names: typing.Set[str] = {
            col.name for col in self.col_lst if not col.optional
        }
        self.data_lst: typing.List[typing.Dict[str: typing.Any]] = []

    def is_complete(self):
        return self.mandatory_col_names.issubset(self.memorized_values.keys())

    def update_values(
        self: typing.Self,
        scope: str,
        text_to_parse: str,
    ) -> None:
        """ Update the memorized_values dict by matching the text using the
        functions in the parsing params.

        :param scope: whether the passed text is a page or a line
        :param text_to_parse: string text to parse to attempt to match the
        matching functions in the parsing params

        :raises UnauthorizedOverwrite: if a value is matched for a data column
        for whom a value was already memorized and that data column overwrite
        attribute is 'forbid'

        :returns: None but updates the internal values
        """

        for parsing_param in self.params_dict.get(scope, []):
            text_match = self.match_text_inputs(
                parsing_param=parsing_param,
                text_to_parse=text_to_parse,
                logger=self.logger,
            )

            if text_match is None:
                continue

            for data_col in parsing_param.cols:

                if data_col.name not in self.memorized_values.keys():
                    self.memorized_values[data_col.name] = (
                        text_match[data_col.name]
                    )
                    if self.is_complete():
                        self.gen_new_line()

                elif data_col.overwrite == 'preserve':
                    # If preserve, keep first occurence and ignore subsequent
                    continue

                elif data_col.overwrite == 'allow':
                    self.memorized_values[data_col.name] = (
                        text_match[data_col.name]
                    )
                    # No need to gen new_line because value already existed

                else:  # Value already existed but overwrite is forbidden
                    raise UnauthorizedOverwrite(
                        field_value=text_match[data_col.name],
                        field_name=data_col.name,
                        previous_value=self.memorized_values[data_col.name],
                    )

    @staticmethod
    def match_text_inputs(
        parsing_param: PDFParsingParams,
        text_to_parse: str,
        logger: logging.Logger,
    ) -> typing.Optional[typing.Dict[str, typing.Any]]:
        """ Attempts to match text input to text, return values if any match

        :param parsing_param: ParsingParam with DataCols to fil and matching
        function to extract values from text
        :param text_to_parse: page or line text to parse
        :param logger: logger

        :raises ValueError: if the number of values returned by the matching
        function does not match the number of columns

        :returns: None if no match, values if match
        """
        col_name_lst = [col.name for col in parsing_param.cols]
        try:
            values = parsing_param.match_func(text_to_parse)

        except Exception as error:
            logger.debug(
                'Matching func raised error %s when parsing'
                'pdf text %s for cols %s',
                error,
                text_to_parse,
                col_name_lst,
            )

        else:

            if values is None:
                return

            if len(values) != len(col_name_lst):
                raise ValueError(
                    f'Matching func only returned '
                    f'{len(values)} elements whilst '
                    f'{len(col_name_lst)} were expected when '
                    f'parsing pdf text {text_to_parse} for cols '
                    f'{col_name_lst}',
                )

            return dict(zip(col_name_lst, values))

    def gen_new_line(self):
        """ Generate a new dataframe line.

        """
        # Copy mandatory otherwise changes to self.memorized_values
        # propagate to all elements in the list
        self.data_lst.append(self.memorized_values.copy())
        for col in self.no_mem_col_lst:
            self.memorized_values.pop(col.name)

    def reset_page(self):
        for col in self.page_mem_col_lst:
            self.memorized_values.pop(col.name)

    def to_df(self):
        """ Transform the text input into DataFrame"""

        df = pd.DataFrame(self.data_lst)
        for col in self.col_lst:
            if col.name not in df.columns:
                if col.optional:
                    df[col.name] = get_dtype_null(col.dtype)
                else:
                    raise MissingColumnError(col.name)

        return df


RECORD_COLS = [
    SoonGoRecordsModel.source_connector.name,
    SoonGoRecordsModel.source_dataset.name,
    SoonGoRecordsModel.source_table.name,
    SoonGoRecordsModel.synchronisation_type.name,
]


class Dataset:
    """ The Dataset type imports tables in csv format as pandas dataframe as
    cached_properties

    :ivar folder: folder where the csv tables are stored
    :ivar logger: logging logger
    :ivar source_connector: name of the connector the dataset stems from
    :ivar name: string name of the Dataset
    :ivar table_lst: list of table names
    """

    def __init__(
        self,
        folder: str,
        logger: logging.Logger,
        source_connector: str,
        name: str,
        type: SynchronizationTypes,
        organization_name: str,
    ):
        """ Instantiate datasets and loads folder and logger

        :param folder: string path to the folder containing the csv tables
        :param logger: logging logger
        :param source_connector: name of the connector the dataset stems from
        :param name: string name of the Dataset
        """
        self.folder = folder
        self.logger = logger
        self.source_connector = source_connector
        self.name = name
        self.type = type
        self.table_lst = []
        self.organization_name = organization_name

    def agg_and_meld(
        self,
        eligible_files: typing.List[str],
        id_cols: typing.List[DataColumn],
        value_col: DataColumn,
        var_col: DataColumn,
        record_dates: typing.List[str],
        source_table: str,
        meld: bool = True,
        skip_cols: typing.Optional[typing.List[str]] = None,
        **read_params,
    ) -> pd.DataFrame:
        """ Import target csv table and melt non id cols. Returns table
        and adds attribute with table name into Dataset

        :param logger: logging.Logger
        :param file_path: str path to the monthly driver mileage data
        :param id_cols: List of DataColumns, part of the target csv tables,
            which should be kept as is in the final dataset
        :param value_name: name to be given to the long form column regrouping
            the values of all non id columns
        :param var_name: name to give to the long form column regrouping
            the header name of all non id columns
        :param meld: boolean melds if True, else just imports it
        """
        if not eligible_files:
            self.logger.warning(
                'No files to concatenate in passed list'
            )
            return pd.DataFrame(
                columns=[col.name for col in id_cols] + [value_col, var_col],
            )
        self.logger.info(
            'Aggregate %d csv files: %s',
            len(eligible_files),
            eligible_files,
        )
        list_dfs = []

        for file_path in eligible_files:
            if meld:
                df = self.meld_df(
                    file_path=file_path,
                    id_cols=id_cols,
                    value_col=value_col,
                    var_col=var_col,
                    skip_cols=skip_cols,
                    record_dates=record_dates,
                    source_table=source_table,
                    **read_params,
                )
            else:
                df = self.load_table(
                    file_path=file_path,
                    col_lst=id_cols,
                    skip_cols=skip_cols,
                    record_dates=record_dates,
                    source_table=source_table,
                    **read_params,
                )
            list_dfs.append(df)

        df = pd.concat(
            list_dfs,
            axis=0,
            ignore_index=True,
        )
        setattr(
            self,
            source_table,
            df,
        )
        return df

    def meld_df(
        self: typing.Self,
        file_path: str,
        id_cols: typing.List[DataColumn],
        value_col: DataColumn,
        var_col: DataColumn,
        record_dates: typing.List[str],
        source_table: str,
        skip_cols: typing.Optional[typing.List[str]] = None,
        **read_params,
    ):
        df = self.load_table(
            file_path=file_path,
            col_lst=id_cols,
            check_cols=False,
            skip_cols=skip_cols,
            record_dates=record_dates,
            source_table=source_table,
            **read_params,
        )
        source_vars = [SoonGoRecordsModel.record_date.name] + RECORD_COLS
        id_vars = [col.name for col in id_cols] + source_vars
        if (
            (CollaboratorsModel.employee_full_name.name not in id_vars)
            and
            (CollaboratorsModel.employee_full_name.name in df.columns)
        ):
            id_vars += [CollaboratorsModel.employee_full_name.name]
        df = pd.melt(
            frame=df,
            id_vars=id_vars,
            value_name=value_col.name,
            var_name=var_col.name,
        )
        for col in [value_col, var_col]:
            if col.post_processing:
                df[col.name] = col.post_processing(df[col.name])
            df[col.name] = df[col.name].astype(col.dtype)
        setattr(
            self,
            source_table,
            df,
        )
        return df

    def load_table(
        self: typing.Self,
        file_path: str,
        col_lst: typing.List[DataColumn],
        record_dates: typing.List[str],
        source_table: str,
        skip_cols: typing.Optional[typing.List[str]] = None,
        check_cols: bool = True,
        **read_params,
    ) -> pd.DataFrame:
        """ Load a csv or excel table as a pandas DataFrame

        :param file_path: str path to the csv file
        :param logger: logger
        :param col_lst: list of DataColumns this file contains
        :param record_dates: list of str column names to compute the record
            date from.
        :param skip_cols: raw str col name to skip, if any
        :param check_cols: check whether col_lst matches df cols.
        :param source_connector: str name of the connector the data was
            extracted from.
        :param source_dataset: str name of the dataset the data was
            extracted from.
        :param source_table: str name of the table the data was
            extracted from.

        :raises ValueError: if different number of columns in col_lst than in
        df after skipping columns, or if column raw_names don't match columns
        in df

        :returns: Pandas Dataframe with the loaded data, normalized at expected
            name and type.
        """
        if not os.path.isfile(file_path):
            self.logger.error(
                'Did not find any file under path %s',
                file_path,
            )
            return pd.DataFrame(
                columns=[col.name for col in col_lst] + RECORD_COLS,
            )

        skip_cols = [] if skip_cols is None else skip_cols
        default_params = {
            'header': 0,
            'index_col': False,
            'decimal': ',',
            'dtype': return_dtypes(col_lst),
            'usecols': lambda x: x not in skip_cols if skip_cols else True,
        }
        csv_params = {
            'encoding': 'latin_1',
            'sep': ';',
        }

        if file_path[-4:] in ('xlsx', '.xls', '.ods'):
            default_params.update(read_params)
            df = pd.read_excel(
                file_path,
                **default_params
            )

        else:
            default_params.update(csv_params)
            default_params.update(read_params)
            df = pd.read_csv(
                file_path,
                **default_params,
            )

        # usecols interfers with skip_cols hence needs a second pass
        if ('usecols' in read_params) and skip_cols:
            df = df[[col for col in df.columns if col not in skip_cols]]

        self.logger.info(
            'Successfully imported %d lines from %s',
            len(df),
            file_path,
        )
        if check_cols:
            check_col_matching(
                gac_col_lst=col_lst,
                raw_df=df,
                logger=self.logger,
            )

        for table_col in col_lst:
            df.rename(
                columns={table_col.raw_name: table_col.name},
                inplace=True,
            )

        df = check_columns(
            df=df,
            col_lst=col_lst,
            organization_name=self.organization_name,
        )

        df = get_record_date(data_df=df, record_dates=record_dates)
        df = set_record_cols(
            df=df,
            source_connector=self.source_connector,
            source_dataset=self.name,
            source_table=source_table,
            synchronization_type=self.type,
        )

        check_no_dup_values(df.columns)
        setattr(
            self,
            source_table,
            df,
        )
        return df

    def agg_pdf(
        self,
        eligible_files: typing.List[str],
        param_lst: typing.Collection[typing.Collection[PDFParsingParams]],
        read_param_lst: typing.Collection[dict],
        record_dates: typing.List[str],
        check_len_dict: typing.Mapping[str, int],
        source_table: str,
        use_ocr: bool = False,
        parallelize: bool = True,
    ) -> pd.DataFrame:
        """ Import target pdf data and agg different files. Returns table
        and adds attribute with table name into Dataset

        :param eligible_files: list of file paths to fetch data from
        :param param_lst: Collection of collection of parsing params. Each
            collection of parsing params corresponds to a file format to parse.
            The different formats are attempted until one matches.
        :param record_dates: list of str column names to compute the record
            date from.
        :param check_len_dict: Mapping of file_name to an expected number of
            records as integer. Used to confirm that all lines were indeed
            captured.
        :param source_connector: str name of the connector the data was
            extracted from.
        :param source_dataset: str name of the dataset the data was
            extracted from.
        :param source_table: str name of the table the data was
            extracted from.
        :param use_ocr: whether to use Optical Character Recognition. Only
            turn to True to bypasse PDF copy protection.
        :param read_params_lst: read params to use with each of the formats
            provided in param_lst; provided as a dict. Must provide a read
            param per parsing_param collection.
        :param parallelize: whether to run aggregations in multiprocessing

        :raises ValueError: if read_param_lst len does not equal
        parsing_param_lst len.
        """
        start = datetime.now()
        if len(read_param_lst) != len(param_lst):
            raise ValueError(
                f'Must provide as many read_params as parsing params but'
                f' {len(read_param_lst)} read params provided and '
                f'{len(param_lst)} parsing params provided.'
            )

        if not eligible_files:
            self.logger.warning(
                'No files to concatenate in passed list'
            )
            col_lst = []
            for param in param_lst:
                col_lst.extend(param.cols)
            return pd.DataFrame(
                columns=col_lst,
            )

        file_name_set = {
           os.path.basename(file_path) for file_path in eligible_files
        }
        key_set = set(check_len_dict.keys())
        if file_name_set != key_set:
            missing_files = file_name_set.difference(
                key_set
            )
            missing_keys = key_set.difference(
                file_name_set
            )
            raise ValueError(
                f'The check len dict keys do not match the eligible files '
                f'list: {missing_files} have no key and {missing_keys} have '
                f'no file in the list'
            )

        self.logger.info(
            'Aggregate %d pdf files: %s',
            len(eligible_files),
            eligible_files,
        )
        if parallelize:
            os.environ['OMP_THREAD_LIMIT'] = '1'
            parse_args = [
                (
                    file,
                    param_lst,
                    read_param_lst,
                    record_dates,
                    check_len_dict,
                    self.organization_name,
                    self.source_connector,
                    self.name,
                    source_table,
                    self.type,
                    use_ocr,
                )
                for file in eligible_files
            ]
            with multiprocessing.Pool(
                processes=multiprocessing.cpu_count()
            ) as pool:
                list_dfs = pool.starmap(parse_pdf, parse_args)
        else:
            list_dfs = [
                parse_pdf(
                    file_path=file,
                    param_lst=param_lst,
                    read_param_lst=read_param_lst,
                    record_dates=record_dates,
                    check_len_dict=check_len_dict,
                    organization_name=self.organization_name,
                    source_connector=self.source_connector,
                    source_dataset=self.name,
                    synchronization_type=self.type,
                    source_table=source_table,
                    use_ocr=use_ocr,
                )
                for file in eligible_files
            ]

        df = pd.concat(
            list_dfs,
            axis=0,
            ignore_index=True,
        )
        setattr(
            self,
            source_table,
            df,
        )
        self.logger.info('Process completes in %s', datetime.now() - start)
        return df

    def agg_pdf_table(
        self: typing.Self,
        eligible_files: typing.List[str],
        col_lst: typing.Collection[DataColumn],
        record_dates: typing.List[str],
        source_table: str,
        bounding_box: typing.Optional[typing.Tuple[int, int, int, int]] = None,
        skip_table: typing.Optional[typing.Callable] = None,
        skip_rows: typing.Optional[typing.Callable] = None,
        skip_cols: typing.Optional[typing.Callable] = None,
        **read_params,
    ) -> pd.DataFrame:
        """ Agg PDF table

        This pdf load logic aggregates tables contained within pdf files
        instead of going through a text pattern detection logic.
        To be preferred to text approach; use cropbox and read_params for
        calibration.

        :param eligible_files: list of file paths to extract data from
        :param col_lst: list of DataColumns to match in the pdf
        :param record_dates: list of str column names to compute the record
            date from.
        :param source_table: str name of the table the data was
            extracted from.
        :param bounding_box: whether to crop the page (x0, top, x1, bottom).
        See pdfplumber bouding_box parameter description
        :param skip_table: callable returning indexes to drop from a list of
            lists
        :param skip_cols: callable returning a df with dropped cols
        :param skip_rows: callable returning a df with dropped rows
        """
        table_lst = []
        for file_path in eligible_files:
            with pdfplumber.open(file_path) as pdf:

                for page in pdf.pages:

                    if bounding_box:
                        page = page.crop(bounding_box)
                    table_lst.extend(
                        page.extract_tables(**read_params)
                    )

        if skip_table:
            for table_index in skip_table(table_lst):
                table_lst.pop(table_index)

        df_lst = []
        for table in table_lst:
            table_df = pd.DataFrame(table)
            table_df = skip_rows(table_df)
            table_df = skip_cols(table_df)
            table_df.columns = [col.name for col in col_lst]
            df_lst.append(table_df)

        df = pd.concat(
            df_lst,
            axis=0,
            ignore_index=True,
        )

        df = check_columns(
            df=df,
            col_lst=col_lst,
            organization_name=self.organization_name,
        )
        df = get_record_date(data_df=df, record_dates=record_dates)
        df = set_record_cols(
            df=df,
            source_connector=self.source_connector,
            source_dataset=self.name,
            source_table=source_table,
            synchronization_type=self.type,
        )

        check_no_dup_values(df.columns)
        setattr(
            self,
            source_table,
            df,
        )
        return df

    def agg_from_api(
        self: typing.Self,
        url_lst: typing.Collection[str],
        col_lst: typing.List[DataColumn],
        record_dates: typing.List[str],
        source_table: str,
        parallelize: bool = True,
        skip_cols: typing.List[str] = tuple(),
        response_keys: typing.Sequence[str] = tuple(),
        params_tup: typing.Collection[dict] = (None, ),
        headers: typing.Optional[dict] = None,
        auth: typing.Optional[requests.auth.HTTPBasicAuth] = None,
    ) -> pd.DataFrame:
        """ Aggregate a number of responses from multiple API urls

            :param url_lst: collection url path string, including base url and
                route
            :param params: query params provided as a dictionary
            :param headers: query headers as a dictionary
            :param auth: requests auth object if auth not provided in headers
            :param col_lst: list of DataColumns this file contains
            :param record_dates: list of str column names to compute the record
                date from.
            :param skip_cols: raw str col name to skip, if any
            :param check_cols: check whether col_lst matches df cols.
            :param source_table: str name of the table the data was
                extracted from.

            :returns: queried data as a pandas DataFrame
        """
        if parallelize:
            load_args = [
                (
                    self.organization_name,
                    url,
                    col_lst,
                    record_dates,
                    self.source_connector,
                    self.name,
                    source_table,
                    False,
                    skip_cols,
                    response_keys,
                    params,
                    headers,
                    auth,
                )
                for url in url_lst
                for params in params_tup
            ]
            with multiprocessing.Pool(
                processes=multiprocessing.cpu_count()
            ) as pool:
                df_lst = pool.starmap(load_from_api, load_args)
        else:
            df_lst = [
                load_from_api(
                    organization_name=self.organization_name,
                    url=url,
                    col_lst=col_lst,
                    record_dates=record_dates,
                    source_connector=self.source_connector,
                    source_dataset=self.name,
                    source_table=source_table,
                    synchronization_type=self.type,
                    skip_cols=skip_cols,
                    response_keys=response_keys,
                    params=params,
                    headers=headers,
                    auth=auth,
                    check_cols=False,
                )
                for url in url_lst
                for params in params_tup
            ]

        df = pd.concat(df_lst, axis=0, ignore_index=True)

        df = check_columns(
            df=df,
            col_lst=col_lst,
            organization_name=self.organization_name,
        )
        df = get_record_date(data_df=df, record_dates=record_dates)
        setattr(
            self,
            source_table,
            df,
        )
        return df

    def __iter__(self) -> typing.Generator[pd.DataFrame, None, None]:
        """ Turn the class iterable. Only iterate on DataFrames."""
        for attr in vars(self):
            if isinstance(getattr(self, attr), pd.DataFrame):
                yield getattr(self, attr)


def load_from_api(
    organization_name: str,
    url: str,
    col_lst: typing.List[DataColumn],
    record_dates: typing.List[str],
    source_connector: str,
    source_dataset: str,
    source_table: str,
    synchronization_type: str,
    check_cols: bool = True,
    skip_cols: typing.Optional[typing.List[str]] = None,
    response_keys: typing.Sequence[str] = tuple(),
    params: typing.Optional[dict] = None,
    headers: typing.Optional[dict] = None,
    auth: typing.Optional[requests.auth.HTTPBasicAuth] = None,
) -> pd.DataFrame:
    """ Fetch data from an api, and return the results as a pandas
        Dataframe.

        :param organization_name: str name of the organization
        :param url: url path string, include base url and route
        :param params: query params provided as a dictionary
        :param headers: query headers as a dictionary
        :param auth: requests auth object if auth not provided in headers
        :param col_lst: list of DataColumns this file contains
        :param record_dates: list of str column names to compute the record
            date from.
        :param synchronization_type: str SynchronizationTypes enum
        :param skip_cols: raw str col name to skip, if any
        :param check_cols: check whether col_lst matches df cols.
        :param source_connector: str name of the connector the data was
            extracted from.
        :param source_dataset: str name of the dataset the data was
            extracted from.
        :param source_table: str name of the table the data was
            extracted from.

        :returns: queried data as a pandas DataFrame
    """
    logger = gen_logger('api_loader')
    response = requests.get(
        url,
        params=params,
        headers=headers,
        auth=auth,
    )
    if response.status_code != 200:
        raise APIBadResponse(response)

    response_items = response.json()
    for response_key in response_keys:
        response_items = response_items[response_key]
    df = pd.DataFrame(response_items)

    # API may not return all fields, hence cols are deleted if available
    if skip_cols:
        skip_cols = set(skip_cols).intersection(df.columns)
        df.drop(skip_cols, axis=1, inplace=True)

    check_col_matching(gac_col_lst=col_lst, raw_df=df, logger=logger)

    for table_col in col_lst:
        df.rename(
            columns={table_col.raw_name: table_col.name},
            inplace=True,
        )

    if check_cols:
        df = check_columns(
            df=df,
            col_lst=col_lst,
            organization_name=organization_name,
        )
        df = get_record_date(data_df=df, record_dates=record_dates)
    df = set_record_cols(
        df=df,
        source_connector=source_connector,
        source_dataset=source_dataset,
        source_table=source_table,
        synchronization_type=synchronization_type,
    )

    check_no_dup_values(df.columns)

    return df


def parse_pdf(
    file_path: str,
    param_lst: typing.Collection[typing.Collection[PDFParsingParams]],
    read_param_lst: typing.Collection[dict],
    record_dates: typing.List[str],
    check_len_dict: typing.Mapping[str, int],
    organization_name: str,
    source_connector: str,
    source_dataset: str,
    source_table: str,
    synchronization_type: SynchronizationTypes,
    use_ocr: bool,
):
    """ Utility function to iterate through each param and attempt parsing
        the pdf.
    """
    logger = gen_logger('pdf_parser')
    for param_index, param_set in enumerate(param_lst):

        try:
            df = load_pdf(
                # Loggers are non pickleable.
                # They need to be regenerated for multiprocessing
                logger=logger,
                file_path=file_path,
                parsing_params=param_set,
                record_dates=record_dates,
                organization_name=organization_name,
                source_connector=source_connector,
                source_dataset=source_dataset,
                source_table=source_table,
                synchronization_type=synchronization_type,
                use_ocr=use_ocr,
                **read_param_lst[param_index],
            )

            file_check = check_len_dict[os.path.basename(file_path)]
            if isinstance(file_check, int):
                total_count = file_check
            else:
                total_count = 0
                for check in check_len_dict[
                    os.path.basename(file_path)
                ]:
                    check_col = [key for key in check.keys() if key != 'count']
                    check_col = check_col[0]
                    actual_count = (df[check_col] == check[check_col]).sum()
                    expected_count = check['count']
                    total_count += expected_count

                    if actual_count != expected_count:
                        raise ValueError(
                            f'Expected {expected_count} rows from '
                            f'file {file_path} for column {check_col} value '
                            f'{check[check_col]} but {actual_count} collected'
                        )

            if total_count != len(df):
                raise ValueError(
                    f'Expected {total_count} rows in the entire '
                    f'file {file_path} but {len(df)} collected'
                )

            return df

        except (
            KeyError,
            UnauthorizedOverwrite,
            MissingColumnError,
        ):
            logger.debug(
                'Format %d failed for file %s, attemping next format',
                param_index,
                file_path,
            )
            if (param_index + 1) == len(param_lst):
                logger.error(
                    'Could not parse file %s using any of the %d'
                    'provided formats',
                    file_path,
                    (param_index + 1),
                )
                raise  # Raise original error for traceback


class APIBadResponse(Exception):

    def __init__(self: typing.Self, response: requests.Response):
        message = (
            f'Status code: {response.status_code}, reason: {response.reason} '
            f'text: {response.text}'
        )
        super().__init__(self, message)


def load_pdf(
    logger: logging.Logger,
    file_path: str,
    parsing_params: typing.Collection[PDFParsingParams],
    record_dates: typing.List[str],
    source_connector: str,
    source_dataset: str,
    source_table: str,
    synchronization_type: SynchronizationTypes,
    organization_name: str,
    use_ocr: bool = False,
    **read_params,
) -> pd.DataFrame:
    """ Read PDF files.

    The load pdf logic loads the file and turns its pages to text either
    through parsing using pdf plumber (default) or OCR (to use in case) of
    copy protection. 4 different types of parsing inputs are accepted

    :param file_path: str path to the csv file
    :param parsing_params: list of PDFParsingParams to match page by page
    or line by line depending on scope to extract information from the pdf
    :param record_dates: list of str column names to compute the record
        date from.
    :param source_connector: str name of the connector the data was
        extracted from.
    :param source_dataset: str name of the dataset the data was
        extracted from.
    :param source_table: str name of the table the data was
        extracted from.
    :param synchronization_type: SynchronisationTypes enum value
    :param use_ocr: whether to use Optical Character Recognition. Only
        turn to True to bypasse PDF copy protection.
    """
    with pdfplumber.open(file_path) as pdf:
        pdf_input = PDFInput(
            parsing_params=parsing_params,
            logger=logger,
        )
        if use_ocr:
            # Convert PDF pages to images and images to text using OCR
            page_images = convert_from_path(
                file_path,
                grayscale=True,
                **read_params
            )
            pages = [
                pytesseract.image_to_string(
                    page
                ) for page in page_images
            ]
        else:
            pages = [
                page.extract_text(**read_params) for page in pdf.pages
            ]
        for page_text in pages:

            pdf_input.update_values(
                scope='page',
                text_to_parse=page_text,
            )

            for line in page_text.split('\n'):

                pdf_input.update_values(
                    scope='line',
                    text_to_parse=line,
                )

    df = pdf_input.to_df()

    df = check_columns(
        df=df,
        col_lst=pdf_input.col_lst,
        organization_name=organization_name,
    )
    df = get_record_date(data_df=df, record_dates=record_dates)
    df = set_record_cols(
        df=df,
        source_connector=source_connector,
        source_dataset=source_dataset,
        source_table=source_table,
        synchronization_type=synchronization_type,
    )

    check_no_dup_values(df.columns)

    return df


def check_no_dup_values(iterable: typing.Iterable):
    """ Check no duplicate values in a passed iteratble

    :param iterable: Iterable whose values should all be unique

    :raises ValueError: if values are not all unique
    """
    if len(set(iterable)) < len(iterable):
        duplicated_values = [
            value for value, count in Counter(iterable).items()
            if count > 1
        ]
        raise ValueError(
            'Passed iterable contains duplicated values: '
            f'{duplicated_values}'
        )


def set_record_cols(
    df: pd.DataFrame,
    source_connector: str,
    source_dataset: str,
    source_table: str,
    synchronization_type: SynchronizationTypes,
) -> pd.DataFrame:
    df[RECORD_COLS] = (
        source_connector, source_dataset, source_table, synchronization_type
    )
    for col in RECORD_COLS:
        df[col] = convert_string(df[col])
        assert not str_is_nan(df[col]).any()

    return df


def check_columns(
    df: pd.DataFrame,
    col_lst: typing.List[DataColumn],
    organization_name: str,
) -> pd.DataFrame:
    handle_duplicate_cols(raw_df=df)

    for table_col in col_lst:

        try:
            if table_col.post_processing:
                df[table_col.name] = table_col.post_processing(
                    df[table_col.name]
                )

            df[table_col.name] = df[table_col.name].astype(table_col.dtype)

        except (ValueError, TypeError, AttributeError) as error:
            raise TypeError(
                f'An error was met whilst converting column '
                f'{table_col.name} of type {df[table_col.name].dtype} to '
                f'{table_col.dtype}: {error}'
            )

    name_cols = {
        CollaboratorsModel.employee_first_name.name,
        CollaboratorsModel.employee_last_name.name,
    }
    if (
        name_cols.issubset(df.columns) and
        CollaboratorsModel.employee_full_name.name not in df.columns
    ):
        df[CollaboratorsModel.employee_full_name.name] = (
            convert_names(organization_name)(
                df[CollaboratorsModel.employee_first_name.name]
                + ' ' +
                df[CollaboratorsModel.employee_last_name.name]
            )
        )

    return df


def get_record_date(
    data_df: pd.DataFrame,
    record_dates: typing.List[str],
) -> pd.DataFrame:
    """ Add a record date to a DataFrame to indicate the minimum time at
        which each row was recorded. This info is used for deduplication.

    :param data_df: DataFrame to date each row for

    :returns: data_df with an additional record_date column
    """
    if not record_dates:
        data_df[SoonGoRecordsModel.record_date.name] = pd.NaT
    else:
        data_df[SoonGoRecordsModel.record_date.name] = (
            data_df[record_dates].max(
                axis=1
            )
        )
    return data_df


def handle_duplicate_cols(raw_df: pd.DataFrame) -> None:
    """ Handle duplicate columns in raw dataframe

    :param raw_df: imported DataFrame with possibly duplicated columns

    :raises ValueError: if multiple columns share the same name but contain
        different values

    :returns: None, but drops duplicate columns which contain the same values
    """
    dup_cols = [
        (col, re.search(r'(.*).*\.\d+$', col).group(1))
        for col in raw_df.columns
        if re.search(r'(.*).*\.\d+$', col)
    ]

    for col, root_col in dup_cols:

        if root_col in raw_df.columns:

            # Handle Immat. with or without '-' format. Prefer with '-'
            if root_col == 'Immat.':
                sanitized_col = raw_df[col].str.replace('-', '')
                sanitized_root = raw_df[root_col].str.replace('-', '')

                if (sanitized_root == sanitized_col).all():

                    if raw_df[col].str.contains('-').any() is False:
                        raw_df.drop(col, axis=1, inplace=True)

                    else:
                        raw_df.drop(root_col, axis=1, inplace=True)
                        raw_df.rename(columns={col: root_col}, inplace=True)

                else:
                    raise ValueError(
                        'Multiple Immat. columns with different values'
                    )

            elif (raw_df[col].fillna(0) != raw_df[root_col].fillna(0)).any():
                raise ValueError(
                    f'Multiple cols named {root_col} have different values'
                )

            else:
                raw_df.drop(col, axis=1, inplace=True)


def check_col_matching(
    gac_col_lst: typing.List[DataColumn],
    raw_df: pd.DataFrame,
    logger: logging.Logger,
) -> None:
    """ Check columns matching between provided DataColumn list and dataframe

    :param gac_col_lst: list of DataColumns
    :param raw_df: import pandas DataFrame

    :raises ValueError: if gac_col_lst does not match raw_df columns
    """
    expected_col_names = {gac_col.raw_name for gac_col in gac_col_lst}
    actual_col_names = set(raw_df.columns)
    if expected_col_names != actual_col_names:
        missing_expected = expected_col_names.difference(actual_col_names)
        unexpected_actual = actual_col_names.difference(expected_col_names)
        empty_unexpected = {
            col for col in unexpected_actual
            if (
                pd.api.types.is_numeric_dtype(raw_df[col]) and
                (raw_df[col] == 0).all() and pd.notna(raw_df[col]).any()
            ) or series_is_nan(raw_df[col]).all()
        }
        if unexpected_actual != empty_unexpected:
            raise ValueError(
                f'Expected columns {missing_expected} but missing and'
                f' found {unexpected_actual.difference(empty_unexpected)} but '
                f'not expected, as well as {len(empty_unexpected)} empty '
                f'columns: {empty_unexpected}'
            )
        else:
            logger.warn(
                'Dropping %d empty columns not in the DataColumn list',
                len(empty_unexpected),
            )
            raw_df.drop(list(empty_unexpected), axis=1, inplace=True)


def return_dtypes(
    gac_attributes: typing.List[DataColumn],
) -> typing.Dict:
    """ Return pandas style dtypes for import

    :param col_names: list of GacColumn attributes as str

    :raises ValueError: if attribute are repeated

    :returns: dtypes with column name and dtype
    """
    check_no_dup_values(gac_attributes)

    return {
        attr.name: attr.dtype
        for attr in gac_attributes
    }


def get_latest_file(
    target_folder: str,
    pattern: typing.Pattern,
) -> str:
    """ Get latest file matching a specific patter in a target folder

    :param target_folder: folder to get the file from
    :param pattern: regular expression the file name needs to match

    :raises ValueError: if the provided target folder argument is not a valid
    directory or if several files matching the pattern have the same most
    recent update time

    :returns: path to the latest file
    """
    if not os.path.isdir(target_folder):
        raise ValueError(
            f'The provided target_folder argument is not a valid directory '
            f'{target_folder}'
        )
    matching_files = [
        os.path.join(target_folder, file_name)
        for file_name in os.listdir(target_folder)
        if re.match(pattern, file_name) and os.path.isfile(
            os.path.join(target_folder, file_name)
        )
    ]
    update_times = [
        os.path.getmtime(file_path) for file_path in matching_files
    ]
    most_recent_time = np.max(update_times)
    most_recent_files = [
        matching_files[index] for index in range(len(update_times))
        if update_times[index] == most_recent_time
    ]
    if len(most_recent_files) == 1:
        return most_recent_files[0]

    else:
        raise ValueError(
            f'File matching the provided pattern file name are tied in terms'
            f'of update time: {most_recent_files}'
        )


class parser_factory:

    def __init__(self, pattern: str):
        self.pattern = re.compile(pattern)

    def __call__(self, line: str) -> typing.Optional[typing.Collection]:
        pattern_match = re.search(
            self.pattern,
            line,
        )
        if pattern_match:
            return pattern_match.groups()


def check_vat_consistency(expense_df: pd.DataFrame) -> None:
    """ Helper function which checks whether tax_exc, tax_inc, and VAT
    amount are consistent. Helps detects parsing errors, notably with OCR.

    :param expense_df: Pandas DataFrame with a amount_tax_exc,
        amount_tax_inc, and a vat_amount or vat_rate column.

    :raises ValueError: if necessary Columns not available or values do not
    match.

    :returns: None but checks that expense_df values are consistent
    """
    req_values = {
        ExpensesModel.amount_tax_exc.name,
        ExpensesModel.amount_tax_inc.name,
    }
    opt_values = {
        ExpensesModel.vat_amount.name,
        ExpensesModel.vat_rate.name,
    }
    if not req_values.issubset(expense_df.columns):
        raise ValueError(
            f'Checking VAT consistency requires both {req_values} but '
            f'passed df only contains {expense_df.columns}'
        )

    vat_cols = opt_values.intersection(expense_df.columns)
    if not vat_cols:
        raise ValueError(
            f'Checking VAT consistency requires one of {opt_values} but'
            f'passed df only contains {expense_df.columns}'
        )

    if ExpensesModel.vat_amount.name in vat_cols:
        vat_amount = expense_df[ExpensesModel.vat_amount.name]

    else:
        vat_amount = (
            expense_df[ExpensesModel.amount_tax_inc.name] *
            expense_df[ExpensesModel.vat_rate.name] / 100
        )

    consistent_values = (
        np.isclose(
            expense_df[ExpensesModel.amount_tax_inc.name],
            (
                expense_df[ExpensesModel.amount_tax_exc.name] +
                vat_amount
            )
        ) | series_is_nan(expense_df[ExpensesModel.amount_tax_inc.name]) |
        series_is_nan(expense_df[ExpensesModel.amount_tax_exc.name]) |
        series_is_nan(vat_amount)
    )
    if not consistent_values.all():
        examples = expense_df.loc[
            ~consistent_values,
            [
                ExpensesModel.amount_tax_exc.name,
                ExpensesModel.amount_tax_inc.name,
            ]
        ].head()
        raise ValueError(
            f'The provided tax_exc and tax_inc amounts are not consistent '
            f'with the provided vat_amount; for example: {examples}'
        )
