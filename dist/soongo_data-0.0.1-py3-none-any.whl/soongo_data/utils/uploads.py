import typing
import uuid

import pandas as pd
from sqlalchemy import Engine, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm.session import Session

from utils.type import str_is_nan
from utils.enums import (
    SynchronizationStatus as StatusEnum, SynchronizationTypes
)
from data_models import VehiclesModel, CollaboratorsModel
from sql_mappings.synchronisations import (
    ConnectorsTable, SynchronisationTypesTable, SynchronisationStatusTable,
    SynchronisationsTable
)
from sql_mappings import (
    Regions, VehiclesTable, BusinessUnits, VehicleManufacturersTable,
    VehicleBrandsTable, VehicleModelsTable, VehicleTrimsTable
)


def upsert_synchronisation(
    session: Session,
    synchronisation_id: str,
    connector_name: str,
    synchronisation_type: SynchronizationTypes,
    organization_id: uuid.UUID,
):
    """ Attempts to insert the passed synchronisation_id as a new Synchronisation
    object in the table publ.synchronisations if it does not yet exists.

    :param session: SQLAlchemy session
    :param synchronisation_id: str synchronisation id
    :param connector_name: str source_connector_name,
    :param synchronisation_type: str SynchronizationTypes enum value
    :param organization_id: str organization_id

    :returns: passed synchronisation_id
    """

    # Fetch connector_id, type_id, and status_id
    connector_id = session.query(
        ConnectorsTable.id
    ).filter_by(name=connector_name).scalar()
    type_id = session.query(
        SynchronisationTypesTable.id
    ).filter_by(name=synchronisation_type).scalar()
    status_id = session.query(
        SynchronisationStatusTable.id
    ).filter_by(name=StatusEnum.ongoing.value).scalar()

    # Insert or ignore
    try:
        new_sync = SynchronisationsTable(
            id=synchronisation_id,
            connector_id=str(connector_id),
            type_id=str(type_id),
            status_id=str(status_id),
            organization_id=str(organization_id),
        )
        session.add(new_sync)
        session.commit()
    except IntegrityError:
        session.rollback()

    return synchronisation_id


def upsert_region(
    session: Session,
    regions: typing.Collection[str],
    synchronisation_id: str,
    connector_name: str,
    synchronisation_type: SynchronizationTypes,
    organization_id: uuid.UUID,
):
    """ Attempts to upsert a region names array to db. region names must follow
    the '(?:\s+(?: > )?)+' pattern. 

    """
    synchronisation_uuid = upsert_synchronisation(
        session=session,
        synchronisation_id=synchronisation_id,
        connector_name=connector_name,
        synchronisation_type=synchronisation_type,
        organization_id=organization_id,
    )

    v_parent_id = None
    for v_region_name in regions:
        v_region_id = session.query(Regions.id).filter_by(
            name=v_region_name,
            organization_id=organization_id,
            parent_id=v_parent_id
        ).scalar()

        if not v_region_id:
            new_region = Regions(
                name=v_region_name,
                organization_id=organization_id,
                parent_id=v_parent_id,
                original_synchronisation_id=synchronisation_uuid
            )
            session.add(new_region)
            session.flush()
            v_region_id = new_region.id

        v_parent_id = v_region_id

    session.commit()
    return v_region_id


def upsert_business_unit(
    session: Session,
    business_units: typing.Collection[str],
    synchronisation_id: str,
    connector_name: str,
    synchronisation_type: SynchronizationTypes,
    organization_id: uuid.UUID,
):
    if not business_units:
        return None

    synchronisation_uuid = upsert_synchronisation(
        session=session,
        synchronisation_id=synchronisation_id,
        connector_name=connector_name,
        synchronisation_type=synchronisation_type,
        organization_id=organization_id,
    )

    v_parent_id = None
    for v_business_unit_name in business_units:
        v_business_unit_id = session.query(BusinessUnits.id).filter_by(
            name=v_business_unit_name,
            organization_id=organization_id,
            parent_id=v_parent_id
        ).scalar()

        if not v_business_unit_id:
            new_business_unit = BusinessUnits(
                name=v_business_unit_name,
                organization_id=organization_id,
                parent_id=v_parent_id,
                original_synchronisation_id=synchronisation_uuid
            )
            session.add(new_business_unit)
            session.flush()
            v_business_unit_id = new_business_unit.id

        v_parent_id = v_business_unit_id

    session.commit()
    return v_business_unit_id


def upsert_car_trim(
    session: Session,
    constructor_name,
    brand_name: str,
    model_name: str,
    trim_name: str,
    synchronisation_id: str,
    connector_name: str,
    synchronisation_type: SynchronizationTypes,
    organization_id: uuid.UUID,
):
    synchronisation_uuid = upsert_synchronisation(
        session=session,
        synchronisation_id=synchronisation_id,
        connector_name=connector_name,
        synchronisation_type=synchronisation_type,
        organization_id=organization_id,
    )

    v_constructor_id = session.query(VehicleManufacturersTable.id).filter_by(
        name=constructor_name,
        organization_id=organization_id
    ).scalar()

    if not v_constructor_id:
        new_constructor = VehicleManufacturersTable(
            name=constructor_name,
            organization_id=organization_id,
            original_synchronisation_id=synchronisation_uuid
        )
        session.add(new_constructor)
        session.flush()
        v_constructor_id = new_constructor.id

    v_brand_id = session.query(VehicleBrandsTable.id).filter_by(
        name=brand_name,
        manufacturer_id=v_constructor_id,
        organization_id=organization_id
    ).scalar()

    if not v_brand_id:
        new_brand = VehicleBrandsTable(
            name=brand_name,
            manufacturer_id=v_constructor_id,
            organization_id=organization_id,
            original_synchronisation_id=synchronisation_uuid
        )
        session.add(new_brand)
        session.flush()
        v_brand_id = new_brand.id

    v_model_id = session.query(VehicleModelsTable.id).filter_by(
        name=model_name,
        brand_id=v_brand_id,
        organization_id=organization_id
    ).scalar()

    if not v_model_id:
        new_model = VehicleModelsTable(
            name=model_name,
            brand_id=v_brand_id,
            organization_id=organization_id,
            original_synchronisation_id=synchronisation_uuid
        )
        session.add(new_model)
        session.flush()
        v_model_id = new_model.id

    v_trim_id = session.query(VehicleTrimsTable.id).filter_by(
        name=trim_name,
        model_id=v_model_id,
        organization_id=organization_id
    ).scalar()

    if not v_trim_id:
        new_trim = VehicleTrimsTable(
            name=trim_name,
            model_id=v_model_id,
            organization_id=organization_id,
            original_synchronisation_id=synchronisation_uuid
        )
        session.add(new_trim)
        session.flush()
        v_trim_id = new_trim.id

    session.commit()

    return {
        'constructor_id': v_constructor_id,
        'brand_id': v_brand_id,
        'model_id': v_model_id,
        'trim_id': v_trim_id
    }


def fetch_vehicle_ids(
    vehicle_df: pd.DataFrame,
    organization_id: str,
    engine: Engine,
) -> pd.DataFrame:
    """ Fetches the vehicle_ids corresponding to the plate numbers in the data

    :param vehicle_df: DataFrame with a plate_number column
    :param engine: sqlalchemy engine

    :raises: ValueError if plate_number not available
    """
    if VehiclesModel.plate_number.name not in vehicle_df.columns:
        raise ValueError(
            f'Plate number is not in columns {vehicle_df.columns}'
        )
    if VehiclesModel.vehicle_id.name in vehicle_df.columns:
        raise ValueError('Vehicle id already available')

    matching_df = pd.read_sql(
        sql=select(
            VehiclesTable.plate_number,
            VehiclesTable.id.label(VehiclesModel.vehicle_id.name),
        ).select_from(VehiclesTable).where(
            VehiclesTable.organization_id == organization_id
        ),
        con=engine,
    )
    vehicle_df = vehicle_df.merge(
        matching_df,
        how='left',
        on=VehiclesModel.plate_number.name,
        validate='m:1',
        indicator=True,
    )
    non_missing_plate = ~str_is_nan(
        vehicle_df[VehiclesModel.plate_number.name]
    )
    new_vehicles = vehicle_df['_merge'] != 'both'
    if (new_vehicles & non_missing_plate).any():
        new_plates = vehicle_df.loc[
            new_vehicles & non_missing_plate,
            "plate_number",
        ].unique()
        raise ValueError(
            'Some of the passes vehicles are new; insert vehicles before'
            f'inserting current data: {new_plates}'
        )
    vehicle_df.drop('_merge', axis=1, inplace=True)
    return vehicle_df


def fetch_collaborator_ids(
    collab_df: pd.DataFrame,
    organization_id: str,
    engine: Engine,
) -> pd.DataFrame:
    """ Fetches the vehicle_ids corresponding to the plate numbers in the data

    :param vehicle_df: DataFrame with a plate_number column
    :param engine: sqlalchemy engine

    :raises: ValueError if plate_number not available
    """
    if CollaboratorsModel.employee_id.name not in collab_df.columns:
        raise ValueError(
            f'Plate number is not in columns {collab_df.columns}'
        )
    if CollaboratorsModel.collaborator_id.name in collab_df.columns:
        raise ValueError('Collaborator id already available')

    matching_df = pd.read_sql(
        sql=select(
            CollaboratorsModel.employee_id,
            CollaboratorsModel.id.label(CollaboratorsModel.collaborator_id.name),
        ).select_from(CollaboratorsModel).where(
            CollaboratorsModel.organization_id == organization_id
        ),
        con=engine,
    )
    collab_df = collab_df.merge(
        matching_df,
        how='left',
        on=CollaboratorsModel.employee_id.name,
        validate='m:1',
        indicator=True,
    )
    non_missing_id = ~str_is_nan(
        collab_df[CollaboratorsModel.employee_id.name]
    )
    new_collab = collab_df['_merge'] != 'both'
    if (new_collab & non_missing_id).any():
        new_ids = collab_df.loc[
            new_collab & non_missing_id,
            CollaboratorsModel.employee_id.name,
        ].unique()
        raise ValueError(
            'Some of the passed collaborators are new; insert collaborators '
            f'before inserting current data: {new_ids}'
        )
    collab_df.drop('_merge', axis=1, inplace=True)
    return collab_df
