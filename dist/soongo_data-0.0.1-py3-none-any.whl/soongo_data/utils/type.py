import dateparser
import json
import os
import typing

import numpy as np
import pandas as pd

from utils.logging import gen_logger


def convert_date(date_series: pd.Series, date_format=None) -> pd.Series:
    """ Convert date series, handling pandas base utility errors on French
        months

    :param date_series: a Series of dates as strings or integers

    :returns: Series converted to datetime
    """
    # Convert Excel style integer dates, or float for datetime
    if pd.api.types.is_numeric_dtype(date_series.dtype):
        if date_series.loc[pd.notna(date_series)].max() < 30000:
            raise ValueError(
                'An integer series was provided for date casting, but values'
                'are not credible dates values (before 1982)'
            )
        # 0 translates into 30/12/1899 in Excel string formatting
        return pd.to_datetime(
            date_series,
            unit='D',
            origin='1899-12-30',
        )

    # Convert stringified dates
    try:
        if date_format:
            day_first = date_format.startswith(r'%d')
        else:
            day_first = True  # Default in European data.

        return pd.to_datetime(
            date_series,
            format=date_format,
            dayfirst=day_first,  # Necessary to silence warning
        )
    except (pd._libs.tslibs.parsing.DateParseError, ValueError):
        return date_series.apply(
            lambda x: dateparser.parse(x) if isinstance(x, str) else pd.NaT
        )


def convert_numeric(str_series: pd.Series, decimal: str = ',') -> pd.Series:
    """ Convert a string numeric value series to float

    :param str_series: a Series of dates as strings

    :returns: Series converted to datetime
    """
    if pd.api.types.is_numeric_dtype(str_series.dtype):
        return str_series

    if decimal != '.':
        str_series = str_series.astype(str).str.replace(decimal, '.')
    for charac in [
        ' ', '€', 'TTC', 'HT', 'km', 'ans', 'an', '(valeurcalculée)',
        '\x80', "'",
    ]:
        str_series = str_series.astype(str).str.replace(charac, '')

    lost_values = str_series.loc[
        pd.isna(pd.to_numeric(str_series, errors='coerce'))
    ]
    if len(lost_values):
        # Create console handler and set level to debug
        method_logger = gen_logger('convert_numeric')
        method_logger.debug(
            f'Lost {len(lost_values)} in processing {str_series.name}: '
            f'{lost_values.unique()}'
        )

    return pd.to_numeric(str_series, errors='coerce')


def convert_boolean(
    str_series: pd.Series,
    pos_value: str = 'oui',
    neg_value: str = 'non',
) -> pd.Series:
    """ Convert a string boolean value series to boolean

    :param str_series: a string series with oui/non values

    :raises ValueError: if series contains others that oui/non/nan

    :returns: Series converted to boolean
    """
    if pd.api.types.is_integer_dtype(str_series.dtype):
        unique_values = str_series.unique()
        if not set(unique_values) == {0, 1}:
            raise ValueError(
                f'Integer series can only be converted to boolean if 0/1 '
                f'valued, but contains: {unique_values}'
            )
        return str_series.map({0: False, 1: True})

    series_values = str_series[~series_is_nan(str_series)].str.lower().unique()
    if not set(series_values).issubset({pos_value, neg_value}):
        raise ValueError(
            f'This processing is only suitable for {pos_value}/{neg_value} '
            f'encoded columns but series contains {series_values}'
        )
    str_series = str_series.str.lower().str.strip()
    bool_series = np.where(
        str_series.str.lower() == pos_value,
        True,
        False,
    )
    return bool_series


def convert_string(str_series: pd.Series) -> pd.Series:
    """ Convert a string series to a string, filling Nan values

    :param str_series: a string series

    :returns: Series converted to string with nan replaced as ''
    """
    return str_series.fillna('').astype('string').str.strip()


def clean_accent(str_series: pd.Series):
    """Clean Pandas string series withdrawing accents and capitalization"""
    str_series = str_series.str.replace('-', ' ')
    str_series = str_series.str.normalize('NFKD')
    return str_series.str.encode('ascii', 'ignore').str.decode('utf-8')


class convert_names:
    """ Convert a string series to a string of names, deleting accent et al

    :param str_series: a string series

    :returns Series converted to a string without accent and lowercase
    """
    def __init__(self, organization_name: str):
        with open(
            os.path.abspath(
                os.path.join(
                    os.path.dirname(__file__),
                    'names_correction.json',
                )
            )
        ) as correction_file:
            self.name_dict = json.load(correction_file).get(
                organization_name, {}
            )

    def __call__(self, series: pd.Series) -> pd.Series:
        series = clean_accent(convert_string(series)).str.lower()
        series = series.str.replace(',', '')
        series = series.apply(gen_name_set)
        substitute = series.map(self.name_dict)
        return series.mask(pd.notna(substitute), substitute)


def gen_name_set(full_name: str) -> str:
    """ Gen name set, an order string with the set of words in the name.

    :param full_name: a string name

    :return: a string with all words in the name ordered alphabetically
    """
    if not isinstance(full_name, str):
        return ''

    ordered_names = full_name.split()
    ordered_names.sort()

    return ' '.join(ordered_names)


def convert_plate(str_series: pd.Series) -> pd.Series:
    str_series = convert_string(str_series)
    str_series = str_series.str.replace("'", '')
    format_match = str_series.str.match(
        pat=r'^[a-z]{2}\d{3}[a-z]{2}',
        case=False,
    )

    if not format_match.loc[~series_is_nan(str_series)].all():
        raise TypeError(
            'Attempted to convert plate to format but series does not match'
        )

    return str_series.mask(
        format_match,
        convert_string(
            str_series.str[0:2] + '-'
            + str_series.str[2:5] + '-'
            + str_series.str[5:]
        ),
    )


def convert_g_to_kg(co2_series: pd.Series) -> pd.Series:
    return convert_numeric(co2_series) / 1000


def str_is_nan(
    str_series: pd.Series,
    null_values: typing.Tuple[str] = ('', 'nan', 'NaT', 'None', ' ', '<NA>', '-'),
) -> pd.Series:
    """ Return a boolean Series indicating if the str series is Nan.

    :param str_series: Pandas Series of strings, with null values saved as
    string such as 'nan'
    :param null_values: tuple of strings accepted as null values
    """
    if not null_values:
        return str_series
    return str_series.isin(null_values) | pd.isna(str_series)


def series_is_nan(data_series: pd.Series) -> pd.Series:
    """ Check whether a series is Nan, including string.

    param data_series: Pandas Series of any dtype

    :return: Series of boolean indicating whether the series is nan
    """
    col_type = data_series.dtype
    if (
        pd.api.types.is_string_dtype(col_type) or
        pd.api.types.is_object_dtype(col_type)
    ):
        return str_is_nan(data_series)

    else:
        return pd.isna(data_series)


def df_is_nan(df: pd.DataFrame) -> pd.DataFrame:
    """ Check whether each element in a DataFrame is Nan, including string.

    :param data_series: Pandas Series of any dtype

    :return: Series of boolean indicating whether the series is nan
    """
    output_lst = []
    for col in df.columns:
        output_lst.append(series_is_nan(df[col]))

    return pd.concat(output_lst, axis=1)


def map_dtype_to_scalar_type(dtype: str) -> typing.Type:
    """ Map pandas dtype to scalar types

    :param dtype: pandas dtype string name

    :returns: equivalent ScalarType, see below, typing.Optional used for nulla
    ble types

    https://pandas.pydata.org/pandas-docs/stable/user_guide/basics.html#basics-dtypes
    """
    _map_dict = {
        'category': str,
        'string': str,
        'bool': typing.Optional[bool],
    }
    map_match = _map_dict.get(dtype)
    if map_match:
        return map_match

    if pd.api.types.is_datetime64_any_dtype(dtype):
        return pd.Timestamp

    if isinstance(dtype, pd.IntervalDtype):
        return pd.Interval

    if isinstance(dtype, pd.Period):
        return pd.Period

    if pd.api.types.is_integer_dtype(dtype):
        return typing.Optional[int]

    if pd.api.types.is_float_dtype(dtype):
        return typing.Optional[float]

    # If object does not match any
    return typing.Any


def get_dtype_null(dtype: str):
    """ Returns the null value corresponding to the specified pandas dtype"""
    if (
        pd.api.types.is_datetime64_any_dtype(dtype) or
        pd.api.types.is_timedelta64_dtype(dtype)
    ):
        return pd.NaT
    if pd.api.types.is_any_real_numeric_dtype(dtype):
        return np.nan
    if (
        (dtype == 'Interval') or
        pd.api.types.is_bool_dtype(dtype)
    ):
        return pd.NA
    if (
        pd.api.types.is_string_dtype(dtype) or
        pd.api.types.is_object_dtype(dtype)
    ):
        return ''
    else:
        raise TypeError(
            f'Dtype {dtype} not handled by the return filler function'
        )
