import logging
import os
import yaml

import connectors
from utils.aws import get_secret


class APICredsNotFound(Exception):

    def __init__(self, organization_name: str, connector_name: str):
        super().__init__(
            (
                f'{connector_name} API secrets for {organization_name} cannot'
                f'be fetched through the secret manager nor through an api '
                f'secrets file.'
            )
        )


def get_api_secret(
    organization_name: str,
    connector_name: str,
    logger: logging.Logger,
) -> dict:
    try:
        return get_secret(f'{organization_name}_{connector_name}'.lower())

    except Exception:
        logger.warning(
            'Fetch data through AWS Secrets Manager failed for api %s on '
            'connector %s, attemping the local api_secrets.yaml, if any',
            organization_name,
            connector_name,
        )
        secrets_path = os.path.join(
            os.path.dirname(
                os.path.abspath(connectors.__file__)
            ),
            'api_secrets.yaml',
        )
        if not os.path.isfile(secrets_path):
            raise APICredsNotFound(
                organization_name=organization_name,
                connector_name=connector_name,
            )

        try:
            with open(secrets_path, 'r') as file:
                api_secret_dict = yaml.safe_load(file)
                return api_secret_dict[organization_name][connector_name]
        except KeyError:
            raise APICredsNotFound(
                organization_name=organization_name,
                connector_name=connector_name,
            )
