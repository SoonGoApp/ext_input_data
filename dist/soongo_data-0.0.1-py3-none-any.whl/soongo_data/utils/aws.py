import json
import typing

import boto3


def get_secret(
    secret_name: str,
    region_name: str = "eu-west-3",
) -> typing.Union[str, list, dict, float, bool, None]:

    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )

    get_secret_value_response = client.get_secret_value(
        SecretId=secret_name
    )

    return json.loads(get_secret_value_response['SecretString'])
