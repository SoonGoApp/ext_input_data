""" Key Product Indicators

List all KPIs and their definition
"""
import typing
from enum import Enum, unique

import pandas as pd

from utils.type import convert_string, str_is_nan


@unique
class ContractType(Enum):
    long_duration = 'LLD'
    short_medium_duration = 'LCD_LMD'
    acquisition = 'ACQ'

    @classmethod
    def mapping(cls):
        return {
            'LLD': cls.long_duration.value,
            'LCD/LMD': cls.short_medium_duration.value,
            'LMD': cls.short_medium_duration.value,
            'ACQ': cls.acquisition.value,
            'GESTION': cls.acquisition.value,
        }


@unique
class RentCategory(Enum):
    financial_rent = 'FINANCIAL_RENT'
    financial_rent_adjustment = 'FINANCIAL_RENT_ADJUSTMENT'
    rent_management_fees = 'RENT_MANAGEMENT_FEES'
    rent_maintenance = 'RENT_MAINTENANCE'
    rent_telematic = 'RENT_TELEMATIC'
    rent_tires = 'RENT_TIRES'
    rent_insurance = 'RENT_INSURANCE'
    rent_fuel_card = 'RENT_FUEL_CARD'
    rent_financial_loss = 'RENT_FINANCIAL_LOSS'
    rent_replacement_vehicle_actual = 'RENT_REPLACEMENT_VEHICLE_ACTUAL'
    rent_replacement_vehicle_flat_fee = 'RENT_REPLACEMENT_VEHICLE_FLAT_FEE'
    rent_relay_vehicle_actual = 'RENT_RELAY_VEHICLE_ACTUAL'
    rent_relay_vehicle_flat_fee = 'RENT_RELAY_VEHICLE_FLAT_FEE'
    rent_assistance = 'RENT_ASSISTANCE'
    rent_others = 'RENT_OTHERS'
    rent_end_of_year = 'RENT_END_OF_YEAR'


@unique
class InsurancePremiums(Enum):
    insurance_vehicle = 'INSURANCE_VEHICLE'
    insurance_glass = 'INSURANCE_GLASS'
    insurance_replacement_vehicle = 'INSURANCE_REPLACEMENT_VEHICLE'
    insurance_assistance = 'INSURANCE_ASSISTANCE'
    insurance_financial_loss = 'INSURANCE_FINANCIAL_LOSS'
    insurance_restitution = 'INSURANCE_RESTITUTION'


@unique
class FuelTypes(Enum):
    sp95 = 'SP95'
    sp95_premium = 'SP95_PREMIUM'
    sp95e10 = 'SP95_E10'
    sp98 = 'SP98'
    sp98_premium = 'SP98_PREMIUM'
    sp100 = 'SP100'
    diesel = 'DIESEL'
    diesel_premium = 'DIESEL_PREMIUM'
    b8 = 'B8'
    b10 = 'B10'
    b20 = 'B20'
    e85 = 'E85'
    lpg = 'LPG'
    gnc = 'GNC'
    default_gaz = 'DEFAULT_GAZ'
    adblue = 'ADBLUE'
    electricity = 'ELECTRICITY'

    @classmethod
    def mapping(cls):
        return {
            # SP 95E10
            'Sans Plomb 95 E10': cls.sp95e10.value,
            'Sans Plomb 95 E10 - (vide)': cls.sp95e10.value,
            'SP95 - E10': cls.sp95e10.value,

            # SP 95
            'SP95': cls.sp95.value,
            'ESSENCE 95': cls.sp95.value,
            'Super 95 Sans PL': cls.sp95.value,
            'Super 95 Sans PL - (vide)': cls.sp95.value,
            # SP95 always containst 5% Ethanol:
            'Sans Plomb 95 E5': cls.sp95.value,

            # SP95 premium
            'SSP95 Excellium': cls.sp95_premium.value,

            # SP 98
            'SP98': cls.sp98.value,
            'ESSENCE 98': cls.sp98.value,
            'Super 98 Sans PL': cls.sp98.value,
            'Super 98 Sans PL - (vide)': cls.sp98.value,

            # SP98
            'SSP98 Excellium': cls.sp98_premium.value,

            # SP 100
            'SSP 100': cls.sp100.value,

            # Diesel
            'Gazole Excellium': cls.diesel_premium.value,
            'Gazole Excellium - (vide)': cls.diesel_premium.value,
            'Gazole Premier': cls.diesel_premium.value,
            'DIESEL': cls.diesel.value,
            'Gazole Premier - (vide)': cls.diesel_premium.value,
            'DIESEL EXCELLIUM': cls.diesel_premium.value,
            'GASOIL': cls.diesel.value,
            'GASOIL HP': cls.diesel.value,
            'Diesel': cls.diesel.value,
            'Gazole MF': cls.diesel.value,

            # Ad blue
            'ADBLUE': cls.adblue.value,
            'Adblue Bidon': cls.adblue.value,
            'AdBlue Pompe': cls.adblue.value,
            'Lubrifiant': cls.adblue.value,  # Actually unsure

            # B8
            'Diesel B8': cls.b8.value,

            # B10
            'Diesel B10': cls.b10.value,
            'Diesel B10 - (vide)': cls.b10.value,

            # B20
            'BIO DIESEL': cls.b20.value,

            # E85
            'E85 Superéthanol': cls.e85.value,
            'SuperEthanol E85': cls.e85.value,

            # Electricity
            'ev-charging': cls.electricity.value,
            'Recharge électrique débit rapide': cls.electricity.value,
            'Recharge électrique débit moye': cls.electricity.value,
            'Recharge électrique faible déb': cls.electricity.value,
            "Recharge électrique débit": cls.electricity.value,
            'EV accès recharge et park': cls.electricity.value,
            'Recharge électrique au tr': cls.electricity.value,

            # Default gaz
            'Essence': cls.default_gaz.value,
        }


@unique
class CostCategory(Enum):  # Enum inheritance is not allowed in Python
    financial_rent = RentCategory.financial_rent.value
    financial_rent_adjustment = RentCategory.financial_rent_adjustment.value
    rent_management_fees = RentCategory.rent_management_fees.value
    rent_maintenance = RentCategory.rent_maintenance.value
    rent_telematic = RentCategory.rent_telematic.value
    rent_tires = RentCategory.rent_tires.value
    rent_insurance = RentCategory.rent_insurance.value
    rent_fuel_card = RentCategory.rent_fuel_card.value
    rent_financial_loss = RentCategory.rent_financial_loss.value
    rent_replacement_vehicle_actual = (
        RentCategory.rent_replacement_vehicle_actual.value
    )
    rent_replacement_vehicle_flat_fee = (
        RentCategory.rent_replacement_vehicle_flat_fee.value
    )
    rent_relay_vehicle_actual = (
        RentCategory.rent_relay_vehicle_actual.value
    )
    rent_relay_vehicle_flat_fee = (
        RentCategory.rent_relay_vehicle_flat_fee.value
    )
    rent_assistance = RentCategory.rent_assistance.value
    rent_others = RentCategory.rent_others.value
    rent_end_of_year = RentCategory.rent_end_of_year.value
    insurance_vehicle = InsurancePremiums.insurance_vehicle.value
    insurance_glass = InsurancePremiums.insurance_glass.value
    insurance_replacement_vehicle = InsurancePremiums.insurance_replacement_vehicle.value
    insurance_assistance = InsurancePremiums.insurance_assistance.value
    insurance_financial_loss = InsurancePremiums.insurance_financial_loss.value
    insurance_restitution = InsurancePremiums.insurance_restitution.value
    insurance_deductible_cost = 'INSURANCE_DEDUCTIBLE_COST'
    insurance_brokerage_cost = 'INSURANCE_BROKERAGE_COST'
    termination_fees = 'TERMINATION_FEES'
    self_insurance = 'SELF_INSURANCE'
    sp98 = FuelTypes.sp98.value
    diesel = FuelTypes.diesel.value
    b10 = FuelTypes.b10.value
    b20 = FuelTypes.b20.value
    sp95 = FuelTypes.sp95.value
    sp95e10 = FuelTypes.sp95e10.value
    sp100 = FuelTypes.sp100.value
    lpg = FuelTypes.lpg.value
    e85 = FuelTypes.e85.value
    diesel_premium = FuelTypes.diesel_premium.value
    default_gaz = FuelTypes.default_gaz.value
    electricity = FuelTypes.electricity.value
    sp95_premium = FuelTypes.sp95_premium.value
    sp98_premium = FuelTypes.sp98_premium.value
    b8 = FuelTypes.b8.value
    gnc = FuelTypes.gnc.value
    charging_points_recurring = 'CHARGING_POINTS_RECURRING'
    charging_point_installation = 'CHARGING_POINT_INSTALLATION'
    employer_in_kind_benefits_charges = 'EMPLOYER_IN_KIND_BENEFITS_CHARGES'
    employee_in_kind_benefits_charges = 'EMPLOYEE_IN_KIND_BENEFITS_CHARGES'
    participation = 'PARTICIPATION'
    mobility_credit = 'MOBILITY_CREDIT'
    car_allowance = 'CAR_ALLOWANCE'
    environmental_bonus = 'ENVIRONMENTAL_BONUS'
    environmental_malus = 'ENVIRONMENTAL_MALUS'
    company_car_tax = 'COMPANY_CAR_TAX'
    corporate_tax_company_car_tax = 'CORPORATE_TAX_COMPANY_CAR_TAX'
    corporate_tax_in_kind_benefit = 'CORPORATE_TAX_IN_KIND_BENEFIT'
    fines = 'FINES'
    deductible_vat = 'DEDUCTIBLE_VAT'
    real_short_term_rental = 'REAL_SHORT_TERM_RENTAL'
    real_replacement_vehicle_cost = 'REAL_REPLACEMENT_VEHICLE_COST'
    real_medium_term_rental = 'REAL_MEDIUM_TERM_RENTAL'
    real_relay_vehicle_cost = 'REAL_RELAY_VEHICLE_COST'
    real_maintenance = 'REAL_MAINTENANCE'
    real_telematics_fee = 'REAL_TELEMATICS_FEE'
    real_telematics_install = 'REAL_TELEMATICS_INSTALL'
    real_tires_summer = 'REAL_TIRES_SUMMER'
    real_tires_winter = 'REAL_TIRES_WINTER'
    real_tires_other = 'REAL_TIRES_OTHER'
    real_glass = 'REAL_GLASS'
    real_fuel_card = 'REAL_FUEL_CARD'
    fuel_card_end_of_year = 'FUEL_CARD_END_OF_YEAR'
    real_assistance = 'REAL_ASSISTANCE'
    adblue = FuelTypes.adblue.value
    real_restitution = 'REAL_RESTITUTION'
    real_others = 'REAL_OTHERS'
    real_repairs = 'REAL_REPAIRS'
    tolls_card = 'TOLLS_CARD'
    tolls_real = 'TOLLS_REAL'
    parking_card = 'PARKING_CARD'
    parking_real = 'PARKING_REAL'
    washing_card = 'WASHING_CARD'
    washing_real = 'WASHING_REAL'
    logo = 'LOGO'
    management_software_fee = 'MANAGEMENT_SOFTWARE_FEE'
    management_software_install = 'MANAGEMENT_SOFTWARE_INSTALL'
    weight_tax = 'WEIGHT_TAX'
    tax_other = 'TAX_OTHER'


@unique
class CO2Categories(Enum):
    CO2_fleet_fuel = 'CO2_FLEET_FUEL'
    CO2_production = 'CO2_PRODUCTION'
    CO2_recycling = 'CO2_recycling'
    CO2_train = 'CO2_TRAIN'
    CO2_plane = 'CO2_PLANE'
    CO2_rental = 'CO2_RENTAL'
    CO2_taxi = 'CO2_TAXI'


class mapper_factory:

    def __init__(self, enum_class: Enum) -> typing.Callable:
        """ Return a mapper function which uses the mapping method of the enum
            class to return a function mapping a pandas Series to this mapping.

            :param enum_class: an Enum child class with a mapping method
        """
        self.enum_class = enum_class

    def __call__(self, pd_series: pd.Series) -> pd.Series:
        """ Map the original values of a pandas Series to a new set of values

        :param pd_series: a Pandas Series of original_data to map into new
            values

        :raises ValueError: if series contains value not covered by mapping
        """
        pd_series = convert_string(pd_series.fillna(''))

        mapping_dict = self.enum_class.mapping()
        base_values = {
            enum_value.value: enum_value.value
            for enum_value in self.enum_class
        }
        mapping_dict.update(base_values)
        missing_values = set(
            pd_series.loc[~str_is_nan(pd_series)]
        ).difference(list(mapping_dict))
        if missing_values:
            raise ValueError(
                f'The provided mapping keys {mapping_dict.keys()} do not '
                f'cover: the following series value {missing_values}'
            )
        return pd_series.map(mapping_dict)


@unique
class AccidentTypes(Enum):
    material = 'MATERIAL'
    human = 'HUMAN'
    human_and_material = 'HUMAN_AND_MATERIAL'

    @classmethod
    def mapping(cls):
        return {
            'Matériel': cls.material.value,
            'Corporel et Matériel': cls.human_and_material.value,
            'Corporel': cls.human.value,
            'Mixte': cls.human_and_material.value,
        }


@unique
class AccidentContextTypes(Enum):
    collisions = 'COLLISIONS'
    theft = 'THEFT'
    parking = 'PARKING'
    other = 'OTHER'
    glass_breakage = 'GLASS_BREAKAGE'
    theft_attempt = 'THEFT_ATTEMPT'
    fire = 'FIRE'
    natural_disaster = 'NATURAL_DISASTER'
    vandalism = 'VANDALISM'
    part_theft = 'PART_THEFT'
    recovered_theft = 'RECOVERED_THEFT'

    @classmethod
    def mapping(cls):
        return {
            'Collision': cls.collisions.value,
            'Collision VTAM': cls.collisions.value,
            'Collision Non identifié': cls.collisions.value,
            'Vol': cls.theft.value,
            'VOL': cls.theft.value,
            'VOL RETROUVE': cls.recovered_theft.value,
            'AUTO VOL': cls.theft.value,
            'AUTO Dommages tous accidents': cls.other.value,
            'AUTO Responsabilité Civile': cls.other.value,
            'Stationnement': cls.parking.value,
            'Autre': cls.other.value,
            'DOMMAGES MATERIELS': cls.other.value,
            'Bris de glace': cls.glass_breakage.value,
            'BRIS DE GLACES': cls.glass_breakage.value,
            'AUTO BRIS DE GLACE': cls.glass_breakage.value,
            'Tentative de vol': cls.theft_attempt.value,
            'TENTATIVE DE VOL': cls.theft_attempt.value,
            'Incendie': cls.fire.value,
            'INCENDIE': cls.fire.value,
            'VANDALISME': cls.vandalism.value,
            'Catastrophe naturelle': cls.natural_disaster.value,
            'FORCES DE LA NATURE': cls.natural_disaster.value,
            'AUTO EVENEMENT CLIMATIQUE': cls.natural_disaster.value,
            "VOL D'ELEMENTS DU VEHICULE": cls.part_theft.value,
        }


@unique
class AccidentStatus(Enum):
    open = 'OPEN'
    closed = 'CLOSED'

    @classmethod
    def mapping(cls):
        return {
            'En attente': cls.open.value,
            'Cloturé': cls.closed.value,
            'O': cls.open.value,
            'C': cls.closed.value,
            'En Cours': cls.open.value,
            'Sans Suite': cls.closed.value,
            'Clos': cls.closed.value,
        }


@unique
class ResponsibilityTypes(Enum):
    zero = 'ZERO'
    fifty = 'FIFTY'
    hundred = 'HUNDRED'
    not_specified = 'NOT_SPECIFIED'

    @classmethod
    def mapping(cls):
        return {
            '0': cls.zero.value,
            '0%': cls.zero.value,
            '50%': cls.fifty.value,
            '100%': cls.hundred.value,
            'Non renseigné': cls.not_specified.value,
            '0 %': cls.zero.value,
            '100 %': cls.hundred.value,
            '50': cls.fifty.value,
            '100': cls.hundred.value,
            '100.00%': cls.hundred.value,
            '50.00%': cls.fifty.value,
            '0.00%': cls.zero.value,
        }


@unique
class RentalCarSegments(Enum):
    mini = 'MINI'
    mini_elite = 'MINI_ELITE'
    compact = 'COMPACT'
    compact_elite = 'COMPACT_ELITE'
    economic = 'ECONOMIC'
    intermediary = 'INTERMEDIARY'
    intermediary_elite = 'INTERMEDIARY_ELITE'
    sedan = 'SEDAN'

    @classmethod
    def mapping(cls):
        return {
            'Mini': cls.mini.value,
            'Compacte': cls.compact.value,
            'Compacte Elite': cls.compact_elite.value,
            'Intermédiaire': cls.intermediary.value,
            'Intermédiaire Elite': cls.intermediary_elite.value,
            'Economique': cls.economic.value,
            'Grande routière': cls.sedan.value,
            'Mini Elite': cls.mini_elite.value,
        }


@unique
class TravelTypes(Enum):
    air = 'AIR'
    rail = 'RAIL'
    rental_car = 'RENTAL_CAR'
    fees = 'FEES'
    hotels = 'HOTELS'
    insurance = 'INSURANCE'

    @classmethod
    def mapping(cls):
        return {
            'Aérien': cls.air.value,
            'Train': cls.rail.value,
            'Voiture': cls.rental_car.value,
            'Frais': cls.fees.value,
            'Hôtel': cls.hotels.value,
            'ASSURANCE': cls.insurance.value,
        }


@unique
class TicketTypes(Enum):
    one_way = 'ONE_WAY'
    return_trip = 'RETURN_TRIP'
    circular = 'CIRCULAR'
    open_jaw = 'OPEN_JAW'
    unknown = 'UNKNOWN'

    @classmethod
    def mapping(cls):
        return {
            'Aller simple': cls.one_way.value,
            'Aller-retour': cls.return_trip.value,
            'Circulaire': cls.circular.value,
            'Open jaw': cls.open_jaw.value,
        }


@unique
class CabinClassTypes(Enum):
    economic = 'ECONOMIC'
    second = 'SECOND'
    business = 'BUSINESS'
    first = 'FIRST'
    premier = 'PREMIER'
    premium = 'PREMIUM'
    unknown = 'UNKNOWN'

    @classmethod
    def mapping(cls):
        return {
            'Economique': cls.economic.value,
            'Seconde': cls.second.value,
            'Première': cls.premier.value,
            'Business': cls.business.value,
            'First': cls.first.value,
            'Premium': cls.premium.value,
        }


@unique
class FiscalType(Enum):
    personal_car = 'PERSONAL_CAR'
    utility_car = 'UTILITY_CAR'

    @classmethod
    def mapping(cls):
        return {
            'Véhicule particulier': cls.personal_car.value,
            'Véhicule utilitaire / société': cls.utility_car.value,
            'VP': cls.personal_car.value,
            'VUL': cls.utility_car.value,
            'vp': cls.personal_car.value,
            'ctte_vp': cls.personal_car.value,
            'VASP': cls.utility_car.value,
            'Véhicule spécialisé': cls.utility_car.value,
            'VU': cls.utility_car.value,
            'VP Standard': cls.personal_car.value,
            'VU Standard': cls.utility_car.value,
            "VU taxe à l'essieu": cls.utility_car.value,
            'Véhicule industriel': cls.utility_car.value,
            'Véhicule utilitaire': cls.utility_car.value,
            "AMBULANCE": cls.utility_car.value,
            "BICYCLE": cls.utility_car.value,
            "BUS": cls.utility_car.value,
            "BUS_DOUBLE_DECK": cls.utility_car.value,
            "CAR": cls.personal_car.value,
            "CAR_ESTATE": cls.personal_car.value,
            "CAR_SPORTS": cls.personal_car.value,
            "DIGGER": cls.utility_car.value,
            "DIGGER_2": cls.utility_car.value,
            "GRITTER": cls.utility_car.value,
            "HGV": cls.utility_car.value,
            "HORSEBOX": cls.utility_car.value,
            "MAN": cls.utility_car.value,
            "MINIBUS": cls.utility_car.value,
            "MIXER": cls.utility_car.value,
            "RIGID": cls.utility_car.value,
            "SWEEPER_LARGE": cls.utility_car.value,
            "SWEEPER_SMALL": cls.utility_car.value,
            "TIPPER": cls.utility_car.value,
            "TIPPER_2": cls.utility_car.value,
            "TRACTOR": cls.utility_car.value,
            "TRACTOR_TRAILER": cls.utility_car.value,
            "TRAILER": cls.utility_car.value,
            "VAN": cls.utility_car.value,
            "VAN_BOX": cls.utility_car.value,
            "VAN_SMALL": cls.utility_car.value,
            "WASTE_VEHICLE": cls.utility_car.value,
            "CHERRY_PICKER_HGV": cls.utility_car.value,
            "CHERRY_PICKER_LCV": cls.utility_car.value,
            "VAN_LCV": cls.utility_car.value,
            "POOL_CAR": cls.personal_car.value,
            "HEAVY_VAN_HGV": cls.utility_car.value,
            "TIPPER_MEDIUM": cls.utility_car.value,
        }


@unique
class VehicleStatus(Enum):
    active = 'ACTIVE'
    closed = 'CLOSED'
    awaiting = 'AWAITING'
    cancelled = 'CANCELLED'
    in_maintenance = 'IN_MAINTENANCE'

    @classmethod
    def mapping(cls):
        return {
            'A la route': cls.active.value,
            'Clos': cls.closed.value,
            'Sorti de parc': cls.closed.value,
            'En attente de livraison': cls.awaiting.value,
            'Annulé': cls.cancelled.value,
            'Annulée': cls.cancelled.value,
            'En parc': cls.active.value,
            'IN_CIRCULATION': cls.active.value,
            'SOLD': cls.closed.value,
        }


@unique
class EnergyTypes(Enum):
    gaz = 'GAZ'
    diesel = 'DIESEL'
    gaz_hybrid_no_recharge = 'GAZ_HYBRID_NO_RECHARGE'
    gaz_hybrid_recharge = 'GAZ_HYBRID_RECHARGE'
    electric = 'ELECTRIC'
    diesel_hybrid_no_recharge = 'DIESEL_HYBRID_NO_RECHARGE'
    diesel_hybrid_recharge = 'DIESEL_HYBRID_RECHARGE'
    gnc = 'COMPRESSED_GAZ'

    @classmethod
    def mapping(cls):
        gaz_no_recharge = 'Hybride essence-électricité non rechargeable (EH)'
        diez_no_recharge = 'Gazole-électricité (hybride non rechargeable) [GH]'
        gaz_recharge = 'Hybride Essence-électricité rechargeable (EE)'
        return {
            'Essence (ES)': cls.gaz.value,
            'Diesel (GO)': cls.diesel.value,
            gaz_no_recharge: cls.gaz_hybrid_no_recharge.value,
            gaz_recharge: cls.gaz_hybrid_recharge.value,
            diez_no_recharge: cls.diesel_hybrid_no_recharge.value,
            'Électricité (EL)': cls.electric.value,
            'Diesel': cls.diesel.value,
            'Essence': cls.gaz.value,
            'GO': cls.diesel.value,
            'ES': cls.gaz.value,
            'EE': cls.gaz_hybrid_recharge.value,
            'EH': cls.gaz_hybrid_no_recharge.value,
            'EL': cls.electric.value,
            'Mild Essence': cls.gaz_hybrid_no_recharge.value,  # SEAT
            'diesel': cls.diesel.value,
            'sans plomb 95': cls.gaz.value,
            'sans plomb 95\nélectrique': cls.gaz_hybrid_recharge.value,
            'Electrique': cls.electric.value,
            'Hybride essence rechargeable': cls.gaz_hybrid_recharge.value,
            'Hybride essence': cls.gaz_hybrid_no_recharge.value,
            'E85': cls.gaz.value
        }


@unique
class RoomTypes(Enum):
    single = 'SINGLE'
    double = 'DOUBLE'
    triple = 'TRIPLE'
    twin = 'TWIN'
    quadruple = 'QUADRUPLE'
    unknown = ''

    @classmethod
    def mapping(cls):
        return {
            'SGL': cls.single.value,
            'single': cls.single.value,
            'Single': cls.single.value,
            'CHAMBRE SINGLE': cls.single.value,
            'Simple': cls.single.value,
            'TWN': cls.twin.value,
            'Twin': cls.twin.value,
            'DBL': cls.double.value,
            'Chambre double': cls.double.value,
            'Double': cls.double.value,
            'TPL': cls.triple.value,
            'QDR': cls.quadruple.value,
            '1ROH': cls.unknown.value,
        }


@unique
class ExpenseStatus(Enum):
    approved = 'APPROVED'
    denied = 'DENIED'
    pending = 'PENDING'

    @classmethod
    def mapping(cls):
        return {
            'Approuvée': cls.approved.value,
            'Refusée': cls.denied.value,
            'En attente': cls.pending.value,
        }


@unique
class ExpenseType(Enum):
    parking = 'PARKING'
    fuel = 'FUEL'
    repairs = 'REPAIRS'
    maintenance = 'MAINTENANCE'
    taxi = 'TAXI'
    public_transportation = 'PUBLIC_TRANSPORTATION'
    train = 'TRAIN'
    plane = 'PLANE'
    mileage_allowance = 'PERSONAL_CAR'
    car_rental = 'CAR_RENTAL'
    tolls = 'TOLLS'
    hotel = 'HOTEL'
    light_transportation_rental = 'LIGHT_TRANSPORTATION_RENTAL'
    it = 'IT'
    food = 'FOOD'
    other = 'OTHER'
    office_supplies = 'OFFICE_SUPPLIES'
    phone = 'PHONE'
    trade_show = 'TRADE_SHOW'

    @classmethod
    def mapping(cls):
        return {
            'Avion': cls.plane.value,
            'Entretien/réparations véhicule': cls.maintenance.value,
            'Essence': cls.fuel.value,
            'Kilométrage du véhicule personnel': cls.mileage_allowance.value,
            'Location de voiture': cls.car_rental.value,
            'Péages': cls.tolls.value,
            'Taxi': cls.taxi.value,
            'Train': cls.taxi.value,
            'Transports publics': cls.public_transportation.value,
            'Stationnement': cls.parking.value,
            'METRO BUS': cls.public_transportation.value,
            'LAVAGE VEHICULE': cls.maintenance.value,
            'AVION': cls.plane.value,
            'CARBURANT': cls.fuel.value,
            'HOTEL': cls.hotel.value,
            'LOCATION VEHICULE': cls.car_rental.value,
            'INDEMN KM 0.42 €': cls.mileage_allowance.value,
            'PEAGE': cls.tolls.value,
            'LOCATION TROTINETTE/VELO': cls.light_transportation_rental.value,
            'ENTRETIEN (VEH.SOCIETE)': cls.maintenance.value,
            'PARKING': cls.parking.value,
            'TRAIN': cls.train.value,
            'TAXI': cls.taxi.value,
            'INDEMN KM': cls.mileage_allowance.value,
            'MOBILE ET EQUIPEMENT': cls.it.value,
            'Location Habitation': cls.hotel.value,
            'Petit-déjeuner en déplacement': cls.food.value,
            'Déjeuner collaborateurs': cls.food.value,
            'Petit-déjeuner clients': cls.food.value,
            'Frais de Repas': cls.food.value,
            'Journaux/Magazines/Livres': cls.other.value,
            'Hôtel': cls.hotel.value,
            'Divers': cls.other.value,
            'Taxe hôtelière': cls.hotel.value,
            'Boissons Alcoolisées (20%)': cls.food.value,
            'Matériel/équipement de bureau': cls.it.value,
            'Déjeuner en déplacement': cls.food.value,
            'Minibar': cls.food.value,
            'Cadeaux - personnel': cls.other.value,
            'Impression/Photocopie/Fournitures': cls.office_supplies.value,
            'Déjeuner clients': cls.food.value,
            'Fournitures de bureau/Logiciels': cls.it.value,
            'Petit-Déjeuner collaborateurs': cls.food.value,
            'Dîner en déplacement': cls.food.value,
            'Dîner collaborateurs': cls.food.value,
            'Dîner clients': cls.food.value,
            'Repas à emporter': cls.food.value,
            'Téléphone cellulaire': cls.phone.value,
            'Courrier/Expédition/Fret': cls.other.value,
            'Salons professionnels': cls.trade_show.value,
        }


@unique
class TravelServiceTypes(Enum):
    rental_car = 'RENTAL_CAR'
    insurance = 'INSURANCE'
    business_insurance = 'BUSINESS_INSURANCE'
    luggage = 'LUGGAGE'
    air_ticket = 'AIR_TICKET'
    rail_card = 'RAIL_CARD'
    low_cost_fees = 'LOW_COST_FEES'
    train_ticket = 'TRAIN_TICKET'
    hotels = 'HOTELS'
    low_cost_ticket = 'LOW_COST_TICKET'
    low_cost_card = 'LOW_COST_CARD'
    airline_penalty = 'AIRLINE_PENALTY'
    air_fee_europe = 'AIR_FEE_EUROPE'
    air_fee_world = 'AIR_FEE_WORLD'
    air_fee_national = 'AIR_FEE_NATIONAL'
    train_fee = 'TRAIN_FEE'
    hotel_fee = 'HOTEL_FEE'
    rental_car_fee = 'RENTAL_CAR_FEE'
    low_cost_fee_world = 'LOW_COST_FEE_WORLD'
    low_cost_fee_national = 'LOW_COST_FEE_NATIONAL'
    voucher_fee = 'VOUCHER_FEE'
    out_of_hours_fee = 'OUT_OF_HOURS_FEE'

    @classmethod
    def mapping(cls):
        presta = 'Prestations de service '
        return {
            'Location de voiture': cls.rental_car.value,
            'Assurance': cls.insurance.value,
            'Assurance affaires': cls.business_insurance.value,
            'Bagage': cls.luggage.value,
            'billet aérien': cls.air_ticket.value,
            'Ecard ferroviaire': cls.rail_card.value,
            'EMD LOWCOST': cls.low_cost_fees.value,
            'Ferroviaire': cls.train_ticket.value,
            'Hôtel': cls.hotels.value,
            'LOW COST': cls.low_cost_ticket.value,
            'LOW COST ECARD': cls.low_cost_card.value,
            'Pénalité compagnie': cls.airline_penalty.value,
            presta + 'air europe': cls.air_fee_europe.value,
            presta + 'air international': cls.air_fee_world.value,
            presta + 'air national': cls.air_fee_national.value,
            presta + 'ferroviaire': cls.train_fee.value,
            presta + 'hôtel': cls.hotel_fee.value,
            presta + 'location de voiture': cls.rental_car_fee.value,
            presta + 'low cost international': cls.low_cost_fee_world.value,
            presta + 'low cost national': cls.low_cost_fee_national.value,
            presta + 'sur avoir': cls.voucher_fee.value,
            'Réservation Hôtel': cls.hotels.value,
            'Frais H24': cls.out_of_hours_fee.value,
        }


@unique
class AssignmentType(Enum):
    company_vehicle = 'COMPANY_CAR'
    service_vehicle = 'SERVICE_VEHICLE'

    @classmethod
    def mapping(cls):
        return {
            'VEHICULE_FONCTION_SERVICE': cls.service_vehicle.value,
            "VEHICULE_FONCTION": cls.company_vehicle.value,
            "VEHICULE_SERVICE": cls.service_vehicle.value,
            "Véhicule entreprise": cls.company_vehicle.value,
        }


@unique
class BillType(Enum):
    debit = 'DEBIT'
    credit = 'CREDIT'

    @classmethod
    def mapping(cls):
        return {
            "FACTURE": cls.debit.value,
            "AVOIR": cls.credit.value,
        }


@unique
class MileageSourceType(Enum):
    collaborator = 'COLLABORATOR'
    provider = 'PROVIDER'

    @classmethod
    def mapping(cls):
        return {
            "COLLABORATEUR": cls.collaborator.value,
            "FOURNISSEUR": cls.provider.value,
        }


@unique
class ModelCategories(Enum):
    city = "CITY"
    sedan = "SEDAN"
    suv = "SUV"
    utility = 'UTILITY'
    other = 'OTHER'

    @classmethod
    def mapping(cls):
        """ Mapping from car models to ModelCategories
        Antipattern - we don't map model_categories directly to model categories.
        """
        return {
            Models.one08.value: cls.city.value,
            Models.five008.value: cls.suv.value,
            Models.two08.value: cls.city.value,
            Models.two008.value: cls.suv.value,
            Models.three08.value: cls.sedan.value,
            Models.three008.value: cls.suv.value,
            Models.five08.value: cls.sedan.value,
            Models.classA.value: cls.sedan.value,
            Models.classC.value: cls.sedan.value,
            Models.gla.value: cls.suv.value,
            Models.cla.value: cls.sedan.value,
            Models.glc.value: cls.suv.value,
            Models.gbl.value: cls.suv.value,
            Models.cooper.value: cls.city.value,
            Models.countryman.value: cls.suv.value,
            Models.clubman.value: cls.suv.value,
            Models.a1.value: cls.city.value,
            Models.a3.value: cls.sedan.value,
            Models.a4.value: cls.sedan.value,
            Models.a5.value: cls.sedan.value,
            Models.a6.value: cls.sedan.value,
            Models.q2.value: cls.suv.value,
            Models.q3.value: cls.suv.value,
            Models.x1.value: cls.suv.value,
            Models.x3.value: cls.suv.value,
            Models.x5.value: cls.suv.value,
            Models.serie1.value: cls.city.value,
            Models.serie2.value: cls.sedan.value,
            Models.serie3.value: cls.sedan.value,
            Models.series5.value: cls.sedan.value,
            Models.one18.value: cls.city.value,
            Models.two20.value: cls.sedan.value,
            Models.three30.value: cls.sedan.value,
            Models.three20.value: cls.sedan.value,
            Models.three16.value: cls.sedan.value,
            Models.c1.value: cls.city.value,
            Models.c3.value: cls.city.value,
            Models.cactus.value: cls.suv.value,
            Models.spacetourer.value: cls.suv.value,
            Models.c4.value: cls.sedan.value,
            Models.c5.value: cls.sedan.value,
            Models.picasso.value: cls.suv.value,
            Models.ds7.value: cls.suv.value,
            Models.galaxy.value: cls.suv.value,
            Models.kuga.value: cls.suv.value,
            Models.ecosport.value: cls.suv.value,
            Models.focus.value: cls.sedan.value,
            Models.smax.value: cls.suv.value,
            Models.fiesta.value: cls.city.value,
            Models.tipo.value: cls.sedan.value,
            Models.fivehundred.value: cls.city.value,
            Models.i_s.value: cls.sedan.value,
            Models.ux.value: cls.suv.value,
            Models.ct.value: cls.sedan.value,
            Models.insignia.value: cls.sedan.value,
            Models.corsa.value: cls.city.value,
            Models.grandland.value: cls.suv.value,
            Models.juke.value: cls.suv.value,
            Models.qashqai.value: cls.suv.value,
            Models.micra.value: cls.city.value,
            Models.clio.value: cls.city.value,
            Models.captur.value: cls.suv.value,
            Models.megane.value: cls.sedan.value,
            Models.talisman.value: cls.sedan.value,
            Models.scenic.value: cls.suv.value,
            Models.espace.value: cls.suv.value,
            Models.austral.value: cls.suv.value,
            Models.zoe.value: cls.city.value,
            Models.polo.value: cls.city.value,
            Models.golf.value: cls.sedan.value,
            Models.troc.value: cls.suv.value,
            Models.tiguan.value: cls.suv.value,
            Models.up.value: cls.city.value,
            Models.id4.value: cls.suv.value,
            Models.fabia.value: cls.city.value,
            Models.scala.value: cls.sedan.value,
            Models.kodiac.value: cls.suv.value,
            Models.octavia.value: cls.sedan.value,
            Models.enyak.value: cls.suv.value,
            Models.fortwo.value: cls.city.value,
            Models.forfour.value: cls.city.value,
            Models.leon.value: cls.sedan.value,
            Models.cupra.value: cls.sedan.value,
            Models.ateca.value: cls.suv.value,
            Models.arona.value: cls.city.value,
            Models.model_3.value: cls.sedan.value,
            Models.model_y.value: cls.suv.value,
            Models.aygo.value: cls.city.value,
            Models.yaris.value: cls.city.value,
            Models.chr.value: cls.suv.value,
            Models.rav4.value: cls.suv.value,
            Models.corolla.value: cls.sedan.value,
            Models.xe.value: cls.sedan.value,
            Models.fpace.value: cls.suv.value,
            Models.picanto.value: cls.city.value,
            Models.ceed.value: cls.sedan.value,
            Models.rio.value: cls.city.value,
            Models.xceed.value: cls.suv.value,
            Models.stonic.value: cls.suv.value,
            Models.niro.value: cls.suv.value,
            Models.sportage.value: cls.suv.value,
            Models.ev6.value: cls.suv.value,
            Models.s90.value: cls.sedan.value,
            Models.v60.value: cls.sedan.value,
            Models.v40.value: cls.sedan.value,
            Models.xc40.value: cls.suv.value,
            Models.xc60.value: cls.suv.value,
            Models.discovery.value: cls.suv.value,
            Models.evoque.value: cls.suv.value,
            Models.stelvio.value: cls.suv.value,
            Models.renegade.value: cls.suv.value,
            Models.d20.value: cls.city.value,
            Models.mg4.value: cls.city.value,
            Models.twingo.value: cls.city.value,
            Models.sprinter.value: cls.utility.value,
            Models.id3.value: cls.sedan.value,
            Models.c40.value: cls.suv.value,
            Models.nv200.value: cls.utility.value,
            Models.nv300.value: cls.utility.value,
            Models.midlum.value: cls.utility.value,
            Models.express_van.value: cls.utility.value,
            Models.xc90.value: cls.suv.value,
            Models.fjr1300.value: cls.other.value,
            Models.master.value: cls.utility.value,
            Models.vivaro.value: cls.utility.value,
            Models.kona.value: cls.suv.value,
            Models.boxer.value: cls.utility.value,
            Models.i4.value: cls.sedan.value,
            Models.eqc.value: cls.suv.value,
            Models.idbuzz.value: cls.utility.value,
            Models.jumper.value: cls.utility.value,
            Models.unknown.value: cls.other.value,
            Models.i30.value: cls.city.value,
            Models.kangoo.value: cls.utility.value,
            Models.proace.value: cls.utility.value,
            Models.tucson.value: cls.suv.value,
            Models.scudo.value: cls.utility.value,
            Models.citystar.value: cls.city.value,
            Models.zafira.value: cls.suv.value,
            Models.talento.value: cls.utility.value,
            Models.jumpy.value: cls.utility.value,
            Models.eqb.value: cls.suv.value,
            Models.mp3.value: cls.other.value,
            Models.berlingo.value: cls.utility.value,
            Models.doblo.value: cls.utility.value,
            Models.auris.value: cls.sedan.value,
            Models.transit.value: cls.utility.value,
            Models.q5.value: cls.suv.value,
            Models.deauville.value: cls.utility.value,
            Models.combo.value: cls.utility.value,
            Models.trafic.value: cls.utility.value,
            Models.xmax.value: cls.other.value,
            Models.ducato.value: cls.utility.value,
            Models.canter.value: cls.utility.value,
            Models.dyna.value: cls.utility.value,
            Models.partner.value: cls.utility.value,
            Models.TGM.value: cls.utility.value,
            Models.expert.value: cls.utility.value,
            Models.ioniq.value: cls.suv.value,
            Models.vito.value: cls.utility.value,
            Models.nx.value: cls.suv.value,
            Models.mokka.value: cls.suv.value,
            Models.crafter.value: cls.utility.value,
            Models.nt400.value: cls.utility.value,
            Models.daily.value: cls.utility.value,
            Models.mascott.value: cls.utility.value,
            Models.caddy.value: cls.utility.value,
            Models.transporter.value: cls.utility.value,
            Models.caravelle.value: cls.utility.value,
            Models.primastar.value: cls.utility.value,
            Models.ix1.value: cls.suv.value,
        }


@unique
class Models(Enum):
    # Peugeot
    one08 = "108"
    five008 = "5008"
    two08 = "208"
    two008 = "2008"
    three08 = "308"
    three008 = "3008"
    five08 = "508"
    boxer = 'BOXER'
    citystar = 'CITYSTAR'
    expert = 'EXPERT'
    partner = 'PARTNER'

    # Mercedes
    classA = "CLASSE A"
    classC = "CLASSE C"
    gla = "GLA"
    cla = "CLA"
    glc = 'GLC'
    gbl = 'GLB'
    sprinter = 'SPRINTER'
    vito = 'VITO'
    eqc = 'EQC'
    eqb = 'EQB'

    # Mini
    cooper = 'COOPER'
    countryman = "COUNTRYMAN"
    clubman = 'CLUBMAN'

    # Audi
    a1 = "A1"
    a3 = 'A3'
    a4 = 'A4'
    a5 = 'A5'
    a6 = 'A6'
    q2 = 'Q2'
    q3 = "Q3"
    q5 = 'Q5'

    # BMW
    i4 = 'I4'
    ix1 = 'IX1'
    x1 = "X1"
    x3 = 'X3'
    x5 = "X5"
    serie1 = 'SERIE 1'
    serie2 = 'SERIE 2'
    serie3 = 'SERIE 3'
    series5 = 'SERIE 5'
    one18 = '118'
    two20 = '220'
    three30 = '330'
    three20 = '320'
    three16 = '316'

    # Citroen
    c1 = "C1"
    c3 = "C3"
    cactus = "CACTUS"
    spacetourer = 'SPACETOURER'
    c4 = "C4"
    c5 = "C5"
    picasso = "PICASSO"
    jumpy = 'JUMPY'
    jumper = 'JUMPER'
    berlingo = 'BERLINGO'

    # DS
    ds7 = "DS7"

    # Ford
    galaxy = 'GALAXY'
    kuga = 'KUGA'
    ecosport = 'ECOSPORT'
    focus = 'FOCUS'
    smax = 'S-MAX'
    fiesta = 'FIESTA'
    transit = 'TRANSIT'

    # FIAT
    doblo = 'DOBLO'
    tipo = "TIPO"
    fivehundred = '500'
    ducato = 'DUCATO'
    talento = 'TALENTO'
    scudo = 'SCUDO'

    # LEXUS
    i_s = 'IS'
    ux = 'UX'
    ct = 'CT'
    nx = 'NX'

    # Opel
    combo = 'COMBO'
    insignia = "INSIGNIA"
    corsa = 'CORSA'
    grandland = 'GRANDLAND'
    zafira = 'ZAFIRA'
    vivaro = 'VIVARO'
    mokka = 'MOKKA'

    # MAN
    TGM = 'TGM'

    # Nissan
    juke = 'JUKE'
    qashqai = 'QASHQAI'
    micra = 'MICRA'
    nv200 = 'NV200'
    nv300 = 'NV300'
    nt400 = 'NT400'
    primastar = 'PRIMASTAR'

    # Renault
    twingo = 'TWINGO'
    clio = "CLIO"
    captur = 'CAPTUR'
    megane = 'MEGANE'
    talisman = 'TALISMAN'
    scenic = 'SCENIC'
    espace = 'ESPACE'
    austral = 'AUSTRAL'
    zoe = "ZOE"
    kangoo = 'KANGOO'
    midlum = 'MIDLUM'
    master = 'MASTER'
    deauville = 'DEAUVILLE'
    express_van = 'EXPRESS VAN'
    trafic = 'TRAFIC'
    mascott = 'MASCOTT'

    # Volkswagen
    polo = "POLO"
    golf = "GOLF"
    troc = "T-ROC"
    tiguan = "TIGUAN"
    up = "UP"
    id3 = 'ID 3'
    id4 = "ID.4"
    idbuzz = 'ID BUZZ'
    caravelle = 'CARAVELLE'
    caddy = 'CADDY'
    crafter = 'CRAFTER'
    transporter = 'TRANSPORTER (T6)'

    # Skoda
    fabia = "FABIA"
    scala = 'SCALA'
    kodiac = 'KODIAQ'
    octavia = 'OCTAVIA'
    enyak = 'ENYAK'

    # SMART
    fortwo = "FORTWO"
    forfour = "FORFOUR"

    # SEAT
    leon = "LEON"
    cupra = "CUPRA"
    ateca = "ATECA"
    arona = "ARONA"

    # Tesla
    model_3 = 'MODEL 3'
    model_y = 'MODEL Y'

    # Toyota
    aygo = "AYGO"
    yaris = "YARIS"
    chr = "C-HR"
    rav4 = 'RAV4'
    corolla = 'COROLLA'
    auris = 'AURIS'
    proace = 'PROACE'
    dyna = 'DYNA'

    # Jaguar
    xe = 'XE'
    fpace = 'F-PACE'

    # KIA
    picanto = 'PICANTO'
    ceed = 'CEED'
    rio = 'RIO'
    xceed = 'XCEED'
    stonic = 'STONIC'
    niro = 'NIRO'
    sportage = 'SPORTAGE'
    ev6 = 'EV6'

    # Volvo
    s90 = 'S90'
    v60 = 'V60'
    v40 = 'V40'
    xc40 = 'XC40'
    xc60 = 'XC60'
    xc90 = 'XC90'
    c40 = 'C40'

    # Land Rover / range rover
    discovery = 'DISCOVERY'
    evoque = 'EVOQUE'

    # Alfa Romeo
    stelvio = 'STELVIO'

    # Jeep
    renegade = 'RENEGADE'

    # Piaggo
    d20 = 'D20'

    # MG
    mg4 = "MG4"

    # Unknown
    unknown = 'UNKNOWN'

    # Yamaha
    fjr1300 = 'FJR 1300'
    xmax = 'X-MAX'

    # Hyundai
    i30 = 'I30'
    ioniq = 'IONIQ'
    kona = 'KONA'
    tucson = 'TUCSON'

    # Piaggio
    mp3 = 'MP3'

    # Mitsubishi
    canter = 'CANTER'

    # Iveco
    daily = 'DAILY'

    @classmethod
    def mapping(cls):
        return {
            "C3 AIRCROSS": cls.c3.value,
            "C5 AIRCROSS": cls.c5.value,
            "DS 7 CROSSBACK": cls.ds7.value,
            'DS7 CROSSBACK': cls.ds7.value,
            'COOPER S': cls.cooper.value,
            "TIPO": cls.tipo.value,
            "INSIGNIA SPORTS TOURER": cls.insignia.value,
            "X5 XDRIVE45E": cls.x5.value,
            "CUPRA LEON SP E-HYBRID180": cls.cupra.value,
            "GLA 250 E": cls.gla.value,
            "A1 SPORTBACK": cls.a1.value,
            "GOLF GTE": cls.golf.value,
            "SEAT ATECA": cls.ateca.value,
            "TOYOTA AYGO": cls.aygo.value,
            "UP": cls.up.value,
            "Q3": cls.q3.value,
            "CLIO": cls.clio.value,
            "SEAT LEON": cls.leon.value,
            "UP!": cls.up.value,
            "C 300 E": cls.classC.value,
            "COUNTRYMAN COOPER SE ALL4": cls.countryman.value,
            "PEUGEOT 5008 1.2 PURETECH 130 S&S GT LINE": cls.five008.value,
            "SKODA FABIA 1.0 TSI 95 DRIVE 125ANS": cls.fabia.value,
            "PEUGEOT 208 1.5 BLUEHDI 100 S&S ALLURE": cls.two08.value,
            "SEAT LEON 2.0 TDI 115 S&S STYLE BUSINESS": cls.leon.value,
            "PEUGEOT 208 1.2 PT 100 S&S AUTO ALLURE": cls.two08.value,
            "MINI COUNTRYMAN 1.5 COOPER SE ALL4 BUSI DESIGN HYBRID A": cls.countryman.value,
            'SERIE 2 GRAN TOURER': cls.serie2.value,
            'SERIE 3 TOURING': cls.serie3.value,
            'IS 300H': cls.i_s.value,
            'CLA COUPE': cls.cla.value,
            'COROLLA': cls.corolla.value,
            'LEXUS UX250H': cls.ux.value,
            'SERIE 3 BERLINE': cls.serie3.value,
            'SÉRIE 3 BERLINE': cls.serie3.value,
            'C4 CACTUS': cls.cactus.value,
            'CLASSE C BREAK': cls.classC.value,
            'CLA': cls.cla.value,
            '308 SW': cls.three08.value,
            'SERIE 2 ACTIVE TOURER': cls.serie2.value,
            '508 SW': cls.five08.value,
            'GRAND C4 PICASSO': cls.picasso.value,
            'GRAND SCÉNIC': cls.scenic.value,
            'CT 200H': cls.ct.value,
            'DS 7': cls.ds7.value,
            'MINI': cls.cooper.value,
            'KODIAC': cls.kodiac.value,
            'A5': cls.a5.value,
            'GRAND SCENIC': cls.scenic.value,
            'SÉRIE 3 TOURING': cls.serie3.value,
            'CLASSE A COMPACT': cls.classA.value,
            'SÉRIE 1': cls.serie1.value,
            'GRAND C4 SPACETOURER': cls.spacetourer.value,
            'RENEGADE': cls.renegade.value,
            'FIESTA': cls.fiesta.value,
            'C4 SPACETOURER': cls.spacetourer.value,
            '500X': cls.fivehundred.value,
            'OCTAVIA COMBI': cls.octavia.value,
            'Q3 SPORTBACK': cls.q3.value,
            'VOLKSWAGEN POLO': cls.polo.value,
            'VOLKSWAGEN T-ROC': cls.troc.value,
            'X3(3) FL 20IBUSDES4MBAJ19': cls.x3.value,
            'A3(3) FL 5P E150 BUSL BA': cls.a3.value,
            'GLA FL 220D BUSED 2M BA': cls.gla.value,
            '3008(2) FL E130 ACT PK BA': cls.three008.value,
            'DISCOVERY SPT TD150 EXEBA': cls.discovery.value,
            'MEGANE D110 BUSINESS EDC': cls.megane.value,
            'SPORTAGE5 H230 DESG 2M': cls.sportage.value,
            '330E(7) BK BUSDES': cls.three30.value,
            'GLC 250 FASC 4M BA': cls.glc.value,
            '308 D120 ACTIVE BUSINESS': cls.three08.value,
            '*MODEL 3 PERF 4M*BP': cls.model_3.value,
            '3008(2) E130 ALLBUSBAGRIP': cls.three008.value,
            '320I(7) BUSDES BA': cls.three20.value,
            'DS7 CRSBK BD130 BUS BA': cls.ds7.value,
            'X1 18D BUSINESS A 2M': cls.x1.value,
            '5008(2) E130 ALLBUS 7PJ19': cls.five008.value,
            'TIGUAN2 E150 CARA 2M BA5P': cls.tiguan.value,
            '5008(2) E130 ALL BUS 7PBA': cls.five008.value,
            '308(2) FL E130 ALL BUS BA': cls.three08.value,
            '508(2) BK E130 ALL PK BA': cls.five08.value,
            'A5 SPORTBACK D190': cls.a5.value,
            'RAV4 D143 DESIGN': cls.rav4.value,
            'X3 20D M SPORT A 4M': cls.x3.value,
            '308(2) FL BK E130ALLBUSBA': cls.three08.value,
            '220D M SPORT A GRAN TOURE': cls.two20.value,
            'TIGUAN2 D150 CFTBUS 2M BA': cls.tiguan.value,
            'A4(4) BK D150U SLIN BA': cls.a4.value,
            '308(2) FL BD120 ALL BUSBA': cls.three08.value,
            '220D SPORT A ACTIVE TOURE': cls.two20.value,
            '5008(2) E130ALLBUS7PBAJ19': cls.five008.value,
            'GRAND D120 BUSINESS + GRA': cls.d20.value,
            'A5 D190 S LINE QUATTRO S': cls.a5.value,
            '308(3) E130 ACT PK BA': cls.three08.value,
            'Q2 D116 SLIN 2M BA': cls.q2.value,
            '316D(6) FL BUSDES BA': cls.three20.value,
            'TIGUAN2 D190 CAREX 4MBA5P': cls.tiguan.value,
            '308 D150 FÉLINE': cls.three08.value,
            '330XI(7) BK LUX BA': cls.three30.value,
            'IS(3) FL 300H PK BUS': cls.i_s.value,
            '3008 D180 GT': cls.three008.value,
            'STELVIO D150 LUS 2M BAJ19': cls.stelvio.value,
            'V40 FL CC D2 [S] OVERSTA': cls.v40.value,
            'RAV4(5) H218 DYN BUS 2M': cls.rav4.value,
            '508(2) E180 ALL BUS BA': cls.five08.value,
            '508 D180 FÉLINE': cls.five08.value,
            '3008 BUSINESS NOUVEAU ALL': cls.three008.value,
            'Q3(2) E150 SLIN 2M BA': cls.q3.value,
            'Q3(2) E150 DESLUX 2M BA': cls.q3.value,
            '118D BUSINESS A': cls.one18.value,
            'SCENIC4 GDE160INITPARBA5P': cls.scenic.value,
            'DS7 CRSBK E180 PERFL BA': cls.ds7.value,
            'DS7 CRSBK BD130 EXE BA': cls.ds7.value,
            'C4 D120 MILLENIUM BUSINES': cls.c4.value,
            'DS7 CRSBK E225 GD CHIC BA': cls.ds7.value,
            'A(4) 180 BUSL BA': cls.a4.value,
            '3008(2) BD180 GTL BA': cls.three008.value,
            'Q2 E150 SPORT': cls.q2.value,
            'Q2 E150 BUSL 2M BA': cls.q2.value,
            'DS7 CRSBK E180 BUS BA': cls.ds7.value,
            'C(4) FL BK 300E BUSL': cls.c4.value,
            '308(2) FLBKE130BCACTBUSBA': cls.three08.value,
            'YARIS3 FL 100H FRANCE BUS': cls.yaris.value,
            '3008 D120 ALLURE BUSINESS': cls.three008.value,
            '208 FL E110 ALL BUS BA': cls.two08.value,
            'GLA2 200 AMGL 2M BA J20': cls.gla.value,
            '2008(2) E130 ACT PK BA': cls.two008.value,
            '308(2) FL BD130 ACTBUS BA': cls.three08.value,
            'MEGANE4 D110E BUS BA': cls.megane.value,
            'MEGANE4 E130E INT BA': cls.megane.value,
            'XC60 D220 SUMMUM GEARTRON': cls.xc60.value,
            'NIRO EV': cls.niro.value,
            'CLA SHOOTING BRAKE': cls.cla.value,
            'ENYAQ': cls.enyak.value,
            'CLASSE C BERLINE': cls.classC.value,
            'DIVERS VI': cls.unknown.value,
            'KANGOO EXPRESS': cls.kangoo.value,
            'YARIS CROSS': cls.yaris.value,
            'JUMPY': cls.jumpy.value,
            'COROLLA SW': cls.corolla.value,
            'GRAND KANGOO': cls.kangoo.value,
            'DIVERS RENAULT VU': cls.unknown.value,
            'RAV 4': cls.rav4.value,
            'IONIQ 5': cls.ioniq.value,
            'MÉGANE E-TECH': cls.megane.value,
            'E': cls.unknown.value,
            'MÉGANE': cls.megane.value,
            'KANGOO': cls.kangoo.value,
            'JUMPER': cls.jumper.value,
            'FIAT TIPO': cls.tipo.value,
            'SCÉNIC E-TECH': cls.scenic.value,
            'SCÉNIC': cls.scenic.value,
            'DIVERS PEUGEOT': cls.unknown.value,
            'CANTER CHASSIS CABINE': cls.canter.value,
            'ZAFIRA TOURER': cls.zafira.value,
            'DIVERS': cls.unknown.value,
            'BENNE': cls.unknown.value,
            'YARIS HYBRIDE': cls.yaris.value,
            'ID.BUZZ': cls.idbuzz.value,
            'TRANSIT': cls.transit.value,
            'Enyaq iV': cls.enyak.value,
            'Kangoo': cls.kangoo.value,
            'NX 300h': cls.nx.value,
            'Proace City Electric': cls.proace.value,
            'MOKKA X': cls.mokka.value,
            'CARAVELLE (T6)': cls.caravelle.value,
            'COOPER SE': cls.cooper.value,
            'DAILY (EURO 6) NGV': cls.daily.value,
            'CADDY': cls.caddy.value,
            'NT400 CABSTAR (KM)': cls.nt400.value,
            'UX 250H': cls.ux.value,
            'TRANSIT 2T': cls.transit.value,
            'E-NV200 EVALIA': cls.nv200.value,
            'TRANSPORTER (T6)': cls.transporter.value,
            'PROACE CITY ELECTRIC': cls.proace.value,
            'E-208': cls.two08.value,
            'ID.3': cls.id3.value,
            'NV200 EVALIA': cls.nv200.value,
            'NX 300H': cls.nx.value,
            'E-NV200 EVALIA (KM)': cls.nv200.value,
            'ID. BUZZ': cls.idbuzz.value,
            'ASSET OR OTHER VEHICLE': cls.unknown.value,
            'PROACE VERSO': cls.proace.value,
            'C40 ELECTRIC': cls.c40.value,
            'E-NIRO': cls.niro.value,
            'E-TRANSIT 2T': cls.transit.value,
            'TRANSIT/TOURNEO CUSTOM': cls.transit.value,
            'XC40 ELECTRIC': cls.xc40.value,
            'PROACE CITY': cls.proace.value,
            'AURIS TOURING SPORTS HYBRID (KM)': cls.auris.value,
            'FIESTA (MK7)': cls.fiesta.value,
            'LF - SÉRIE 3 (EURO 6)': cls.unknown.value,
            'C40 RECHARGE': cls.c40.value,
            'RELAY': cls.unknown.value,
            'ENYAQ IV': cls.enyak.value,
            'IX1 (U11)': cls.ix1.value,
        }


@unique
class Makes(Enum):
    audi = 'AUDI'
    bmw = 'BMW'
    citroen = 'CITROEN'
    ds = 'DS'
    fiat = 'FIAT'
    mercedes = 'MERCEDES'
    mini = 'MINI'
    opel = 'OPEL'
    peugeot = 'PEUGEOT'
    renault = 'RENAULT'
    seat = 'SEAT'
    smart = 'SMART'
    skoda = 'SKODA'
    toyota = 'TOYOTA'
    volkswagen = 'VOLKSWAGEN'
    land_rover = 'LAND ROVER'
    lexus = 'LEXUS'
    nissan = 'NISSAN'
    alfa_romeo = 'ALFA ROMEO'
    kia = 'KIA'
    jaguar = 'JAGUAR'
    jeep = 'JEEP'
    tesla = 'TESLA'
    volvo = 'VOLVO'
    ford = 'FORD'
    mg = 'MG'
    piaggio = 'PIAGGIO'
    mitsubishi = 'MITSUBISHI'
    yamaha = 'YAMAHA'
    hyundai = 'HYUNDAI'
    daf = 'DAF'
    honda = 'HONDA'
    unknown = 'UNKNOWN'
    man = 'MAN'
    iveco = 'IVECO'

    @classmethod
    def mapping(cls):
        return {
            "CITROËN": cls.citroen.value,
            "DS AUTOMOBILES": cls.ds.value,
            'MERCEDES BENZ': cls.mercedes.value,
            'SEAT LEON': cls.seat.value,
            'VOLKSWAGEN POLO': cls.volkswagen.value,
            'VOLKSWAGEN T-ROC': cls.volkswagen.value,
            'DIVERS': cls.unknown.value,
            'OPEL / VAUXHALL': cls.opel.value,
            'DAF TRUCKS': cls.daf.value,
            'MERCEDES-BENZ': cls.mercedes.value,
            'STANDARD': cls.unknown.value,
        }


@unique
class GazStationType(Enum):
    company_operated = 'COMPANY_OPERATED'
    dealer_operated = 'DEALER_OPERATED'  # And company owned
    dealer_owned = 'DEALER_OWNED'

    @classmethod
    def mapping(cls):
        return {
            "CoDo": cls.dealer_operated,
        }


@unique
class SynchronizationTypes(Enum):
    manual = 'MANUAL'
    csv_upload = 'CSV_UPLOAD'
    edi = 'EDI'
    api = 'API'


@unique
class SynchronizationStatus(Enum):
    error = 'ERROR'
    ok = 'OK'
    ongoing = 'ONGOING'
