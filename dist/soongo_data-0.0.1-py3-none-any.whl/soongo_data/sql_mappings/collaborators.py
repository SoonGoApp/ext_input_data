""" Collaborators table definition and association tables
"""
from sqlalchemy import Column, String, UUID, func, TIMESTAMP, ForeignKey

from .base import Base


class CollaboratorsTable(Base):
    __tablename__ = 'collaborators'
    __table_args__ = {'schema': 'publ'}
    id = Column(
        UUID,
        primary_key=True,
        nullable=False,
        server_default=func.uuid_generate_v4()
    )
    firstname = Column(
        String,
    )
    lastname = Column(
        String,
    )
    email = Column(
        String,
    )
    phone = Column(
        String,
    )
    role = Column(
        String,
    )
    work_location = Column(
        String,
    )
    organization_collaborator_id = Column(
        String,
    )
    organization_collaborator_category = Column(
        String,
    )
    organization_id = Column(
        UUID,
        ForeignKey('publ.organizations.id', ondelete="CASCADE")
    )
    business_unit_id = Column(
        UUID,
    )
    region_id = Column(
        UUID,
    )
    collaborator_id = Column(
        String,
    )
    created_at = Column(
        TIMESTAMP(timezone=True),
    )
    updated_at = Column(
        TIMESTAMP(timezone=True),
    )
    synchronisation_id = Column(
        UUID,
        ForeignKey('publ.synchronisations.id', ondelete='cascade'),
    )
