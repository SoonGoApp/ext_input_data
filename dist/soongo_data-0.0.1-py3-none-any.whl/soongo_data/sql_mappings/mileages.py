""" Mileages table definition and association tables """

from sqlalchemy import (
    Column, Integer, func, UUID, TIMESTAMP, ForeignKey, Float
)

from .base import Base


class MileagesTable(Base):
    __tablename__ = 'mileages'
    __table_args__ = {'schema': 'publ'}

    id = Column(
        UUID,
        primary_key=True,
        server_default=func.uuid_generate_v4(),
    )
    organization_id = Column(
        UUID,
        ForeignKey('publ.organizations.id', ondelete='cascade'),
    )
    vehicle_id = Column(
        UUID,
        ForeignKey('publ.vehicles.id', ondelete='cascade'),
    )
    mileage = Column(Integer, nullable=False)
    mileage_date = Column(TIMESTAMP)
    synchronisation_id = Column(
        UUID,
        ForeignKey('publ.synchronisations.id', ondelete='cascade'),
    )


class MileagesDiffTable(Base):
    __tablename__ = 'mileage_diff_days_diff'
    __table_args__ = {'schema': 'publ'}

    id = Column(
        UUID,
        ForeignKey('publ.mileages.id', ondelete='cascade'),
        primary_key=True,
        server_default=func.uuid_generate_v4(),
    )
    organization_id = Column(
        UUID,
        ForeignKey('publ.organizations.id', ondelete='cascade'),
    )
    vehicle_id = Column(
        UUID,
        ForeignKey('publ.vehicles.id', ondelete='cascade'),
    )
    mileage = Column(Integer, nullable=False)
    mileage_date = Column(TIMESTAMP)
    mileage_diff = Column(Float)
    days_diff = Column(Float)
