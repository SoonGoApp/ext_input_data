from sqlalchemy import Column, Text, ForeignKey, DateTime, func, UUID
from sqlalchemy.schema import UniqueConstraint, Index

from .base import Base


class BusinessUnits(Base):
    __tablename__ = 'organization_business_units'
    __table_args__ = (
        UniqueConstraint(
            'name',
            'organization_id',
            'parent_id',
            name='organization_business_units_name_organization_id_parent_id_key',
        ),
        Index('organization_business_units_created_at_idx', 'created_at'),
        Index(
            'organization_business_units_organization_id_idx',
            'organization_id'
        ),
        Index(
            'organization_business_units_original_synchronisation_id_idx',
            'original_synchronisation_id',
        ),
        Index('organization_business_units_parent_id_idx', 'parent_id'),
        Index('organization_business_units_updated_at_idx', 'updated_at'),
        {'schema': 'publ'}
    )

    id = Column(
        UUID,
        primary_key=True,
        server_default=func.uuid_generate_v4(),
        nullable=False,
    )
    name = Column(
        Text,
        nullable=False,
    )
    organization_id = Column(
        UUID,
        ForeignKey('publ.organizations.id'),
        nullable=False,
    )
    parent_id = Column(
        UUID,
        ForeignKey('publ.organization_business_units.id'),
        nullable=True,
    )
    created_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )
    updated_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )
    original_synchronisation_id = Column(
        UUID,
        ForeignKey('publ.synchronisations.id'),
        nullable=True,
    )
