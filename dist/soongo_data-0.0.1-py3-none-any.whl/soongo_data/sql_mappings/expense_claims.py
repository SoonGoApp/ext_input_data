from sqlalchemy import Column, String, Float, func, UUID, TIMESTAMP, ForeignKey

from .base import Base


# Define a table model with the specified columns
class ExpenseClaimsTable(Base):
    __tablename__ = 'expense_claims'
    __table_args__ = {'schema': 'publ'}

    id = Column(
        UUID,
        primary_key=True,
        server_default=func.uuid_generate_v4(),
    )
    expense_date = Column(TIMESTAMP, nullable=False)
    organization_id = Column(
        UUID,
        ForeignKey('publ.organizations.id', ondelete='cascade'),
    )
    collaborator_id = Column(
        UUID,
        ForeignKey('publ.collaborators.id', ondelete='cascade'),
    )
    currency = Column(String, nullable=False)
    expense_type = Column(String)
    net_amount = Column(Float)
    amount_tax_exc = Column(Float)
    deductible_vat = Column(Float)
    synchronisation_id = Column(
        UUID,
        ForeignKey('publ.synchronisations.id', ondelete='cascade'),
    )
