from sqlalchemy import Column, Text, ForeignKey, DateTime, func, UUID
from sqlalchemy.schema import Index

from .base import Base


class VehicleManufacturersTable(Base):
    __tablename__ = 'vehicle_manufacturers'
    __table_args__ = (
        Index('vehicle_manufacturers_created_at_idx', 'created_at'),
        Index('vehicle_manufacturers_name_idx', 'name'),
        Index('vehicle_manufacturers_organization_id_idx', 'organization_id'),
        Index('vehicle_manufacturers_original_synchronisation_id_idx', 'original_synchronisation_id'),
        Index('vehicle_manufacturers_updated_at_idx', 'updated_at'),
        {'schema': 'publ'}
    )

    id = Column(UUID, primary_key=True, server_default=func.uuid_generate_v4(), nullable=False)
    name = Column(Text, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    organization_id = Column(UUID, ForeignKey('publ.organizations.id', ondelete='CASCADE'), nullable=False)
    original_synchronisation_id = Column(UUID, ForeignKey('publ.synchronisations.id'), nullable=True)


class VehicleBrandsTable(Base):
    __tablename__ = 'vehicle_brands'
    __table_args__ = (
        Index('vehicle_brands_created_at_idx', 'created_at'),
        Index('vehicle_brands_id_idx', 'id'),
        Index('vehicle_brands_manufacturer_id_idx', 'manufacturer_id'),
        Index('vehicle_brands_name_idx', 'name'),
        Index('vehicle_brands_organization_id_idx', 'organization_id'),
        Index('vehicle_brands_original_synchronisation_id_idx', 'original_synchronisation_id'),
        Index('vehicle_brands_updated_at_idx', 'updated_at'),
        {'schema': 'publ'}
    )

    id = Column(UUID, primary_key=True, server_default=func.uuid_generate_v4(), nullable=False)
    name = Column(Text, nullable=False)
    manufacturer_id = Column(
        UUID,
        ForeignKey('publ.vehicle_manufacturers.id', ondelete='CASCADE'),
        nullable=True,
    )
    created_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )
    updated_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )
    organization_id = Column(
        UUID,
        ForeignKey('publ.organizations.id', ondelete='CASCADE'),
        nullable=False,
    )
    original_synchronisation_id = Column(
        UUID,
        ForeignKey('publ.synchronisations.id'),
        nullable=True,
    )


class VehicleModelsTable(Base):
    __tablename__ = 'vehicle_models'
    __table_args__ = (
        Index('vehicle_models_brand_id_idx', 'brand_id'),
        Index('vehicle_models_created_at_idx', 'created_at'),
        Index('vehicle_models_id_idx', 'id'),
        Index('vehicle_models_name_idx', 'name'),
        Index('vehicle_models_organization_id_idx', 'organization_id'),
        Index('vehicle_models_original_synchronisation_id_idx', 'original_synchronisation_id'),
        Index('vehicle_models_updated_at_idx', 'updated_at'),
        {'schema': 'publ'}
    )

    id = Column(
        UUID,
        primary_key=True,
        server_default=func.uuid_generate_v4(),
        nullable=False,
    )
    name = Column(Text, nullable=False)
    brand_id = Column(UUID, ForeignKey('publ.brands.id'))
    created_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )
    updated_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )
    organization_id = Column(UUID, nullable=False)
    original_synchronisation_id = Column(
        UUID,
        ForeignKey('publ.synchronisations.id'),
        nullable=True,
    )


class VehicleTrimsTable(Base):
    __tablename__ = 'vehicle_trims'
    __table_args__ = (
        Index('vehicle_trims_created_at_idx', 'created_at'),
        Index('vehicle_trims_id_idx', 'id'),
        Index('vehicle_trims_model_id_idx', 'model_id'),
        Index('vehicle_trims_name_idx', 'name'),
        Index('vehicle_trims_organization_id_idx', 'organization_id'),
        Index('vehicle_trims_original_synchronisation_id_idx', 'original_synchronisation_id'),
        Index('vehicle_trims_updated_at_idx', 'updated_at'),
        {'schema': 'publ'}
    )

    id = Column(
        UUID,
        primary_key=True,
        server_default=func.uuid_generate_v4(),
        nullable=False,
    )
    name = Column(Text, nullable=True)
    model_id = Column(
        UUID,
        ForeignKey('publ.vehicle_models.id', ondelete='SET NULL'),
        nullable=True,
    )
    created_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )
    updated_at = Column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )
    organization_id = Column(
        UUID,
        ForeignKey('publ.organizations.id', ondelete='CASCADE'),
        nullable=False,
    )
    original_synchronisation_id = Column(
        UUID,
        ForeignKey('publ.synchronisations.id'),
        nullable=True,
    )
