""" Module declaring the database to map tables onto
"""
from sqlalchemy.ext.declarative import declarative_base

# Create a metadata object
Base = declarative_base()
