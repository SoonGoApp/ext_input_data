""" Expenses table definition and association tables"""

from sqlalchemy import Column, Text, Float, func, UUID, TIMESTAMP, ForeignKey

from .base import Base


# Define a table model with the specified columns
class ExpensesTable(Base):
    __tablename__ = 'expenses'
    __table_args__ = {'schema': 'publ'}

    id = Column(
        UUID,
        primary_key=True,
        server_default=func.uuid_generate_v4(),
    )
    organization_id = Column(
        UUID,
        ForeignKey('publ.organizations.id', ondelete='cascade'),
        nullable=False,
    )
    internal_reference = Column(Text, nullable=False)
    supplier = Column(Text)
    billing_date = Column(TIMESTAMP)
    amount_tax_exc = Column(Float)
    vehicle_id = Column(
        UUID,
        ForeignKey('publ.vehicles.id', ondelete='cascade'),
    )
    vat_value = Column(Float)
    deductible_vat = Column(Float)
    collaborator_id = Column(
        UUID,
        ForeignKey('publ.collaborators.id', ondelete='cascade'),
    )
    business_unit_id = Column(UUID)
    soongo_category = Column(Text)
    net_amount = Column(Float)
    quantity = Column(Float)
    synchronisation_id = Column(
        UUID,
        ForeignKey('publ.synchronisations.id', ondelete='cascade'),
    )
