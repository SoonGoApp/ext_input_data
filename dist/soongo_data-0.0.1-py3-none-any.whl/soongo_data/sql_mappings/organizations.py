from sqlalchemy import Column, Text, func, UUID, TIMESTAMP

from .base import Base


# Define a table model with the specified columns
class OrganizationsTable(Base):
    __tablename__ = 'organizations'
    __table_args__ = {'schema': 'publ'}

    id = Column(
        UUID,
        primary_key=True,
        server_default=func.gen_random_uuid(),
    )
    slug = Column(
        Text,
        nullable=False,
    )
    name = Column(
        Text,
        nullable=False,
    )
    logo_url = Column(Text)
    created_at = Column(
        TIMESTAMP(timezone=True),
        nullable=False,
        server_default=func.now(),
    )
    updated_at = Column(
        TIMESTAMP(timezone=True),
        nullable=False,
        server_default=func.now(),
    )
