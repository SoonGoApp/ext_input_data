"""
Define the accident table mapping and related tables
"""
from sqlalchemy import (
    Column, Text, Boolean, DateTime, Float, func, UUID, ForeignKey
)

from .base import Base


class AccidentsTable(Base):
    __tablename__ = 'accidents'
    __table_args__ = {'schema': 'publ'}

    id = Column(
        UUID,
        primary_key=True,
        server_default=func.uuid_generate_v4(),
    )
    organization_id = Column(
        UUID,
        ForeignKey('publ.organizations.id', ondelete='cascade'),
        nullable=False,
    )
    accident_date = Column(DateTime, nullable=False)
    accident_ref = Column(Text)
    vehicle_id = Column(
        UUID,
        ForeignKey('publ.vehicles.id', ondelete='cascade'),
    )
    accident_type = Column(Text)
    context = Column(Text)
    responsibility = Column(Text)
    third_party = Column(Boolean)
    insurer = Column(Text)
    collaborator_id = Column(
        UUID,
        ForeignKey('publ.collaborators.id', ondelete='cascade'),
    )
    business_unit_id = Column(UUID)
    cost_insurer = Column(Float, nullable=False)
    cost_self_insurance = Column(Float, nullable=False)
    cost_deductible = Column(Float, nullable=False)
    status = Column(Text)
    was_commute = Column(Boolean)
    weekend_accident = Column(Boolean)
    accident_location = Column(Text)
    synchronisation_id = Column(
        UUID,
        ForeignKey('publ.synchronisations.id', ondelete='cascade'),
    )
