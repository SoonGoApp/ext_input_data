"""
Define the attribution mapping and related tables
"""
from sqlalchemy import (
    Column, Text, Boolean, func, JSON, UUID, TIMESTAMP
)

from .base import Base


class KpisTable(Base):
    __tablename__ = 'kpis'
    __table_args__ = {'schema': 'publ'}

    id = Column(
        UUID,
        primary_key=True,
        server_default=func.uuid_generate_v4(),
    )
    display_name = Column(
        Text,
        nullable=False,
    )
    description = Column(Text)
    is_active = Column(
        Boolean,
        nullable=False,
        server_default='false',
    )
    unit = Column(Text)
    kpi_category_id = Column(UUID, nullable=False)
    formula = Column(
        JSON,
        nullable=False,
        server_default='{"left": {"type": "constant-primitive", "value": 1}}'
    )
    created_at = Column(
        TIMESTAMP(timezone=True),
        nullable=False,
        server_default=func.now(),
    )
    updated_at = Column(
        TIMESTAMP(timezone=True),
        nullable=False,
        server_default=func.now(),
    )
    bundled_kpi = Column(Boolean, server_default='false')
