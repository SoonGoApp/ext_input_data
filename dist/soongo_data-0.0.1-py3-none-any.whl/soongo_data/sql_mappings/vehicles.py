""" Vehicles table definition and association tables """

from sqlalchemy import (
    Column, Text, UUID, func, TIMESTAMP, Float, Date, Integer, Boolean,
    ForeignKey, case
)

from .base import Base


class VehiclesTable(Base):
    __tablename__ = 'vehicles'
    __table_args__ = {'schema': 'publ'}
    id = Column(
        UUID,
        primary_key=True,
        nullable=False,
        server_default=func.uuid_generate_v4()
    )
    plate_number = Column(
        Text,
        nullable=False,
    )
    organization_id = Column(
        UUID,
        ForeignKey('publ.organization.id', ondelete='cascade'),
        nullable=False,
    )
    trim_id = Column(UUID)
    model_id = Column(UUID)
    brand_id = Column(UUID)
    manufacturer_id = Column(UUID)
    co2_per_km = Column(Float)
    co2_production = Column(Float)
    co2_recycling = Column(Float)
    energy = Column(Text)
    manufacturer_price_tax_exc = Column(Float)
    rebate_rate = Column(Float)
    rebate_price = Column(Float)
    order_reference = Column(Text, nullable=False)
    lease_start_date = Column(Date)
    lease_end_date = Column(Date)
    vehicle_status = Column(Text)
    lease_months = Column(Integer)
    lease_mileage = Column(Integer)
    vehicle_age = Column(Integer)
    supplier = Column(Text)
    initial_mileage = Column(Integer)
    mileage = Column(Integer)
    mileage_update = Column(TIMESTAMP)
    fiscal_power = Column(Integer)
    fiscal_type = Column(Text)
    is_air_quality_certified = Column(Boolean)
    seat_count = Column(Integer)
    business_unit_id = Column(UUID)
    theoretical_fuel_consumption = Column(Float)
    created_at = Column(
        TIMESTAMP(timezone=True),
        nullable=False,
        server_default=func.now(),
    )
    updated_at = Column(
        TIMESTAMP(timezone=True),
        nullable=False,
        server_default=func.now(),
    )
    contract_type = Column(Text)
    entry_into_service_date = Column(Date)
    assignment_type = Column(Text)


def spread_co2_prod(mileage_col):
    return case(
        (mileage_col < 50000, mileage_col / 100000),
        (mileage_col < 100000, mileage_col / 200000 + 0.25),
        (mileage_col < 200000, mileage_col / 400000 + 0.5),
        (mileage_col >= 200000, 1),
    )


def spread_co2_recycling(mileage_col):
    return case(
        (mileage_col < 100000, mileage_col / 400000),
        (mileage_col < 150000, mileage_col / 200000 - 0.25),
        (mileage_col < 200000, mileage_col / 100000 - 1),
        (mileage_col >= 200000, 1),
    )
