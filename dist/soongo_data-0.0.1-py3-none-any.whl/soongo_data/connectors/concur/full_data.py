""" Concur Data

Class loading, normalizing and organizing all Concur Datasets for a given
organization
"""
import os
import typing
from enum import Enum, unique

from data_models import (
    BusinessUnitsModel, CollaboratorsModel, ClaimsModel
)
from utils.logging import gen_logger
from utils.dataset import Dataset, add_connector
from utils.type import convert_names
from utils.enums import SynchronizationTypes


@unique
class ConcurAnalyticsTable(Enum):
    expense_claims = 'EXPENSE_CLAIMS'
    mileage_allowance = 'MILEAGE_ALLOWANCE'


@add_connector
class ConcurData(Dataset):
    SOURCE_CONNECTOR = 'CONCUR'
    NAME = 'CONCUR'
    TYPE = SynchronizationTypes.csv_upload.value

    def __init__(
        self,
        folder: str,
        organization_name: str,
        log_file: typing.Optional[str] = None,
    ) -> None:
        """ Instantiates HavasData object containing all the Havas tables

        :param folder: str path to the root folder where all the data is
            stored.
        :param log_file: file where to write logs

        :raises ValueError: if folder is not a valid path or does not
        contain all required subfolders
        """
        super().__init__(
            folder=folder,
            logger=gen_logger(
                name=self.__class__.__name__,
                file_path=log_file,
            ),
            source_connector=self.SOURCE_CONNECTOR,
            name=self.NAME,
            type=self.TYPE,
            organization_name=organization_name,
        )
        if not os.path.isdir(os.path.expanduser(folder)):
            self.logger.error(
                'Provided root folder %s is not a valid directory',
                folder,
            )

        self.load_table(
            file_path=os.path.join(
                self.folder,
                'General Reporting NdF.xlsx',
            ),
            col_lst=[
                BusinessUnitsModel.entity_1.return_variant(
                    raw_name=(
                        'Unité organisationnelle du collaborateur 2 : nom'
                    ),
                ),
                BusinessUnitsModel.entity_ref,
                CollaboratorsModel.employee_full_name.return_variant(
                    post_processing=convert_names(self.organization_name),
                ),
                CollaboratorsModel.organization_employee_id.return_variant(
                    raw_name='Identifiant collaborateur',
                ),
                ClaimsModel.submission_date,
                ClaimsModel.payment_date,
                ClaimsModel.approbation_status,
                ClaimsModel.claim_name,
                ClaimsModel.claim_ref,
                ClaimsModel.expense_date,
                ClaimsModel.amount_tax_inc.return_variant(
                    raw_name='Montant approuvé (ndf)',
                ),
                ClaimsModel.currency,
                ClaimsModel.expense_type,
            ],
            skip_cols=[
                'Total(Approved Amount (rpt))',
                'Total(Approved Amount (rpt)).1',
            ],
            record_dates=[
                ClaimsModel.submission_date.name,
                ClaimsModel.payment_date.name,
                ClaimsModel.expense_date.name,
            ],
            source_table=ConcurAnalyticsTable.expense_claims.value,
            sheet_name=0,
        )
        self.import_mileage_allowance()

    def import_mileage_allowance(self):
        allowance_df = self.load_table(
            file_path=os.path.join(
                self.folder,
                'IK - Excessive Personal Car Mileage V2.xlsx',
            ),
            col_lst=[
                CollaboratorsModel.employee_full_name.return_variant(
                    raw_name='Collaborateur',
                    post_processing=convert_names(self.organization_name),
                ),
                ClaimsModel.claim_ref,
                ClaimsModel.expense_type,
                ClaimsModel.expense_date,
                ClaimsModel.professional_mileage,
                ClaimsModel.currency.return_variant(
                    raw_name='Devise de remboursement',
                ),
                ClaimsModel.amount_tax_inc.return_variant(
                    raw_name='Montant approuvé',
                ),
            ],
            record_dates=[
                ClaimsModel.expense_date.name,
            ],
            source_table=ConcurAnalyticsTable.mileage_allowance.value,
            skip_cols=['Nom des critères du tarif']
        )

        setattr(
            self,
            ConcurAnalyticsTable.mileage_allowance.value,
            allowance_df
        )
        return allowance_df


if __name__ == '__main__':
    org_name = 'Quartus'
    data = ConcurData(
        folder=f'/home/matthieuglotz/Documents/Data/{org_name}/CONCUR',
        organization_name=org_name,
    )
    i = 0
    for df in data:
        df.to_csv(f'~/dev/temp/concur_{i}.csv', index=False, sep=";")
        i += 1
        print(df)
