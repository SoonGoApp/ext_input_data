""" Masternaut Data

Class loading, normalizing and organizing all Masternaut Datasets for a given
organization
"""
import os
import typing
import datetime
from enum import Enum, unique
from functools import cached_property

import requests
import requests.auth
import pandas as pd

from data_models import (
    VehiclesModel, CollaboratorsModel, BusinessUnitsModel,
    MileageReportsModel, SoonGoRecordsModel
)
from utils.logging import gen_logger
from utils.dataset import Dataset, add_connector, load_from_api
from utils.enums import (
    EnergyTypes, Models, mapper_factory, SynchronizationTypes
)
from utils.type import convert_string, convert_names
from utils.api import get_api_secret


@unique
class MasternautTables(Enum):
    collaborators = 'COLLABORATORS'
    vehicles = 'VEHICLES'
    associations = 'ASSOCIATIONS'


@add_connector
class MasternautData(Dataset):
    SOURCE_CONNECTOR = 'MASTERNAUT'
    NAME = 'MASTERNAUT'
    TYPE = SynchronizationTypes.api.value

    def __init__(
        self,
        folder: str,
        organization_name: str,
        log_file: typing.Optional[str] = None,
    ) -> None:
        """ Instantiates MasternautData object containing fleet data from
            Masternaut

        :param folder: str path to the root folder where all the data is
            stored.
        :param log_file: file where to write logs
        """
        logger = gen_logger(
            name=self.__class__.__name__,
            file_path=log_file,
        )
        super().__init__(
            folder=folder,
            logger=logger,
            source_connector=self.SOURCE_CONNECTOR,
            name=self.NAME,
            type=self.TYPE,
            organization_name=organization_name,
        )
        if not os.path.isdir(os.path.expanduser(folder)):
            self.logger.error(
                'Provided root folder %s is not a valid directory',
                folder,
            )
        api_creds = get_api_secret(
            organization_name=organization_name,
            connector_name=self.NAME,
            logger=logger,
        )
        self.auth = requests.auth.HTTPBasicAuth(
            api_creds['username'],
            api_creds['pwd'],
        )
        self.masternaut_api_ids = api_creds['ids']
        self.load_collaborators
        self.load_vehicles
        #  self.load_latest_vehicle_journey TODO: handle call limit

    @cached_property
    def load_vehicles(self):
        base_url = (
            'https://api.masternautconnect.com/connect-webservices/services/'
            'public/v1/customer/'
        )

        df_lst = []
        for customer_id in self.masternaut_api_ids:
            vehicle_df = load_from_api(
                organization_name=self.organization_name,
                url=f'{base_url}{customer_id}/vehicle',
                auth=self.auth,
                response_keys=['items'],
                col_lst=[
                    VehiclesModel.plate_number.return_variant(
                        raw_name='registration',
                    ),
                    VehiclesModel.vehicle_id_ext_connector,
                    VehiclesModel.fiscal_type.return_variant(
                        raw_name='type',
                    ),
                    MileageReportsModel.mileage.return_variant(
                        raw_name='odometerValue',
                    ),
                    VehiclesModel.make.return_variant(
                        raw_name='make',
                    ),
                    VehiclesModel.model.return_variant(
                        raw_name='model',
                        post_processing=convert_upper,  # Deactivate mapping to process it after
                    ),
                    VehiclesModel.vehicle_status.return_variant(
                        raw_name='status',
                    ),
                    VehiclesModel.motor_energy_type,
                    VehiclesModel.motor_fuels,
                    MileageReportsModel.mileage_date.return_variant(
                        raw_name='odometerLastModified',
                        post_processing=convert_iso_date,
                    )
                ],
                skip_cols=[
                    'name',
                    'groupId',
                    'groupName',
                    'idlingFidelity',
                    'engineTotalHours',
                    'engineTotalHoursType',
                    'assetTypeGroup',
                    'featureTags',
                    'engineTotalHoursLastModified',
                    'tags',
                    'defaultDriverId',
                    'odometerType',
                ],
                record_dates=[
                    MileageReportsModel.mileage_date.name,
                ],
                source_connector=self.SOURCE_CONNECTOR,
                source_dataset=self.NAME,
                synchronization_type=self.TYPE,
                source_table=MasternautTables.vehicles.value,
            )
            vehicle_df[SoonGoRecordsModel.ext_api_id.name] = customer_id
            df_lst.append(vehicle_df)

        vehicle_df = pd.concat(df_lst, axis=0)
        vehicle_df[VehiclesModel.energy.name] = ''
        for fuel_val, energy_val, energy_cat in [
            ("['DIESEL']", "ICE", EnergyTypes.diesel.value),
            ("['DIESEL']", "HEV", EnergyTypes.diesel_hybrid_no_recharge.value),
            ("['DIESEL']", "PHEV", EnergyTypes.diesel_hybrid_recharge.value),

            ("['PETROL']", "ICE", EnergyTypes.gaz.value),
            ("['PETROL']", "HEV", EnergyTypes.gaz_hybrid_no_recharge.value),
            ("['PETROL']", "PHEV", EnergyTypes.gaz_hybrid_recharge.value),

            ("['ELECTRIC', 'PETROL']", "PHEV", EnergyTypes.gaz_hybrid_recharge.value),
            ("['ELECTRIC', 'PETROL']", "HEV", EnergyTypes.gaz_hybrid_no_recharge.value),

            ("['ELECTRIC']", "EV", EnergyTypes.electric.value),

            ("['METHANE']", "CNG", EnergyTypes.gnc.value),
        ]:
            vehicle_df[VehiclesModel.energy.name] = (
                vehicle_df[VehiclesModel.energy.name].mask(
                    (vehicle_df[VehiclesModel.motor_fuels.name] == fuel_val)
                    &
                    (vehicle_df[VehiclesModel.motor_energy_type.name] == energy_val),
                    energy_cat
                )
            )
        vehicle_df[VehiclesModel.model.name] = (
            vehicle_df[VehiclesModel.model.name].mask(
                # Masternaut adds add info after ' - ' not relevant for model
                # However a number of lexus models are named LF - XXX
                vehicle_df[VehiclesModel.model.name].str.contains(' - ') &
                ~vehicle_df[VehiclesModel.model.name].str.contains('LF - '),
                vehicle_df[VehiclesModel.model.name].str.split(' - ').str[0],
            )
        )
        vehicle_df[VehiclesModel.model.name] = mapper_factory(Models)(
            vehicle_df[VehiclesModel.model.name]
        )

        for date_col in [
            MileageReportsModel.mileage_date.name,
            SoonGoRecordsModel.record_date.name,
        ]:
            vehicle_df[date_col] = vehicle_df[date_col].fillna(
                pd.Timestamp(datetime.date.today())
            )

        vehicle_df.drop(
            [
                VehiclesModel.motor_fuels.name,
                VehiclesModel.motor_energy_type.name,
            ],
            axis=1,
        )
        setattr(
            self,
            MasternautTables.vehicles.value,
            vehicle_df
        )
        return vehicle_df

    @cached_property
    def load_collaborators(self):
        base_url = (
            'https://api.masternautconnect.com/connect-webservices/services/'
            'public/v1/customer/'
        )
        collaborators_df = self.agg_from_api(
            url_lst=[
                f'{base_url}{customer_id}/driver'
                for customer_id in self.masternaut_api_ids
            ],
            auth=self.auth,
            response_keys=['items'],
            parallelize=False,  # Too few query, multiprocessing inefficient
            col_lst=[
                CollaboratorsModel.employee_full_name.return_variant(
                    raw_name='name',
                    post_processing=convert_names(self.organization_name)
                ),
                BusinessUnitsModel.entity_3.return_variant(
                    raw_name='groupName',
                ),
                CollaboratorsModel.employee_entry_date.return_variant(
                    raw_name='activeDate',
                    post_processing=convert_iso_date,
                )
            ],
            skip_cols=[
                'customerId',
                'active',
                'groupId',
                'tempVehicleNextJourneyOnly',
                'tempPrivateMode',
                'tempPrivateModeNextJourneyOnly',
                'keys',
                'tags',
                'defaultVehicleId',
                'timezoneId',
                'id',
            ],
            record_dates=[
                CollaboratorsModel.employee_entry_date.name,
            ],
            source_table=MasternautTables.collaborators.value,
        )

        return collaborators_df

    @cached_property
    def load_latest_vehicle_journey(self):
        base_url = (
            'https://api.masternautconnect.com/connect-webservices/services/'
            'public/v1/customer/'
        )

        df_lst = []
        for customer_id in self.masternaut_api_ids:

            # a 400 is returned if one attemps to query a vehicle_id
            # which does not exist for that customer id
            vehicle_ids = self.load_vehicles.loc[
                self.load_vehicles[SoonGoRecordsModel.ext_api_id.name] == customer_id,
                VehiclesModel.vehicle_id_ext_connector.name,
            ].unique()

            df_lst.append(
                self.agg_from_api(
                    url_lst=[
                        f'{base_url}{customer_id}/tracking/history/vehicle/latest',
                    ],
                    params_tup=[
                        {
                            'fromDateTime': str(
                                datetime.date.today() -
                                datetime.timedelta(days=1)
                            ),
                            'vehicleId': id,
                        }
                        for id in vehicle_ids
                    ],
                    auth=self.auth,
                    response_keys=['items'],
                    col_lst=[
                        CollaboratorsModel.employee_full_name.return_variant(
                            raw_name='driverName',
                            post_processing=convert_names(
                                self.organization_name
                            ),
                        ),
                        VehiclesModel.plate_number.return_variant(
                            raw_name='vehicleRegistration',
                        ),
                    ],
                    skip_cols=[
                        'processedDateTime',
                        'totalCount',
                        'items',
                        'vehicleId',
                        'vehicleName',
                        'vehicleGroupName',
                        'driverId',
                        'driverGroupName',
                        'eventDate',
                        'eventStatus',
                        'longitude',
                        'latitude',
                        'formattedAddress',
                        'locationId',
                        'locationName',
                        'locationCategory',
                        'speed',
                        'inputId',
                        'inputLabel',
                        'inputState',
                        'customInputLabel',
                        'customInputState',
                        'cumulativeRuntime',
                        'cumulativeRuntimeType',
                        'cumulativeDistance',
                        'cumulativeFuelUsage',
                        'cumulativeIdleTime',
                        'cumulativePtoTime',
                        'fuelLevelLitres',
                        'heading',
                        'electricBatteryLevelPercent',
                        'electricBatteryLevelPercentEstimated',
                        'electricRangeKm',
                        'electricRangeKmEstimated',
                        'fuelLevelPercentage',
                        'fuelLevelLitres',
                    ],
                    record_dates=[
                    ],
                    source_table=MasternautTables.associations.value,
                )
            )
        associations_df = pd.concat(df_lst, axis=0).drop_duplicates()
        setattr(
            self,
            MasternautTables.associations.value,
            associations_df
        )
        return associations_df


def convert_iso_date(date_series: pd.Series) -> pd.Series:
    return pd.to_datetime(date_series, format="ISO8601")


def convert_upper(str_series: pd.Series) -> pd.Series:
    return convert_string(str_series).str.upper()


if __name__ == '__main__':
    masternaut_data = MasternautData(
        folder='/home/matthieuglotz/Documents/Data/Acorus/MASTERNAUT',
        organization_name='Acorus',
    )
    i = 0
    for df in masternaut_data:
        df.to_csv(f'~/dev/temp/masternaut{i}.csv')
        i += 1
        print(df)
