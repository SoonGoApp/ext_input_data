""" Flease Data

Class loading, normalizing and organizing all datasets from the Flease
connector
"""
import os
import re
import typing
from enum import Enum, unique

import pandas as pd

from data_models import (
    CollaboratorsModel, VehicleAssociationsModel, TaxesModel, VehiclesModel,
    VehicleContractsModel, ExpensesModel, BusinessUnitsModel,
    MileageReportsModel
)
from utils.dataset import (
    Dataset, add_connector, parser_factory, PDFParsingParams, get_record_date
)
from utils.logging import gen_logger
from utils.type import convert_string, convert_numeric, convert_date
from utils.enums import (
    FiscalType, EnergyTypes, CostCategory, SynchronizationTypes
)


@unique
class FleaseTables(Enum):
    vehicles = 'VEHICLES'
    taxes = 'CONTRACTS'
    expenses = 'EXPENSES'


@add_connector
class FleaseData(Dataset):
    SOURCE_CONNECTOR = 'FLEASE'
    NAME = 'FLEASE'
    TYPE = SynchronizationTypes.csv_upload.value

    def __init__(
        self,
        folder: str,
        taxes_check_dict: dict,
        expenses_check_dict: dict,
        organization_name: str,
        log_file: typing.Optional[str] = None,
    ) -> None:
        """ Instantiates a Dataset from the exports received from Athlon

        :param folder: str path to the root folder where all the data is
            stored.
        :param log_file: file where to write logs

        :raises ValueError: if folder is not a valid path or does not
        contain all required subfolders
        """
        logger = gen_logger(
            name=self.__class__.__name__,
            file_path=log_file,
        )
        super().__init__(
            folder=folder,
            logger=logger,
            source_connector=self.SOURCE_CONNECTOR,
            name=self.NAME,
            type=self.TYPE,
            organization_name=organization_name,
        )
        if not os.path.isdir(os.path.expanduser(folder)):
            logger.error(
                'Provided root folder %s is not a valid directory',
                folder,
            )
        self.agg_pdf(
            eligible_files=[
                os.path.join(
                    self.folder,
                    'DOMINO HR.pdf',
                ),
                os.path.join(
                    self.folder,
                    'DOMINO PRESTATIONS & FORMATION.pdf',
                ),
            ],
            check_len_dict=taxes_check_dict,
            read_param_lst=[{}],
            param_lst=[[
                PDFParsingParams(
                    cols=[VehiclesModel.plate_number],
                    match_func=parser_factory(
                        r'([A-Z]{2}-\d{3}-[A-Z]{2})'
                    ),
                    scope='line',
                ),
                PDFParsingParams(
                    cols=[
                        TaxesModel.ikb_period_start,
                        TaxesModel.ikb_period_end,
                    ],
                    match_func=parser_factory(
                        r'Période : (\d{2}/\d{2}/\d{4}) - (\d{2}/\d{2}/\d{4})'
                    ),
                    scope='line',
                ),
                PDFParsingParams(
                    cols=[
                        VehiclesModel.make,
                        VehiclesModel.entry_into_fleet_date,
                        VehiclesModel.theoretical_CO2_per_km,
                        VehiclesModel.energy,
                        VehiclesModel.rebate_price_ttc.return_variant(
                            post_processing=convert_numeric,
                        ),
                        VehicleContractsModel.total_rent_ttc,
                        VehiclesModel.fiscal_type.return_variant(
                            post_processing=convert_fiscal_type,
                        ),
                    ],
                    match_func=vehicle_line_parser,
                    scope='line',
                ),
                PDFParsingParams(
                    cols=[
                        TaxesModel.ikb_current,
                        TaxesModel.declared_non_deductible_amortization,
                        TaxesModel.tax_CO2_emission,
                        TaxesModel.tax_pollutant,
                    ],
                    match_func=tax_line_parser,
                    scope='line',
                )
            ]],
            record_dates=[TaxesModel.ikb_period_start.name],
            source_table=FleaseTables.taxes.value,
        )
        self.import_expenses(expenses_check_dict)
        self.import_vehicles()

    def import_vehicles(self):
        self.load_table(
            file_path=os.path.join(
                self.folder,
                "export_flease_flotte_2024-08-08.xlsx",
            ),
            col_lst=[
                VehiclesModel.plate_number.return_variant(
                    raw_name='Immatriculation',
                ),
                VehiclesModel.entry_into_fleet_date.return_variant(
                    raw_name="Date d'entrée en parc",
                ),
                VehiclesModel.exit_from_fleet_date.return_variant(
                    raw_name="Date de sortie de parc",
                ),
                CollaboratorsModel.employee_first_name.return_variant(
                    raw_name="Prénom",
                ),
                CollaboratorsModel.employee_last_name.return_variant(
                    raw_name="Nom",
                ),
                VehicleAssociationsModel.association_start_date.return_variant(
                    raw_name="Date de début d'affectation",
                ),
                VehicleAssociationsModel.association_end_date.return_variant(
                    raw_name="Date de fin d'affectation",
                ),
                BusinessUnitsModel.entity_1.return_variant(
                    raw_name="Business Unit",
                ),
                VehiclesModel.make.return_variant(
                    raw_name='Marque',
                ),
                VehiclesModel.model.return_variant(
                    raw_name='Modèle',
                ),
                VehiclesModel.energy.return_variant(
                    raw_name='Énergie',
                ),
                VehiclesModel.theoretical_CO2_per_km.return_variant(
                    raw_name='Taux CO2',
                ),
                VehiclesModel.rebate_price_ht.return_variant(
                    raw_name="Prix d'achat véhicule (HT)",
                ),
                MileageReportsModel.mileage_date.return_variant(
                    raw_name="Date du dernier kilométrage connu",
                ),
                MileageReportsModel.mileage.return_variant(
                    raw_name="Dernier kilométrage connu",
                ),
                MileageReportsModel.kilometers_driven.return_variant(
                    raw_name="Kilométrage consommé",
                ),
                VehiclesModel.registration_date.return_variant(
                    raw_name="Date de 1ère immatriculation",
                ),
                VehicleContractsModel.contract_reference.return_variant(
                    raw_name="N° de contrat",
                ),
                VehicleContractsModel.lease_start_date.return_variant(
                    raw_name="Date de début du contrat",
                ),
                VehicleContractsModel.lease_end_date.return_variant(
                    raw_name="Date de fin du contrat",
                ),
                VehicleContractsModel.lease_months.return_variant(
                    raw_name="Durée du contrat",
                ),
                VehicleContractsModel.lease_mileage.return_variant(
                    raw_name="Kilométrage contrat",
                ),
                VehicleContractsModel.financial_rent_ht.return_variant(
                    raw_name="Loyer financier (HT)",
                ),
                VehicleContractsModel.insurance_rent_ttc.return_variant(
                    raw_name="Loyer assurance",
                ),
                VehicleContractsModel.other_rent_ht.return_variant(
                    raw_name="Loyer options (HT)",
                ),
                VehicleContractsModel.total_rent_ht.return_variant(
                    raw_name="Loyer total (HT)",
                ),
            ],
            skip_cols=[
                'Date de sortie de parc estimée',
            ],
            record_dates=[
                VehicleContractsModel.lease_start_date.name,
                VehiclesModel.entry_into_fleet_date.name,
                MileageReportsModel.mileage_date.name,
            ],
            source_table=FleaseTables.vehicles.value,
        )

    def import_expenses(self, expenses_check_dict: dict):
        expense_df = self.agg_pdf(
            eligible_files=[
                os.path.join(self.folder, file_name)
                for file_name in os.listdir(self.folder)
                if re.match(r'Facture LPF-\d{4}-\d{2}-\d{4,5}\.pdf', file_name)
            ],
            read_param_lst=[{}, {}, {}],
            check_len_dict=expenses_check_dict,
            param_lst=[
                # Format 1
                [
                    PDFParsingParams(
                        cols=[
                            ExpensesModel.billing_date.return_variant(
                                overwrite='preserve',
                                memorization='doc',
                            ),
                        ],
                        match_func=parser_factory(
                            r"(\d{2}/\d{2}/\d{4})"
                        ),
                        scope='page',
                    ),
                    PDFParsingParams(
                        cols=[
                            VehicleContractsModel.contract_reference.return_variant(
                                overwrite='preserve',
                                memorization='doc',
                            ),
                        ],
                        match_func=parser_factory(
                            r'.*Contrat n°(\S+).*'
                        ),
                        scope='page',
                    ),
                    PDFParsingParams(
                        cols=[
                            VehiclesModel.make.return_variant(
                                overwrite='preserve',
                                memorization='doc',
                            ),
                            VehiclesModel.model.return_variant(
                                overwrite='preserve',
                                memorization='doc',
                            ),
                            VehiclesModel.plate_number.return_variant(
                                overwrite='preserve',
                                memorization='doc',
                            ),
                        ],
                        match_func=parser_factory(
                            r'\n([A-Z]+)\s(\S+) - \S{17} - '
                            r'([A-Z]{2}-\d{3}-[A-Z]{2})\n'
                        ),
                        scope='page',
                    ),
                    PDFParsingParams(
                        cols=[
                            ExpensesModel.billing_start_date.return_variant(
                                overwrite='preserve',
                                memorization='doc',
                                post_processing=convert_date_day_first,
                            ),
                            ExpensesModel.billing_end_date.return_variant(
                                overwrite='preserve',
                                memorization='doc',
                                post_processing=convert_date_day_first,
                            ),
                        ],
                        match_func=parser_factory(
                            r'\nPériode du (\d{2}/\d{2}/\d{4}) au '
                            r'(\d{2}/\d{2}/\d{4})\n'
                        ),
                        scope='page',
                    ),
                    PDFParsingParams(
                        cols=[
                            ExpensesModel.product,
                            ExpensesModel.quantity.return_variant(
                                post_processing=convert_numeric,
                            ),
                            ExpensesModel.unit_price.return_variant(
                                post_processing=convert_numeric,
                            ),
                            ExpensesModel.vat_rate,
                            ExpensesModel.amount_tax_exc.return_variant(
                                post_processing=convert_numeric,
                            ),
                        ],
                        match_func=parser_factory(
                            r'^(Loyer mensuel de LLD \(Financier, '
                            r'Assistance, Entretien\)|Livraison) '
                            r'(\d+(?:,\d{1,2})?) (?:mois|unité) '
                            r'(\d+(?:,\d{1,2})?) (?:€|¬) '
                            r'(\d{1,2}(?:,\d{1,2})?)% '
                            r'(\d+(?:,\d{1,2})?) (?:€|¬)$'
                        ),
                        scope='line',
                    ),
                ],
                # Format 2 e.g. Facture LPF-2023-05-4179.pdf
                [
                    PDFParsingParams(
                        cols=[
                            ExpensesModel.billing_date.return_variant(
                                overwrite='preserve',
                                memorization='doc',
                            )
                        ],
                        match_func=parser_factory(
                            r"(?:Date d'émission )?"
                            r"(\d{2}(?:\/\d{2}\/| [a-z]+\.? )\d{4}).*"
                        ),
                        scope='page',
                    ),
                    PDFParsingParams(
                        cols=[
                            ExpensesModel.product,
                            ExpensesModel.quantity.return_variant(
                                post_processing=convert_numeric,
                            ),
                            ExpensesModel.unit_price.return_variant(
                                post_processing=convert_numeric,
                            ),
                            ExpensesModel.vat_rate,
                            ExpensesModel.amount_tax_exc.return_variant(
                                post_processing=convert_numeric,
                            ),
                        ],
                        match_func=parser_factory(
                            r'^(Loyer mensuel de LLD \(Financier, '
                            r'Assistance, Entretien\)|Livraison) '
                            r'(\d+(?:,\d{1,2})?) (?:mois|unité) '
                            r'(\d+(?:,\d{1,2})?) (?:€|¬) '
                            r'(\d{1,2}(?:,\d{1,2})?)% '
                            r'(\d+(?:,\d{1,2})?) (?:€|¬)$'
                        ),
                        scope='line',
                    ),
                    PDFParsingParams(
                        cols=[
                            VehiclesModel.make,
                            VehiclesModel.model,
                            VehiclesModel.plate_number,
                        ],
                        match_func=parser_factory(
                            r'^([A-Z]+)\s(\S+) - \S{17} - '
                            r'([A-Z]{2}-\d{3}-[A-Z]{2})$'
                        ),
                        scope='line',
                    ),
                    PDFParsingParams(
                        cols=[VehicleContractsModel.contract_reference],
                        match_func=parser_factory(
                            r'^Contrat n°(\S+) - Facturation \S+'
                        ),
                        scope='line',
                    ),
                ],
                # Format 3 e.g. Facture LPF-2024-07-10376.pdf
                [
                    PDFParsingParams(
                        cols=[
                            ExpensesModel.billing_date.return_variant(
                                overwrite='preserve',
                                memorization='doc',
                            )
                        ],
                        match_func=parser_factory(
                            r"(?:Date d'émission )?"
                            r"(\d{2}(?:\/\d{2}\/| [a-z]+\.? )\d{4}).*"
                        ),
                        scope='page',
                    ),
                    PDFParsingParams(
                        cols=[
                            ExpensesModel.product,
                            ExpensesModel.quantity.return_variant(
                                post_processing=convert_numeric,
                            ),
                            ExpensesModel.unit_price.return_variant(
                                post_processing=convert_numeric,
                            ),
                            ExpensesModel.vat_rate.return_variant(
                                post_processing=convert_vat_rate,
                            ),
                            ExpensesModel.amount_tax_exc.return_variant(
                                post_processing=convert_numeric,
                            ),
                        ],
                        match_func=parser_factory(
                            r'^(Refacturation FPS|Frais de gestion) '
                            r'(\d+(?:,\d{1,2})?) (?:mois|unité) '
                            r'(\d+(?:,\d{1,2})?) (?:€|¬) '
                            r'(\d{1,2}(?:,\d{1,2})?|Aucune)%? '
                            r'(\d+(?:,\d{1,2})?) (?:€|¬)$'
                        ),
                        scope='line',
                    ),
                    PDFParsingParams(
                        cols=[
                            VehiclesModel.model.return_variant(
                                memorization='doc',
                                overwrite='allow',
                            ),
                            VehiclesModel.make.return_variant(
                                memorization='doc',
                                overwrite='allow',
                            ),
                            VehiclesModel.plate_number.return_variant(
                                memorization='doc',
                                overwrite='allow',
                            ),
                        ],
                        match_func=parser_factory(
                            r'^Forfait de Post-Stationnement - ((\S+).*) '
                            r'([A-Z]{2}-\d{3}-[A-Z]{2})$'
                        ),
                        scope='line',
                    ),
                    PDFParsingParams(
                        cols=[
                            VehicleContractsModel.contract_reference.return_variant(
                                memorization='doc',
                                overwrite='allow',
                            )
                        ],
                        match_func=parser_factory(
                            r'^Contrat n°(\S+)$'
                        ),
                        scope='line',
                    ),
                ],
            ],
            record_dates=[
                ExpensesModel.billing_date.name,
            ],
            source_table=FleaseTables.expenses.value,
        )
        expense_df = self.categorize(expense_df)
        expense_df = get_record_date(
            data_df=expense_df,
            record_dates=[
                ExpensesModel.billing_date.name,
                ExpensesModel.billing_start_date.name,
                ExpensesModel.billing_end_date.name,
            ],
        )
        setattr(
            self,
            FleaseTables.expenses.value,
            expense_df
        )
        return expense_df

    @staticmethod
    def categorize(expense_df: pd.DataFrame) -> pd.DataFrame:
        """ Categorize expense transactions assigning them a SoonGo Category.

        :param expense_df: expense dataframe with a product column

        :returns: df with an expense_category column
        """
        expense_df[ExpensesModel.expense_category.name] = (
            expense_df[ExpensesModel.product.name].map(
                {
                    'Loyer mensuel de LLD (Financier, Assistance, Entretien)': CostCategory.financial_rent.value,
                    'Livraison': CostCategory.real_repairs.value,
                    'Refacturation FPS': CostCategory.fines.value,
                    'Frais de gestion': CostCategory.real_others.value,
                }
            )
        )
        missing_categories = pd.isna(expense_df[ExpensesModel.expense_category.name])
        if missing_categories.any():
            missed_products = expense_df.loc[
                missing_categories,
                ExpensesModel.product.name,
            ].unique()
            raise ValueError(
                f'Missing category for products {missed_products}'
            )
        return expense_df


def convert_date_day_first(series: pd.Series) -> pd.Series:
    return convert_date(series, date_format=r'%d/%m/%Y')


def convert_vat_rate(series: pd.Series) -> pd.Series:
    return convert_numeric(
        series.str.replace('Aucune', '0')
    )


def convert_fiscal_type(series: pd.Series) -> pd.Series:
    return convert_string(
        series.map(
            {
                'Non': FiscalType.personal_car.value,
                'Oui': FiscalType.utility_car.value,
            }
        )
    )


def vehicle_line_parser(line) -> typing.Optional[typing.List]:
    """ Parse line containing vehicle information in the Taxe PDF

    :param line: line of the pdf converted to text

    :return: list of elements with vehicle col info
    """

    if 'g/km' in line:
        line = line.replace(
            'Mild Essence',
            EnergyTypes.mapping()['Mild Essence'],  # The space breaks
        )
        return [
            element.replace('€', '')
            for element in line.split()
            if element != 'g/km'
        ]


def tax_line_parser(line) -> typing.Optional[typing.List]:
    """ Parse line containing taxe information in the Taxe PDF

    :param line: line of the pdf converted to text

    :return list of elements with taxes col info
    """

    if ('€' in line) and not ('g/km' in line):
        return [
            element.replace('€', '') for element in line.split()
        ]


if __name__ == '__main__':
    import yaml

    organisation_name = 'Domino'
    connector_name = 'FLEASE'
    config_file = os.path.join(
        os.path.dirname(
            os.path.dirname(
                os.path.realpath(__file__)
            )
        ),
        'connector_config.yaml',
    )

    with open(config_file) as config_path:
        connector_params = yaml.safe_load(
            config_path
        )[organisation_name][connector_name]

    flease_data = FleaseData(
        folder=os.path.join(
            '/home/matthieuglotz/Documents/Data/',
            organisation_name,
            connector_name,
        ),
        organization_name=organisation_name,
        **connector_params,
    )
    i = 0
    for df in flease_data:
        df.to_csv(f'~/dev/temp/check_flease_{i}.csv')
        i += 1
        print(df)
