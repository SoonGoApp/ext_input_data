""" Notilus Data

Class loading, normalizing and organizing all Notilus Datasets for a given
organization
"""
import logging
import os
import re
import typing
from enum import Enum, unique

import numpy as np
import pandas as pd

from data_models import (
    VehiclesModel, VehicleContractsModel, VehicleAssociationsModel,
    ExpensesModel, ClaimsModel, BusinessUnitsModel, CollaboratorsModel,
    VehicleReportsModel, MileageReportsModel, TaxesModel, FinesModel,
    SoonGoRecordsModel
)
from utils.logging import gen_logger
from utils.type import (
    convert_numeric, convert_plate, str_is_nan, convert_names, convert_date
)
from utils.dataset import (
    Dataset, add_connector, get_latest_file, get_record_date
)
from utils.extrapolation import (
    fill_expense_gaps, extrapolate_expense_from_rents
)
from utils.enums import (
    CostCategory, AssignmentType, FuelTypes, SynchronizationTypes
)


@unique
class NotilusTables(Enum):
    expenses = 'EXPENSES'
    anomalous_expenses = 'ANOMALOUS_EXPENSES'
    ext_expenses = 'EXT_EXPENSES'
    co2_tax = 'CO2_TAX'
    age_tax = 'AGE_TAX'
    collaborators = 'COLLABORATORS'
    mileage = 'MILEAGE'
    fines = 'FINES'
    vehicles = 'VEHICLES'
    expense_claims = 'EXPENSE_CLAIMS'
    associations = 'ASSOCIATIONS'


@add_connector
class NotilusData(Dataset):
    SOURCE_CONNECTOR = 'NOTILUS'
    NAME = 'NOTILUS'
    TYPE = SynchronizationTypes.csv_upload.value

    def __init__(
        self,
        folder: str,
        organization_name: str,
        supplier_lst: typing.List[str],
        log_file: typing.Optional[str] = None,
    ) -> None:
        """ Instantiates GreenNCapData object containing carbon data from
        GreenNCap

        :param folder: str path to the root folder where all the data is
            stored.
        :param log_file: file where to write logs

        :raises ValueError: if folder is not a valid path or does not
        contain all required subfolders
        """
        logger = gen_logger(
            name=self.__class__.__name__,
            file_path=log_file,
        )
        super().__init__(
            folder=folder,
            logger=logger,
            source_connector=self.SOURCE_CONNECTOR,
            name=self.NAME,
            type=self.TYPE,
            organization_name=organization_name,
        )
        if not os.path.isdir(os.path.expanduser(folder)):
            self.logger.error(
                'Provided root folder %s is not a valid directory',
                folder,
            )
        self.import_expense_table()
        self.import_anomalous_expense_table()
        self.import_vehicles_data(
            folder=folder,
            source_table=NotilusTables.vehicles.value,
        )
        self.import_collaborators_table()
        self.import_vehicle_age_table()
        self.import_co2_tax_table()
        self.extrapolate_expense_table(supplier_lst)
        self.load_table(
            file_path=get_latest_file(
                self.folder,
                re.compile(r'Relevé de compteur_\d{8}_\d{6}\.xlsx'),
            ),
            col_lst=[
                VehiclesModel.plate_number.return_variant(
                    raw_name='Véhicule > Immatriculation',
                    post_processing=convert_plate,
                ),
                VehiclesModel.make.return_variant(
                    raw_name='Véhicule > Modèle > Marque > Libellé',
                ),
                VehiclesModel.model.return_variant(
                    raw_name='Véhicule > Modèle > Libellé',
                ),
                MileageReportsModel.mileage_date.return_variant(
                    raw_name='Date du relevé',
                ),
                MileageReportsModel.mileage.return_variant(
                    raw_name='Compteur',
                ),
                MileageReportsModel.mileage_source_type,
            ],
            skip_cols=['Valeur de référence'],
            record_dates=[MileageReportsModel.mileage_date.name],
            source_table=NotilusTables.mileage.value,
        )
        self.load_table(
            file_path=get_latest_file(
                self.folder,
                re.compile(r'Affectation_\d{8}_\d{6}\.xlsx'),
            ),
            col_lst=[
                CollaboratorsModel.organization_employee_id.return_variant(
                    raw_name=(
                        'Véhicule > Données calculées > Collaborateur affecté'
                        ' > Matricule'
                    ),
                ),
                CollaboratorsModel.employee_last_name.return_variant(
                    raw_name=(
                        'Véhicule > Données calculées > Collaborateur affecté '
                        '> Nom'
                    )
                ),
                CollaboratorsModel.employee_first_name.return_variant(
                    raw_name=(
                        'Véhicule > Données calculées > Collaborateur affecté '
                        '> Prénom'
                    )
                ),
                VehiclesModel.plate_number.return_variant(
                    raw_name=(
                        'Véhicule > Immatriculation'
                    ),
                    post_processing=convert_plate,
                ),
                VehiclesModel.fiscal_type.return_variant(
                    raw_name='Véhicule > Genre > Libellé',
                ),
                VehicleAssociationsModel.association_start_date.return_variant(
                    raw_name='Date de début',
                ),
                VehicleAssociationsModel.association_end_date.return_variant(
                    raw_name='Date de fin',
                ),
                BusinessUnitsModel.cost_center.return_variant(
                    raw_name='Véhicule > Société > Libellé'
                ),
                VehiclesModel.make.return_variant(
                    raw_name='Véhicule > Modèle > Marque > Référence'
                ),
                VehiclesModel.model.return_variant(
                    raw_name='Véhicule > Modèle > Référence'
                ),
                VehiclesModel.entry_into_service_date.return_variant(
                    raw_name='Véhicule > Date de mise en circulation'
                ),
                VehiclesModel.fiscal_power.return_variant(
                    raw_name='Véhicule > Puissance fiscale',
                )
            ],
            skip_cols=[
                'Véhicule > Modèle > Marque > Libellé',
                'Véhicule > Modèle > Libellé',
                'Véhicule > Type de véhicule',
            ],
            record_dates=[
                VehicleAssociationsModel.association_start_date.name,
                VehicleAssociationsModel.association_end_date.name,
            ],
            source_table=NotilusTables.associations.value,
        )

        self.load_table(
            file_path=get_latest_file(
                self.folder,
                re.compile(r'Contravention_\d{8}_\d{6}\.xlsx'),
            ),
            col_lst=[
                FinesModel.fine_ref.return_variant(
                    raw_name='Référence',
                ),
                VehiclesModel.make.return_variant(
                    raw_name='Véhicule > Modèle > Marque > Libellé',
                ),
                VehiclesModel.model.return_variant(
                    raw_name='Véhicule > Modèle > Libellé',
                ),
                FinesModel.offense_date.return_variant(
                    raw_name='Date de la contravention',
                ),
                FinesModel.notice_date.return_variant(
                    raw_name="Date d'avis",
                ),
                FinesModel.fine_type.return_variant(
                    raw_name="Type",
                ),
                FinesModel.ticket_base_value.return_variant(
                    raw_name="Montant",
                ),
                FinesModel.currency.return_variant(
                    raw_name="Devise",
                ),
                FinesModel.fine_status.return_variant(
                    raw_name="Statut",
                ),
                FinesModel.offense_comment.return_variant(
                    raw_name="Motif > Motif",
                ),
                CollaboratorsModel.organization_employee_id.return_variant(
                    raw_name=(
                        "Désignation@Conducteur > Utilisateur > Matricule"
                    ),
                ),
                CollaboratorsModel.employee_last_name.return_variant(
                    raw_name=(
                        "Désignation@Conducteur > Utilisateur > Nom"
                    ),
                ),
                CollaboratorsModel.employee_first_name.return_variant(
                    raw_name=(
                        "Désignation@Conducteur > Utilisateur > Prénom"
                    ),
                ),
            ],
            skip_cols=['Valeur de référence'],
            record_dates=[
                FinesModel.offense_date.name,
            ],
            source_table=NotilusTables.fines.value,
        )
        self.import_ndf()

    def import_ndf(self):
        """ Import Notilus ndf data"""
        file_name_pattern = (
            r'NOTILUS - EXPORT NDF (?:RSE|SOONGO) - (?:V\d )?\d{6,8} ?\.xlsx?'
        )
        expense_data = self.agg_and_meld(
            eligible_files=[
                os.path.join(self.folder, file_name)
                for file_name in os.listdir(self.folder)
                if re.match(file_name_pattern, file_name)
            ],
            id_cols=[
                BusinessUnitsModel.entity_ref.return_variant(
                    raw_name='CODE SOCIETE',
                ),
                BusinessUnitsModel.cost_center.return_variant(
                    raw_name='LIBELLE SOCIETE',
                ),
                CollaboratorsModel.organization_employee_id.return_variant(
                    raw_name='Code Personne',
                ),
                ClaimsModel.payment_date.return_variant(
                    raw_name='Date Compta',
                ),
                ClaimsModel.claim_ref.return_variant(
                    raw_name='Numero de Note',
                ),
                ClaimsModel.expense_type.return_variant(
                    raw_name='Nature Frais',
                ),
                ClaimsModel.amount_tax_inc.return_variant(
                    raw_name='Montant frais',
                ),
                ClaimsModel.deductible_vat.return_variant(
                    raw_name='TVA frais',
                ),
            ],
            record_dates=[
                ClaimsModel.payment_date.name,
            ],
            value_col=None,
            var_col=None,
            skip_cols=['date frais'],
            source_table=NotilusTables.expense_claims.value,
            meld=False,
        )

        expense_data[ClaimsModel.expense_date.name] = convert_date(
            expense_data[ClaimsModel.payment_date.name],
            date_format=r'%d/%m/%Y',
        )
        setattr(
            self,
            NotilusTables.expense_claims.value,
            expense_data,
        )
        return expense_data

    def import_vehicles_data(
        self,
        folder: str,
        source_table: str,
    ) -> pd.DataFrame:
        """ Get vehicles data from Notilus

        :param logger: logging logger
        :param havas_folder: string path to the havas folder
        """
        vehicle_file_path = get_latest_file(
            self.folder,
            re.compile(r'Véhicule_\d{8}_\d{6}.xlsx'),
        )

        df = self.load_table(
            file_path=os.path.join(
                folder,
                vehicle_file_path,
            ),
            col_lst=[
                VehiclesModel.plate_number.return_variant(
                    raw_name="Immatriculation",
                    post_processing=convert_plate,
                ),
                BusinessUnitsModel.cost_center.return_variant(
                    raw_name='Société > Libellé',
                ),
                VehiclesModel.entry_into_fleet_date,
                VehiclesModel.exit_from_fleet_date,
                VehiclesModel.entry_into_service_date.return_variant(
                    raw_name='Date de mise en circulation',
                ),
                VehiclesModel.make.return_variant(
                    raw_name='Marque > Libellé',
                ),
                VehiclesModel.model.return_variant(
                    raw_name='Modèle > Libellé',
                ),
                VehiclesModel.fiscal_type.return_variant(
                    raw_name='Genre > Référence',
                ),
                VehiclesModel.energy.return_variant(
                    raw_name='Carburant > Référence',
                ),
                VehiclesModel.theoretical_CO2_per_km.return_variant(
                    raw_name='Taux de CO2'
                ),
                VehiclesModel.fiscal_power.return_variant(
                    raw_name='Puissance fiscale',
                ),
                VehicleAssociationsModel.assignment_type.return_variant(
                    raw_name='Données calculées > Affectation courante > Type'
                ),
                VehicleAssociationsModel.employee_or_cost_center_id.return_variant(
                    raw_name=(
                        "Données calculées > Collaborateur affecté > Matricule"
                    ),
                ),
                CollaboratorsModel.employee_last_name.return_variant(
                    raw_name='Données calculées > Collaborateur affecté > Nom'
                ),
                CollaboratorsModel.employee_first_name.return_variant(
                    raw_name=(
                        'Données calculées > Collaborateur affecté > Prénom'
                    ),
                ),
                TaxesModel.ikb_current.return_variant(
                    raw_name=(
                        "Données calculées > Affectation courante > Montant "
                        "d'avantage en nature"
                    ),
                ),
                VehicleReportsModel.monthly_participation.return_variant(
                    raw_name=(
                        'Données calculées > Affectation courante > '
                        'Montant de participation'
                    ),
                ),
                VehicleAssociationsModel.association_start_date.return_variant(
                    raw_name=(
                        'Données calculées > Affectation courante > '
                        'Date de début'
                    ),
                ),
                VehicleAssociationsModel.association_end_date.return_variant(
                    raw_name=(
                        'Données calculées > Affectation courante > '
                        'Date de fin'
                    ),
                ),
                VehicleAssociationsModel.assignment_comment.return_variant(
                    raw_name=(
                        'Données calculées > Affectation courante > Remarque'
                    )
                ),
                VehiclesModel.car_supplier.return_variant(
                    raw_name="Contrat > Fournisseur > Libellé",
                ),
                VehicleContractsModel.contract_type.return_variant(
                    raw_name=(
                        'Contrat > Type de financement > Référence'
                    )
                ),
                VehicleContractsModel.contract_reference.return_variant(
                    raw_name=(
                        'Contrat > Référence'
                    )
                ),
                VehicleContractsModel.lease_start_date.return_variant(
                    raw_name=(
                        'Contrat > Date de début'
                    )
                ),
                VehicleContractsModel.lease_end_date.return_variant(
                    raw_name=(
                        'Contrat > Date de fin'
                    )
                ),
                VehicleContractsModel.lease_months.return_variant(
                    raw_name=(
                        'Contrat > Dernière loi de roulage > Durée (Mois)'
                    )
                ),
                VehicleContractsModel.lease_mileage.return_variant(
                    raw_name=(
                        'Contrat > Dernière loi de roulage > Distance'
                    )
                ),
                VehicleContractsModel.total_rent_ttc.return_variant(
                    raw_name=(
                        'Contrat > Dernière loi de roulage > Loyer mensuel'
                    )
                ),
                VehiclesModel.model_ref.return_variant(
                    raw_name=(
                        'Modèle constructeur > Référence'
                    )
                ),
                VehiclesModel.full_model.return_variant(
                    raw_name=(
                        'Modèle constructeur > Libellé'
                    )
                ),
                VehiclesModel.vehicle_finishing.return_variant(
                    raw_name=(
                        'Modèle constructeur > Finition'
                    )
                ),
                MileageReportsModel.mileage_date.return_variant(
                    raw_name=(
                        'Données calculées > Date du dernier relevé'
                    )
                ),
                MileageReportsModel.mileage.return_variant(
                    raw_name=(
                        'Données calculées > Dernier relevé'
                    )
                ),
                VehicleContractsModel.financial_rent_ttc.return_variant(
                    raw_name=(
                        "Contrat > Dernière loi de roulage > Loyer 'Financier'"
                    )
                ),
                VehicleContractsModel.maintenance_rent_ttc.return_variant(
                    raw_name=(
                        "Contrat > Dernière loi de roulage > Loyer "
                        "'Maintenance'"
                    )
                ),
                VehicleContractsModel.tires_rent_ttc.return_variant(
                    raw_name=(
                        "Contrat > Dernière loi de roulage > Loyer "
                        "'Garantie perte financière'"
                    )
                ),
                VehicleContractsModel.financial_loss_rent_ttc.return_variant(
                    raw_name=(
                        "Contrat > Dernière loi de roulage > Loyer"
                        " 'Télématique'"
                    )
                ),
                VehicleContractsModel.telematics_rent_ttc.return_variant(
                    raw_name=(
                        "Contrat > Dernière loi de roulage > "
                        "Loyer 'Pneumatiques'"
                    )
                ),
                VehicleContractsModel.other_rent_ttc.return_variant(
                    raw_name=(
                        "Contrat > Dernière loi de roulage > Loyer 'Autres'"
                    )
                ),
            ],
            record_dates=[
                VehiclesModel.entry_into_fleet_date.name,
                VehiclesModel.entry_into_service_date.name,
                VehicleAssociationsModel.association_start_date.name,
                MileageReportsModel.mileage_date.name,
            ],
            source_table=source_table,
        )

        # Distinguish the business unit references from the employee ids
        is_service = (
            df[VehicleAssociationsModel.assignment_type.name] ==
            AssignmentType.service_vehicle.value
        )
        df[VehicleAssociationsModel.assigned_service.name] = (
            df[VehicleAssociationsModel.employee_or_cost_center_id.name].where(
                is_service,
                pd.NA,
            )
        )
        for col in [
            CollaboratorsModel.employee_first_name.name,
            CollaboratorsModel.employee_last_name.name,
        ]:
            df[col] = df[col].mask(is_service, '')

        is_company = (
            df[VehicleAssociationsModel.assignment_type.name] ==
            AssignmentType.company_vehicle.value
        )
        df[CollaboratorsModel.organization_employee_id.name] = (
            df[VehicleAssociationsModel.employee_or_cost_center_id.name].where(
                is_company,
                pd.NA,
            )
        )

        df[CollaboratorsModel.employee_full_name.name] = (
            convert_names(self.organization_name)(
                df[CollaboratorsModel.employee_first_name.name] + ' ' +
                df[CollaboratorsModel.employee_last_name.name]
            )
        )
        df[CollaboratorsModel.organization_employee_id.name] = convert_numeric(
            df[CollaboratorsModel.organization_employee_id.name]
        ).astype(CollaboratorsModel.organization_employee_id.dtype)
        df[VehicleAssociationsModel.daily_participation.name] = (
            df[VehicleReportsModel.monthly_participation.name] / 30
        )
        df.drop(
            columns=[
                VehicleAssociationsModel.employee_or_cost_center_id.name,
                VehicleReportsModel.monthly_participation.name,
            ],
            inplace=True,
        )
        setattr(
            self,
            source_table,
            df,
        )
        return df

    def import_expense_table(self) -> pd.DataFrame:
        """ Import expense table, non anomalous"""

        expense_file_path = get_latest_file(
            self.folder,
            re.compile(r'Ligne de facture_\d{8}_\d{6}.xlsx'),
        )
        expense_df = self.load_table(
            file_path=os.path.join(
                self.folder,
                expense_file_path,
            ),
            col_lst=[
                ExpensesModel.expense_reference.return_variant(
                    raw_name="Facture > Référence"
                ),
                ExpensesModel.supplier.return_variant(
                    raw_name="Facture > Fournisseur > Libellé",
                ),
                ExpensesModel.billing_type,
                ClaimsModel.payment_date.return_variant(
                    raw_name="Facture > Date d'émission",
                ),
                ExpensesModel.is_anomalous,
                BusinessUnitsModel.billed_entity.return_variant(
                    raw_name='Facture > Société facturée > Libellé'
                ),
                ExpensesModel.billing_date.return_variant(
                    raw_name='Date',
                ),
                ExpensesModel.category_2.return_variant(
                    raw_name='Libellé nature',
                ),
                ExpensesModel.amount_tax_inc.return_variant(
                    raw_name='Montant',
                ),
                ExpensesModel.amount_tax_exc.return_variant(
                    raw_name='Montant (HT)',
                ),
                ExpensesModel.vat_rate.return_variant(
                    raw_name='Taux de taxe',
                ),
                ExpensesModel.currency.return_variant(
                    raw_name='Devise',
                ),
                ExpensesModel.quantity.return_variant(
                    raw_name='Quantité',
                ),
                VehiclesModel.plate_number.return_variant(
                    raw_name='Véhicule > Immatriculation',
                    post_processing=convert_plate,
                ),
                ExpensesModel.anomaly_description,
                ExpensesModel.category_1.return_variant(
                    raw_name='Nature > Famille',
                ),
            ],
            skip_cols=['Facture > Montant total (TTC)', 'Facture > Statut'],
            sheet_name='Data',
            record_dates=[
                ExpensesModel.billing_date.name,
                ClaimsModel.payment_date.name,
            ],
            source_table=NotilusTables.expenses.value,
        )
        expense_df = self.categorize_expenses(expense_df)
        # !! Drop fuel expenses which are managed in Edenred !!
        expense_df = expense_df.loc[
            (
                ~expense_df[ExpensesModel.expense_category.name].isin(
                    [fuel_type.value for fuel_type in FuelTypes]
                )
            ),
        ]
        setattr(
            self,
            NotilusTables.expenses.value,
            expense_df
        )

    def extrapolate_expense_table(
        self: typing.Self,
        supplier_lst: typing.List[str],
    ) -> pd.DataFrame:
        """ Extrapolate_expenses from faulty suppliers

        :param supplier_lst: list of car suppliers expenses should be extra
            polated for.
        """

        vehicle_df = getattr(
            self,
            NotilusTables.vehicles.value,
        )
        expense_df = getattr(self, NotilusTables.expenses.value).merge(
            vehicle_df[
                [
                    VehiclesModel.plate_number.name,
                    VehicleContractsModel.lease_start_date.name,
                    VehicleContractsModel.lease_end_date.name,
                ]
            ],
            on=VehiclesModel.plate_number.name,
            validate='m:1',
            how='left',
        )
        expense_df = expense_df.loc[
            expense_df[ExpensesModel.supplier.name].isin(
                supplier_lst
            )
        ]
        expense_df['temp_date'] = expense_df[ExpensesModel.billing_date.name].where(
            expense_df[ExpensesModel.expense_category.name] == CostCategory.financial_rent.value
        )
        expense_df['min_date'] = expense_df.groupby(
            VehiclesModel.plate_number.name
        )['temp_date'].transform('min')
        expense_df['max_date'] = expense_df.groupby(
            VehiclesModel.plate_number.name
        )['temp_date'].transform('max')
        expense_df[VehicleContractsModel.lease_start_date.name] = expense_df[
            [
                'min_date',
                VehicleContractsModel.lease_start_date.name,
            ]
        ].min(axis=1)
        expense_df[VehicleContractsModel.lease_end_date.name] = expense_df[
            [
                'max_date',
                VehicleContractsModel.lease_end_date.name,
            ]
        ].max(axis=1)
        expense_df = fill_expense_gaps(
            expense_df=expense_df,
            id_cols=[
                VehiclesModel.plate_number.name,
                ExpensesModel.supplier.name,
                SoonGoRecordsModel.source_connector.name,
                SoonGoRecordsModel.source_dataset.name,
                SoonGoRecordsModel.source_table.name,
                SoonGoRecordsModel.synchronisation_type.name,
            ],
            start_col=VehicleContractsModel.lease_start_date.name,
            end_col=VehicleContractsModel.lease_end_date.name,
        )
        expense_df['rent_count'] = (
            expense_df[ExpensesModel.expense_category.name] ==
            CostCategory.financial_rent.value
        )
        rent_count = expense_df.groupby(
            VehiclesModel.plate_number.name
        )['rent_count'].sum().reset_index()

        rent_df = vehicle_df.merge(
            rent_count,
            on=VehiclesModel.plate_number.name,
            how='left',
            validate='1:1',
        )
        rent_df = rent_df.loc[
            (rent_df['rent_count'].fillna(0) == 0) &
            rent_df[VehiclesModel.car_supplier.name].isin(supplier_lst),
        ]
        rent_df[VehicleContractsModel.financial_rent_ttc.name] = (
            rent_df[VehicleContractsModel.financial_rent_ttc.name].fillna(
                rent_df[VehicleContractsModel.total_rent_ttc.name]
            )
        )
        missing_rent_expenses = extrapolate_expense_from_rents(
            rent_df=rent_df,
            id_cols=[
                VehiclesModel.plate_number.name,
                VehiclesModel.car_supplier.name,
                SoonGoRecordsModel.source_connector.name,
                SoonGoRecordsModel.source_dataset.name,
                SoonGoRecordsModel.source_table.name,
                SoonGoRecordsModel.synchronisation_type.name,
            ],
            start_col=VehicleContractsModel.lease_start_date.name,
            end_col=VehicleContractsModel.lease_end_date.name,
        )
        missing_rent_expenses = missing_rent_expenses.rename(
            {VehiclesModel.car_supplier.name: ExpensesModel.supplier.name},
            axis=1,
        )
        expense_df = pd.concat(
            [
                expense_df,
                missing_rent_expenses,
            ],
            axis=0,
        )

        expense_df.drop(
            [
                'temp_date',
                'min_date',
                'max_date',
                'rent_count',
                VehicleContractsModel.lease_start_date.name,
                VehicleContractsModel.lease_end_date.name,
            ],
            axis=1,
            inplace=True,
        )
        expense_df = get_record_date(
            data_df=expense_df,
            record_dates=[
                ExpensesModel.billing_date.name,
                ClaimsModel.payment_date.name,
            ],
        )
        expense_df[SoonGoRecordsModel.source_table.name] = (
            NotilusTables.ext_expenses.value
        )
        setattr(
            self,
            NotilusTables.ext_expenses.value,
            expense_df,
        )

    def import_vehicle_age_table(self) -> pd.DataFrame:
        """ Import vehicle age table"""
        df_lst = []
        eligible_files = [
            os.path.join(self.folder, file_name)
            for file_name in os.listdir(self.folder)
            if re.match(r'co2_tax_\d{4}', file_name)
        ]
        for file_path in eligible_files:
            try:
                df_lst.append(
                    self.read_age_tax_table(
                        sheet_name='Taxe energie Cerfa 2858-FC-SD',
                        file_path=file_path,
                    )
                )
            except ValueError as error:
                if "Worksheet named" in str(error):
                    df_lst.append(
                        self.read_age_tax_table(
                            sheet_name='Taxe Anciénneté - 2858-FC-SD',
                            file_path=file_path,
                        )
                    )
                else:
                    raise

        vehicle_age_df = pd.concat(df_lst, axis=0)
        vehicle_age_df[ExpensesModel.billing_date.name] = (
            vehicle_age_df[TaxesModel.tax_status_end_date.name]
        )

        setattr(
            self,
            NotilusTables.age_tax.value,
            vehicle_age_df
        )

        return vehicle_age_df

    def import_co2_tax_table(self) -> pd.DataFrame:
        """ Import CO2 Tax table """
        df_lst = []
        eligible_files = [
            os.path.join(self.folder, file_name)
            for file_name in os.listdir(self.folder)
            if re.match(r'co2_tax_\d{4}', file_name)
        ]
        for file_path in eligible_files:
            try:
                df_lst.append(
                    self.read_co2_tax_table(
                        sheet_name='Taxe Co2 Cerfa 2857-FC-SD',
                        file_path=file_path,
                    )
                )
            except ValueError as error:
                if "Worksheet named" in str(error):
                    df_lst.append(
                        self.read_co2_tax_table(
                            sheet_name='Taxe Co2 - 2857-FC-SD',
                            file_path=file_path,
                        )
                    )
                else:
                    raise

        co2_tax_df = pd.concat(df_lst, axis=0)
        co2_tax_df[ExpensesModel.billing_date.name] = (
            co2_tax_df[TaxesModel.tax_status_end_date.name]
        )

        setattr(
            self,
            NotilusTables.co2_tax.value,
            co2_tax_df
        )

        return co2_tax_df

    def import_anomalous_expense_table(self) -> pd.DataFrame:
        """ Import anomalous expense table"""

        expense_file_path = get_latest_file(
            self.folder,
            re.compile(r'Ligne de facture_\d{8}_\d{6}_anomaly.xlsx'),
        )
        expense_df = self.load_table(
            file_path=os.path.join(
                self.folder,
                expense_file_path,
            ),
            col_lst=[
                BusinessUnitsModel.billed_entity.return_variant(
                    raw_name='Facture > Société facturée > Libellé',
                ),
                BusinessUnitsModel.entity_ref.return_variant(
                    raw_name='Facture > Société facturée > Référence',
                ),
                ExpensesModel.expense_reference.return_variant(
                    raw_name="Facture > Référence",
                ),
                ExpensesModel.supplier.return_variant(
                    raw_name="Facture > Fournisseur > Libellé",
                ),
                ClaimsModel.payment_date.return_variant(
                    raw_name="Facture > Date d'émission",
                ),
                ExpensesModel.category_2.return_variant(
                    raw_name='Libellé nature',
                ),
                ExpensesModel.amount_tax_inc.return_variant(
                    raw_name='Montant',
                ),
                ExpensesModel.anomaly_description,
            ],
            sheet_name='Data',
            record_dates=[
                ClaimsModel.payment_date.name,
            ],
            source_table=NotilusTables.anomalous_expenses.value,
        )
        expense_df = self.categorize_expenses(expense_df)
        # !! Drop fuel expenses which are managed in Edenred !!
        expense_df = expense_df.loc[
            (
                ~expense_df[ExpensesModel.expense_category.name].isin(
                    [fuel_type.value for fuel_type in FuelTypes]
                )
            ),
        ]

        setattr(
            self,
            NotilusTables.anomalous_expenses.value,
            expense_df
        )
        return expense_df

    def import_collaborators_table(self) -> pd.DataFrame:
        """ Import collaborators table """
        collaborators_df = self.load_table(
            file_path=get_latest_file(
                target_folder=self.folder,
                pattern=re.compile(r'Collaborateur_\d{8}_\d{6}\.xlsx'),
            ),
            col_lst=[
                VehicleAssociationsModel.employee_or_cost_center_id.return_variant(
                    raw_name='Matricule',
                ),
                CollaboratorsModel.employee_last_name.return_variant(
                    raw_name='Nom',
                ),
                CollaboratorsModel.employee_first_name.return_variant(
                    raw_name='Prénom',
                ),
                CollaboratorsModel.employee_email.return_variant(
                    raw_name='e-Mail',
                ),
                BusinessUnitsModel.entity_2.return_variant(
                    raw_name='Société > Libellé',
                ),
                BusinessUnitsModel.entity_3.return_variant(
                    raw_name='Service > Libellé',
                ),
                BusinessUnitsModel.entity_ref.return_variant(
                    raw_name='Service > Référence',
                ),
                CollaboratorsModel.employee_internal_category.return_variant(
                    raw_name='Catégorie > Référence',
                ),
                CollaboratorsModel.employee_category_name,
                CollaboratorsModel.employee_address.return_variant(
                    raw_name=(
                        'Informations complémentaires > Adresse personnelle > '
                        'Adresse'
                    ),
                ),
            ],
            record_dates=[],
            source_table=NotilusTables.collaborators.value,
            skip_cols=[
                'Actif',
                'Civilité',
                'Société > Référence',
                'Informations complémentaires > N+1 > Matricule',
                'Informations complémentaires > N+1 > Nom',
                'Informations complémentaires > N+1 > Prénom',
                'Informations complémentaires > N+2 > Matricule',
                'Informations complémentaires > N+2 > Nom',
                'Informations complémentaires > N+2 > Prénom',
                ''
            ],
        )
        collaborators_df[BusinessUnitsModel.entity_1.name] = 'GROUPE DOMINO'
        collaborators_df[CollaboratorsModel.employee_internal_category.name] = (
            pd.to_numeric(
                collaborators_df[VehicleAssociationsModel.employee_or_cost_center_id.name],
                errors='coerce',
            )
        ).astype(CollaboratorsModel.employee_internal_category.dtype)

        for col in [
            CollaboratorsModel.employee_last_name.name,
            CollaboratorsModel.employee_first_name.name,
        ]:
            collaborators_df[col] = collaborators_df[col].mask(
                pd.isna(
                    collaborators_df[CollaboratorsModel.employee_internal_category.name]
                )
            )
        collaborators_df[CollaboratorsModel.employee_full_name.name] = (
            convert_names(self.organization_name)(
                collaborators_df[CollaboratorsModel.employee_first_name.name]
                + ' ' +
                collaborators_df[CollaboratorsModel.employee_last_name.name]
            )
        )
        setattr(
            self,
            NotilusTables.collaborators.value,
            collaborators_df
        )
        return collaborators_df

    def read_age_tax_table(
        self: typing.Self,
        sheet_name: str,
        file_path: str,
    ) -> pd.DataFrame:
        return self.load_table(
            file_path=file_path,
            col_lst=[
                BusinessUnitsModel.cost_center.return_variant(
                    raw_name="Société d'imputation du véhicule",
                ),
                VehiclesModel.plate_number.return_variant(
                    raw_name="NUMÉRO d'immatriculation des véhicules",
                    post_processing=convert_plate,
                ),
                VehiclesModel.entry_into_service_date.return_variant(
                    raw_name="Date de la première immatriculation",
                ),
                VehiclesModel.country_entry_into_service_date,
                VehicleAssociationsModel.assignment_type.return_variant(
                    raw_name="Mode d’affectation",
                ),
                TaxesModel.tax_vehicle_age.return_variant(
                    raw_name="Unnamed: 16",
                ),
                TaxesModel.tax_status_start_date.return_variant(
                    raw_name="Unnamed: 7",
                ),
                TaxesModel.tax_status_end_date.return_variant(
                    raw_name="Unnamed: 8",
                ),
                VehicleReportsModel.total_days.return_variant(
                    raw_name="Unnamed: 9",
                ),
            ],
            skip_cols=[
                'Catégorie',
                'Unnamed: 10',
                'Unnamed: 11',
                'Unnamed: 12',
                'Unnamed: 13',
                'Unnamed: 14',
                'Unnamed: 15',
                'Unnamed: 17',
                "1– VÉHICULES IMPOSABLES",
            ],
            usecols='A:R',
            skiprows=[1, 2, 3],
            sheet_name=sheet_name,
            record_dates=[
                TaxesModel.tax_status_start_date.name,
                TaxesModel.tax_status_end_date.name,
            ],
            source_table=NotilusTables.age_tax.value,
        )

    def read_co2_tax_table(
        self: typing.Self,
        sheet_name: str,
        file_path: str,
    ) -> pd.DataFrame:
        return self.load_table(
            file_path=file_path,
            col_lst=[
                BusinessUnitsModel.cost_center.return_variant(
                    raw_name="Société d'imputation du véhicule",
                ),
                VehiclesModel.plate_number.return_variant(
                    raw_name="NUMÉRO d'immatriculation des véhicules",
                    post_processing=convert_plate,
                ),
                VehiclesModel.entry_into_service_date.return_variant(
                    raw_name="Date de la première immatriculation",
                ),
                VehiclesModel.country_entry_into_service_date,
                VehiclesModel.theoretical_CO2_per_km.return_variant(
                    raw_name=(
                        'Taux d’émission de dioxyde de carbone '
                        '\n\nEn gramme par kilomètre'
                    )
                ),
                VehiclesModel.fiscal_power.return_variant(
                    raw_name=(
                        'Puissance administrative \n\nEn chevaux fiscaux'
                    )
                ),
                VehicleAssociationsModel.assignment_type.return_variant(
                    raw_name="Mode d’affectation",
                ),
                TaxesModel.tax_CO2_emission.return_variant(
                    raw_name="Unnamed: 17",
                ),
                TaxesModel.tax_status_start_date.return_variant(
                    raw_name="Unnamed: 8",
                ),
                TaxesModel.tax_status_end_date.return_variant(
                    raw_name="Unnamed: 9",
                ),
                VehicleReportsModel.total_days.return_variant(
                    raw_name="Unnamed: 10",
                ),
            ],
            skip_cols=[
                "1– VÉHICULES IMPOSABLES",
                'Unnamed: 11',
                'Unnamed: 12',
                'Unnamed: 13',
                'Unnamed: 14',
                'Unnamed: 15',
                'Unnamed: 16',
            ],
            usecols='A:R',
            skiprows=[1, 2, 3],
            sheet_name=sheet_name,
            record_dates=[
                TaxesModel.tax_status_start_date.name,
                TaxesModel.tax_status_end_date.name,
            ],
            source_table=NotilusTables.co2_tax.value,
        )

    @staticmethod
    def categorize_expenses(df: pd.DataFrame) -> pd.DataFrame:
        soongo_cat = ExpensesModel.expense_category.name
        notilus_cat = ExpensesModel.category_2.name
        df[soongo_cat] = np.where(
            df[notilus_cat] == 'Adblue',
            CostCategory.adblue.value,
            None,
        )
        df[soongo_cat] = (
            df[soongo_cat].where(
                (
                    (df[notilus_cat] != 'Carburant Essence')
                    | pd.notna(df[soongo_cat])
                ),
                CostCategory.default_gaz.value,
            )
        )
        df[soongo_cat] = (
            df[soongo_cat].where(
                (
                    (df[notilus_cat] != 'Carburant gazole')
                    | pd.notna(df[soongo_cat])
                ),
                CostCategory.diesel.value,
            )
        )
        df[soongo_cat] = (
            df[soongo_cat].where(
                (
                    (df[notilus_cat] != 'Carburant Gazole')
                    | pd.notna(df[soongo_cat])
                ),
                CostCategory.diesel.value,
            )
        )
        df[soongo_cat] = (
            df[soongo_cat].where(
                (
                    ~df[notilus_cat].isin((
                        'Carte Grise',
                        "Crit'air",
                        'Double des clés',
                        'Frais de régularisation',  # TODO: question
                        'Gardiennage',  # TODO: question
                    ))
                    | pd.notna(df[soongo_cat])
                ),
                CostCategory.real_others.value,
            )
        )
        df[soongo_cat] = (
            df[soongo_cat].where(
                (
                    ~df[notilus_cat].isin((
                        'Contrôle divers',
                        'Diagnostics',
                        'Entretien',
                        'Entretien courant',
                        'Entretien système de freinage (Plaquette/disques)',
                        'Entretien courroie',
                        'Entretien essuie-glace',
                        'Entretien éclairage',
                        'Filtre à huile',
                        'Filtre carburant',
                        'Filtre habitacle',
                        'Vidange',
                    ))
                    | pd.notna(df[soongo_cat])
                ),
                CostCategory.real_maintenance.value,
            )
        )
        df[soongo_cat] = (
            df[soongo_cat].where(
                (
                    ~df[notilus_cat].isin((
                        'Dépassement kilométrique',
                        'Loyer financier',
                    ))
                    | pd.notna(df[soongo_cat])
                ),
                CostCategory.financial_rent.value,
            )
        )
        df[soongo_cat] = (
            df[soongo_cat].where(
                (
                    ~df[notilus_cat].isin((
                        'Loyer assistance',
                    ))
                    | pd.notna(df[soongo_cat])
                ),
                CostCategory.rent_assistance.value,
            )
        )
        df[soongo_cat] = (
            df[soongo_cat].where(
                (
                    ~df[notilus_cat].isin((
                        'Frais carte carburant',
                    ))
                    | pd.notna(df[soongo_cat])
                ),
                CostCategory.real_fuel_card.value,
            )
        )
        df[soongo_cat] = (
            df[soongo_cat].where(
                (
                    ~df[notilus_cat].isin((
                        'Frais carte carburant/Télépéage',
                    ))
                    | pd.notna(df[soongo_cat])
                ),
                CostCategory.tolls_real.value,
            )
        )
        df[soongo_cat] = (
            df[soongo_cat].where(
                (
                    ~df[notilus_cat].isin((
                        'Frais de gestion',
                        'Solution Fournisseur',
                    ))
                    | pd.notna(df[soongo_cat])
                ),
                CostCategory.rent_management_fees.value,
            )
        )
        df[soongo_cat] = (
            df[soongo_cat].where(
                (
                    ~df[notilus_cat].isin((
                        'Frais sinistre',
                    ))
                    | pd.notna(df[soongo_cat])
                ),
                CostCategory.insurance_deductible_cost.value,
            )
        )
        df[soongo_cat] = (
            df[soongo_cat].where(
                (
                    ~df[notilus_cat].isin((
                        'Frais de gestion amende',
                    ))
                    | pd.notna(df[soongo_cat])
                ),
                CostCategory.fines.value,
            )
        )
        df[soongo_cat] = (
            df[soongo_cat].where(
                (
                    ~df[notilus_cat].isin((
                        'Indemnités résilisation',  # TODO: question
                    ))
                    | pd.notna(df[soongo_cat])
                ),
                CostCategory.real_restitution.value,
            )
        )
        df[soongo_cat] = (
            df[soongo_cat].where(
                (
                    ~df[notilus_cat].isin((
                        'Location courte durée',
                    ))
                    | pd.notna(df[soongo_cat])
                ),
                CostCategory.real_short_term_rental.value,
            )
        )
        df[soongo_cat] = (
            df[soongo_cat].where(
                (
                    ~df[notilus_cat].isin((
                        'Loyer maintenance',
                    ))
                    | pd.notna(df[soongo_cat])
                ),
                CostCategory.rent_maintenance.value,
            )
        )
        df[soongo_cat] = (
            df[soongo_cat].where(
                (
                    ~df[notilus_cat].isin((
                        'Garantie perte financière',
                    ))
                    | pd.notna(df[soongo_cat])
                ),
                CostCategory.rent_financial_loss.value,
            )
        )
        df[soongo_cat] = (
            df[soongo_cat].where(
                (
                    ~df[notilus_cat].isin((
                        'Montage Pneumatique',
                        'Pneumatiques divers',
                        'Pneumatique',
                        'Pneumatiques 4 saisons',
                        'Pneumatiques gardiennage',
                        'Permutation de roues',
                        'Pneus 4 saisons',
                    ))
                    | pd.notna(df[soongo_cat])
                ),
                CostCategory.real_tires_other.value,
            )
        )
        df[soongo_cat] = (
            df[soongo_cat].where(
                (
                    ~df[notilus_cat].isin((
                        'Pneumatiques été',
                    ))
                    | pd.notna(df[soongo_cat])
                ),
                CostCategory.real_tires_summer.value,
            )
        )
        df[soongo_cat] = (
            df[soongo_cat].where(
                (
                    ~df[notilus_cat].isin((
                        'Pneumatiques hivers',
                    ))
                    | pd.notna(df[soongo_cat])
                ),
                CostCategory.real_tires_winter.value,
            )
        )
        df[soongo_cat] = (
            df[soongo_cat].where(
                (
                    ~df[notilus_cat].isin((
                        "Prime d'Assurance",
                    ))
                    | pd.notna(df[soongo_cat])
                ),
                CostCategory.insurance_vehicle.value,
            )
        )
        df[soongo_cat] = (
            df[soongo_cat].where(
                (
                    ~df[notilus_cat].isin((
                        "Réparation",
                        'Pneumatiques réparation',  # TODO: discuss with F2
                        'Réparation carrosserie',
                        'Réparation pneumatiques',
                    ))
                    | pd.notna(df[soongo_cat])
                ),
                CostCategory.real_repairs.value,
            )
        )
        df[soongo_cat] = (
            df[soongo_cat].where(
                (
                    ~df[notilus_cat].isin((
                        'Véhicule de remplacement',
                    ))
                    | pd.notna(df[soongo_cat])
                ),
                CostCategory.rent_replacement_vehicle_flat_fee.value,
            )
        )
        uncategorized_cats = df.loc[
            str_is_nan(df[soongo_cat]),
            notilus_cat,
        ].unique()
        if uncategorized_cats:
            raise ValueError(
                f'Some Notilus categories were not mapped to a SoonGo category'
                f': {uncategorized_cats}'
            )
        return df


if __name__ == '__main__':
    notilus_data = NotilusData(
        folder='/home/matthieuglotz/Documents/Data/Domino/NOTILUS',
        organization_name='Domino',
        supplier_lst=[
            'FREE2MOVE', 'ARVAL LLD', 'BYmyCAR', 'P LEASE', 'YOOLIZ', 'LEASYS',
            'AUTOMOBILE DU LEMAN', 'VOLKSWAGEN BANK',
            'AUTO-GUADELOUP Pointe à Pitre', 'DIAC Location'
            ],
    )
    i = 0
    for df in notilus_data:
        df.to_csv(f'~/dev/temp/notilus_{i}.csv')
        i += 1
