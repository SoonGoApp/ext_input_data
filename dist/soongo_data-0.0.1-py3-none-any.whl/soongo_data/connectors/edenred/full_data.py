""" Edenred Data

Class loading, normalizing and organizing all Edenred Datasets for a given
organization
"""
import re
import os
import typing
from enum import Enum, unique

import pandas as pd

from data_models import (
    FuelCardsModel, VehiclesModel, ExpensesModel, MileageReportsModel
)
from utils.dataset import Dataset, add_connector
from utils.logging import gen_logger
from utils.type import convert_plate
from utils.enums import SynchronizationTypes


@unique
class EdenredTables(Enum):
    fuel_expenses = 'FUEL_EXPENSES'


@add_connector
class EdenredData(Dataset):
    SOURCE_CONNECTOR = 'EDENRED'
    NAME = 'EDENRED'
    TYPE = SynchronizationTypes.csv_upload.value

    def __init__(
        self,
        folder: str,
        organization_name: str,
        log_file: typing.Optional[str] = None,
    ) -> None:
        """ Instantiates EdenredData object containing all the Edenred tables

        :param folder: str path to the root folder where all the data is
            stored.
        :param log_file: file where to write logs

        :raises ValueError: if folder is not a valid path or does not
        contain all required subfolders
        """
        super().__init__(
            folder=folder,
            logger=gen_logger(
                name=self.__class__.__name__,
                file_path=log_file,
            ),
            source_connector=self.SOURCE_CONNECTOR,
            name=self.NAME,
            type=self.TYPE,
            organization_name=organization_name,
        )
        self.import_fuel_expenses()

    def import_fuel_expenses(self) -> pd.DataFrame:
        if not os.path.isdir(os.path.expanduser(self.folder)):
            self.logger.error(
                'Provided root folder %s is not a valid directory',
                self.folder,
            )
            expense_claims_files = []
        else:
            expense_claims_files = [
                os.path.join(self.folder, file_name)
                for file_name in os.listdir(self.folder)
                if re.match(
                    r'Transactions_\d{14}\.csv',
                    file_name,
                )
            ]

        fuel_expense_df = self.agg_and_meld(
            eligible_files=expense_claims_files,
            id_cols=[
                FuelCardsModel.gaz_station_ref,
                FuelCardsModel.gaz_station,
                FuelCardsModel.gaz_station_type,
                FuelCardsModel.fuel_card_type,
                FuelCardsModel.fuel_card_ref.return_variant(
                    raw_name='Carte : Numéro de carte',
                ),
                FuelCardsModel.fuel_card_end_date,
                ExpensesModel.billing_ref.return_variant(
                    raw_name="Numéro de transaction",
                ),
                ExpensesModel.billing_date.return_variant(
                    raw_name='Date de transaction',
                ),
                FuelCardsModel.fuel_type.return_variant(
                    raw_name='Produit',
                ),
                ExpensesModel.unit_price,
                ExpensesModel.quantity,
                ExpensesModel.amount_tax_inc,
                ExpensesModel.amount_tax_exc,
                VehiclesModel.plate_number.return_variant(
                    raw_name='Immatriculation',
                    post_processing=convert_plate,
                ),
                MileageReportsModel.mileage.return_variant(
                    raw_name='Kilométrage',
                ),
                FuelCardsModel.was_approved,
                FuelCardsModel.approval_type,
            ],
            value_col='',
            var_col='',
            record_dates=[
                ExpensesModel.billing_date.name,
            ],
            source_table=EdenredTables.fuel_expenses.value,
            meld=False,
            skip_cols=[
                'Enseigne',
                'Site : Numéro de terminal',
                'Site : Libellé court',
                'Client : Référence client',
                'Client : Nom du client',
                'Numéro de TLC',
                'Date de télécollecte',
                'Type de transaction',
                'Référence transaction',
                'Code devise',
                'Code produit',
                'Code véhicule',
                'Code chauffeur',
                "Numéro d'opposition",
                "Numéro d'autorisation",
                "Mode de transaction",
                "Mode de vente",
                "Mode de validation",
                "Facturation client",
                "Facturation site",
                "Numéro de facture",
                "Avoir gérant",
            ],
        )
        fuel_expense_df[ExpensesModel.expense_category.name] = (
            fuel_expense_df[FuelCardsModel.fuel_type.name]
        )
        fuel_expense_df[MileageReportsModel.mileage_date.name] = (
            fuel_expense_df[ExpensesModel.billing_date.name]
        )
        setattr(
            self,
            EdenredTables.fuel_expenses.value,
            fuel_expense_df,
        )
        return fuel_expense_df


if __name__ == '__main__':
    logger = gen_logger('EdenredData')
    edenred_data = EdenredData(
        folder='/home/matthieuglotz/Documents/Data/Domino/EDENRED',
        organization_name='Domino',
    )

    for df in edenred_data:
        print(df)
