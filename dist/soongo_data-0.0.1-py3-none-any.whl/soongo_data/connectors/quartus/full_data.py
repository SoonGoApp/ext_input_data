""" Quartus Data

Class loading, normalizing and organizing all datasets exported manually by
Quartus, mostly for HR purposes
"""
import os
import typing
from enum import Enum, unique

from data_models import (
    CollaboratorsModel, BusinessUnitsModel
)
from utils.dataset import Dataset, add_connector
from utils.logging import gen_logger
from utils.enums import SynchronizationTypes


@unique
class QuartusTables(Enum):
    collaborators_entry_exit = 'ENTRY_EXIT'


@add_connector
class QuartusData(Dataset):
    SOURCE_CONNECTOR = 'QUARTUS'
    NAME = 'QUARTUS'
    TYPE = SynchronizationTypes.csv_upload.value

    def __init__(
        self,
        folder: str,
        organization_name: str,
        log_file: typing.Optional[str] = None,
        entity_1: str = "Groupe QUARTUS"
    ) -> None:
        """ Instantiates a Dataset from the exports received from Domino

        :param folder: str path to the root folder where all the data is
            stored.
        :param log_file: file where to write logs

        :raises ValueError: if folder is not a valid path or does not
        contain all required subfolders
        """
        logger = gen_logger(
            name=self.__class__.__name__,
            file_path=log_file,
        )
        super().__init__(
            folder=folder,
            logger=logger,
            source_connector=self.SOURCE_CONNECTOR,
            name=self.NAME,
            type=self.TYPE,
            organization_name=organization_name,
        )
        if not os.path.isdir(os.path.expanduser(folder)):
            logger.error(
                'Provided root folder %s is not a valid directory',
                folder,
            )
        self.import_collaborators_entry_exit(entity_1)

    def import_collaborators_entry_exit(self: typing.Self, entity_1: str):

        collaborators_df = self.load_table(
            file_path=os.path.join(
                self.folder,
                'Export salariés.csv',
            ),
            col_lst=[
                CollaboratorsModel.employee_first_name.return_variant(
                    raw_name='Nom',
                ),
                CollaboratorsModel.employee_last_name.return_variant(
                    raw_name='Prénom',
                ),
                CollaboratorsModel.employee_email.return_variant(
                    raw_name='Email_salarie'
                ),
                CollaboratorsModel.organization_employee_id.return_variant(
                    raw_name='Matricule'
                ),
                CollaboratorsModel.employee_entry_date.return_variant(
                    raw_name='DateEmbauche'
                ),
                CollaboratorsModel.employee_exit_date.return_variant(
                    raw_name='DateDepart'
                ),
                BusinessUnitsModel.entity_2.return_variant(
                    raw_name='Societe'
                ),
                BusinessUnitsModel.entity_3.return_variant(
                    raw_name='Etablissement'
                ),
            ],
            record_dates=[
                CollaboratorsModel.employee_entry_date.name,
                CollaboratorsModel.employee_exit_date.name,
            ],
            source_table=QuartusTables.collaborators_entry_exit.value,
            skip_cols=[
                'Civilité',
            ],
            encoding='utf-8',
        )
        collaborators_df[BusinessUnitsModel.entity_1.name] = entity_1


if __name__ == '__main__':
    quartus_data = QuartusData(
        folder='/home/matthieuglotz/Documents/Data/Quartus/QUARTUS',
        organization_name='Quartus'
    )
    for df in quartus_data:
        df.to_csv('~/dev/temp/quartus_data.csv')
