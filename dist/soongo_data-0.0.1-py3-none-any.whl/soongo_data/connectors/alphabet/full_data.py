""" Alphabet Data

Class loading, normalizing and organizing all datasets from the Alphabet
connector
"""
import os
import re
import typing
from enum import Enum, unique

import pandas as pd

from data_models import (
    CollaboratorsModel, TaxesModel, VehiclesModel,
    VehicleContractsModel, ExpensesModel, BusinessUnitsModel
)
from utils.dataset import (
    Dataset, add_connector, parser_factory, PDFParsingParams,
    check_vat_consistency
)
from utils.logging import gen_logger
from utils.type import convert_string, convert_numeric, convert_date, convert_names
from utils.enums import CostCategory, SynchronizationTypes

name_dict = {
    'jeannelfrancois': 'francois jeannel',
    'juliefigueroa': 'julie figueroa',
    'parisagence': 'agence paris',
    'pierrecocard': 'pierre cocard',
    '. labrini': 'labrini',
    'jeannel francois': 'francois jeannel',
}


@unique
class AlphabetTables(Enum):
    corporate_vehicle_tax = 'CORPORATE_VEHICLE_TAX'
    non_deductible_amortization = 'NON_DEDUCTIBLE_AMORTIZATION'
    expenses = 'EXPENSES'


@add_connector
class AlphabetData(Dataset):
    SOURCE_CONNECTOR = 'ALPHABET'
    NAME = 'ALPHABET'
    TYPE = SynchronizationTypes.csv_upload.value

    def __init__(
        self,
        folder: str,
        organization_name: str,
        log_file: typing.Optional[str] = None,
        **add_params
    ) -> None:
        """ Instantiates a Dataset from the exports received from Alphabet

        :param folder: str path to the root folder where all the data is
            stored.
        :param log_file: file where to write logs

        :raises ValueError: if folder is not a valid path or does not
        contain all required subfolders
        """
        logger = gen_logger(
            name=self.__class__.__name__,
            file_path=log_file,
        )
        super().__init__(
            folder=folder,
            logger=logger,
            source_connector=self.SOURCE_CONNECTOR,
            name=self.NAME,
            type=self.TYPE,
            organization_name=organization_name,
        )
        if not os.path.isdir(os.path.expanduser(folder)):
            logger.error(
                'Provided root folder %s is not a valid directory',
                folder,
            )
        self.import_and()
        self.import_tvs()
        self.import_expenses(add_params['expenses_check_dict'])

    def import_expenses(self, expenses_check_dict: dict) -> pd.DataFrame:
        format_2_expenses = [
            PDFParsingParams(
                cols=[
                    ExpensesModel.billing_date.return_variant(
                        overwrite='preserve',
                        memorization='doc',
                        post_processing=convert_day_first_date,
                    ),
                ],
                match_func=parser_factory(r'DATE (\d{2}/\d{2}/\d{4})\n'),
                scope='page',
            ),
            PDFParsingParams(
                cols=[
                    BusinessUnitsModel.entity_1.return_variant(
                        overwrite='preserve',
                        memorization='doc',
                    ),
                ],
                match_func=parser_factory(
                    r'TYPE FACTURE (?:LOYER|MAINTENANCE) +(?:DD )?([\S ]+)\n'
                ),
                scope='page',
            ),
            PDFParsingParams(
                cols=[
                    VehiclesModel.plate_number.return_variant(
                        overwrite='allow',
                        memorization='doc',
                    ),
                    VehicleContractsModel.contract_reference.return_variant(
                        overwrite='allow',
                        memorization='doc',
                    ),
                    VehiclesModel.full_model.return_variant(
                        overwrite='allow',
                        memorization='doc',
                    ),
                    VehiclesModel.make.return_variant(
                        overwrite='allow',
                        memorization='doc',
                    ),
                ],
                match_func=parser_factory(
                    r'1 ?: ?([A-Z]{2}-\d{3}-[A-Z]{2}) 2 ?: ?(\S+) '
                    r'3 ?: ?((\S+)(?:(?!4).)*)'
                ),
                scope='line',
            ),
            PDFParsingParams(
                cols=[
                    CollaboratorsModel.employee_full_name.return_variant(
                        overwrite='allow',
                        memorization='doc',
                        post_processing=convert_names(self.organization_name),
                    ),
                    BusinessUnitsModel.entity_ref.return_variant(
                        overwrite='allow',
                        memorization='doc',
                    ),
                ],
                match_func=parser_factory(
                    r'4 ?: ?(.*) (?:5|S)\$? ?:(\S*) 6'
                ),
                scope='line',
            ),
            PDFParsingParams(
                cols=[
                    VehiclesModel.entry_into_fleet_date.return_variant(
                        overwrite='allow',
                        memorization='doc',
                        optional=True,
                    ),
                ],
                match_func=parser_factory(
                    r'6 ?: ?(\d{2}/\d{2}/\d{4}) '
                ),
                scope='line',
            ),
            PDFParsingParams(
                cols=[
                    VehicleContractsModel.lease_end_date.return_variant(
                        overwrite='allow',
                        memorization='doc',
                        optional=True,
                    ),
                ],
                match_func=parser_factory(
                    r'7 ?: ?(\d{2}/\d{2}/\d{4})'
                ),
                scope='line',
            ),
            PDFParsingParams(
                cols=[
                    VehicleContractsModel.lease_months.return_variant(
                        overwrite='allow',
                        memorization='doc',
                    ),
                    VehicleContractsModel.lease_mileage.return_variant(
                        overwrite='allow',
                        memorization='doc',
                        post_processing=convert_numeric,
                    ),
                ],
                match_func=parser_factory(
                    r'8 ?: ?(\d+)/(\d+)'
                ),
                scope='line'
            ),
            PDFParsingParams(
                cols=[
                    ExpensesModel.product,
                    ExpensesModel.quantity.return_variant(
                        post_processing=convert_numeric
                    ),
                    ExpensesModel.unit_price.return_variant(
                        post_processing=convert_numeric
                    ),
                    ExpensesModel.vat_rate.return_variant(
                        post_processing=convert_numeric
                    ),
                    ExpensesModel.amount_tax_exc.return_variant(
                        post_processing=convert_numeric
                    ),
                    ExpensesModel.vat_amount.return_variant(
                        post_processing=convert_numeric
                    ),
                    ExpensesModel.amount_tax_inc.return_variant(
                        post_processing=convert_numeric
                    ),
                ],
                match_func=parser_factory(
                    r'[A-Z]{2}-\d{3}-[A-Z]{2} Gestion pour compte '
                    r'([A-Z ]+) (?:\(rempl\.? ?1?\)?)? *(\d) '
                    r'((?:\d{1,3} ?)*\d{1,3},\d{2}) '
                    r'(\d{1,2}(?:,\d{2})?) '
                    r'((?:\d{1,3} ?)*\d{1,3},\d{2}) '
                    r'((?:\d{1,3} ?)*\d{1,3},\d{2}) (?:\| )?'
                    r'((?:\d{1,3} ?)*\d{1,3},\d{2})'
                ),
                scope='line',
            ),
        ]
        expense_df = self.agg_pdf(
            eligible_files=[
                os.path.join(self.folder, file_name)
                for file_name in os.listdir(self.folder)
                if re.match(
                    r'C\d{5}_INV\d+_(?:LOYER(:?-DD)?|MAINTENANCE)_\d{6}.pdf',
                    file_name,
                )
            ],
            read_param_lst=[{}, {}, {'dpi': 400}],
            check_len_dict=expenses_check_dict,
            param_lst=[
                # Format 1: e.g. C56577_INV05249198_LOYER-DD_122023.pdf
                [
                    PDFParsingParams(
                        cols=[
                            ExpensesModel.billing_date.return_variant(
                                overwrite='preserve',
                                memorization='doc',
                            ),
                        ],
                        match_func=parser_factory(
                            r'DATE (\d{2}/\d{2}/\d{4})\n',
                        ),
                        scope='page',
                    ),
                    PDFParsingParams(
                        cols=[
                            BusinessUnitsModel.entity_1.return_variant(
                                overwrite='preserve',
                                memorization='doc',
                            ),
                        ],
                        match_func=parser_factory(
                            r'TYPE FACTURE (?:LOYER|MAINTENANCE) +(?:DD )?'
                            r'([\S ]+)\n'
                        ),
                        scope='page',
                    ),
                    PDFParsingParams(
                        cols=[
                            VehiclesModel.plate_number.return_variant(
                                overwrite='allow',
                                memorization='doc',
                            ),
                            VehicleContractsModel.contract_reference.return_variant(
                                overwrite='allow',
                                memorization='doc',
                            ),
                            VehiclesModel.full_model.return_variant(
                                overwrite='allow',
                                memorization='doc',
                            ),
                            VehiclesModel.make.return_variant(
                                overwrite='allow',
                                memorization='doc',
                            ),
                        ],
                        match_func=parser_factory(
                            r'(?:1:?|2:?|:)? ?([A-Z]{2}-\d{3}-[A-Z]{2}) '
                            r'2 ?: ?(\S+) 3 ?: ?((\S+)(?:(?!4).)*)'
                        ),
                        scope='line',
                    ),
                    PDFParsingParams(
                        cols=[
                            CollaboratorsModel.employee_full_name.return_variant(
                                overwrite='allow',
                                memorization='doc',
                                post_processing=convert_names(
                                    self.organization_name
                                ),
                            ),
                            BusinessUnitsModel.entity_ref.return_variant(
                                overwrite='allow',
                                memorization='doc',
                            ),
                            VehiclesModel.entry_into_fleet_date.return_variant(
                                overwrite='allow',
                                memorization='doc',
                            ),
                        ],
                        match_func=parser_factory(
                            r'4? ?: ?(.*) 5?S?\$? ?:(\S*) 6 ?: '
                            r'?(\d{2}/\d{2}/\d{4}) '
                        ),
                        scope='line',
                    ),
                    PDFParsingParams(
                        cols=[
                            VehicleContractsModel.lease_end_date.return_variant(
                                overwrite='allow',
                                memorization='doc',
                            ),
                        ],
                        match_func=parser_factory(
                            r'7 ?: ?(\d{2}/\d{2}/\d{4})'
                        ),
                        scope='line',
                    ),
                    PDFParsingParams(
                        cols=[
                            VehicleContractsModel.lease_months.return_variant(
                                overwrite='allow',
                                memorization='doc',
                            ),
                            VehicleContractsModel.lease_mileage.return_variant(
                                overwrite='allow',
                                memorization='doc',
                                post_processing=convert_numeric,
                            ),
                        ],
                        match_func=parser_factory(
                            r'8 ?: ?(\d+)/(\d+)'
                        ),
                        scope='line'
                    ),
                    PDFParsingParams(
                        cols=[
                            ExpensesModel.product,
                            ExpensesModel.quantity.return_variant(
                                post_processing=convert_quantity,
                            ),
                            ExpensesModel.vat_rate.return_variant(
                                post_processing=convert_numeric
                            ),
                            ExpensesModel.amount_tax_exc.return_variant(
                                post_processing=convert_numeric
                            ),
                            ExpensesModel.vat_amount.return_variant(
                                post_processing=convert_numeric
                            ),
                            ExpensesModel.amount_tax_inc.return_variant(
                                post_processing=convert_numeric
                            ),
                        ],
                        match_func=parser_factory(
                            r'(.*) \d{2}/\d{4} (\d{2}/\d{2}) (\d{1,2},\d{2})'
                            r' ((?:\d{1,3} ?)*\d{1,3},\d{2}) '
                            r'((?:\d{1,3} ?)*\d{1,3},\d{2}) (?:\| )?'
                            r'((?:\d{1,3} ?)*\d{1,3},\d{2})'
                        ),
                        scope='line',
                    ),
                ],
                # Format 2 e.g. C56577_INV05341622_MAINTENANCE_032024.pdf
                format_2_expenses,
                # Format 3 same as previous but DPI 400
                format_2_expenses,
            ],
            record_dates=[ExpensesModel.billing_date.name],
            source_table=AlphabetTables.expenses.value,
            use_ocr=True,
        )
        expense_df = self.categorize(expense_df)
        check_vat_consistency(expense_df)
        setattr(
            self,
            AlphabetTables.expenses.value,
            expense_df
        )
        return expense_df

    def import_tvs(self) -> pd.DataFrame:
        tvs_df = self.agg_pdf_table(
            eligible_files=[
                os.path.join(self.folder, file_name)
                for file_name in os.listdir(self.folder)
                if re.match(
                    r'TVS_CC_C\d{5}_20\d{2}\.pdf',
                    file_name,
                )
            ],
            col_lst=[
                BusinessUnitsModel.entity_1.return_variant(
                    post_processing=convert_new_lines,
                ),
                VehiclesModel.plate_number,
                CollaboratorsModel.employee_full_name.return_variant(
                    post_processing=convert_names(self.organization_name),
                ),
                VehiclesModel.full_model.return_variant(
                    post_processing=convert_new_lines,
                ),
                VehicleContractsModel.contract_reference,
                VehiclesModel.entry_into_service_date,
                VehicleContractsModel.lease_start_date,
                TaxesModel.tax_status_end_date,
                VehicleContractsModel.lease_month_and_mileage,  # Need to separate
                VehiclesModel.theoretical_CO2_per_km,
                VehiclesModel.energy,
                BusinessUnitsModel.cost_center,
                TaxesModel.nb_days,
                TaxesModel.tax_corporate_vehicles.return_variant(
                    post_processing=lambda x: convert_numeric(
                        x.mask(x == '', 0)
                    )
                ),
                TaxesModel.tax_pollutant,
            ],
            record_dates=[],
            source_table=AlphabetTables.corporate_vehicle_tax.value,
            bounding_box=(20, 100, 800, 550),
            skip_cols=lambda x: x.iloc[:, 2:17],
            skip_rows=lambda x: x.loc[
                ~x[3].isin(
                    ['NaN', 'Immatric\nulation', ''],
                ) & (x[16] != 'Total: ') & (x[5] != ''),
            ],
        )
        tvs_df[VehicleContractsModel.lease_months.name] = convert_numeric(
            tvs_df[
                VehicleContractsModel.lease_month_and_mileage.name
            ].str.split(' / ').str[0]
        )
        tvs_df[VehicleContractsModel.lease_mileage.name] = convert_numeric(
            tvs_df[
                VehicleContractsModel.lease_month_and_mileage.name
            ].str.split(' / ').str[1]
        )
        tvs_df.drop(
            VehicleContractsModel.lease_month_and_mileage.name,
            axis=1,
            inplace=True,
        )
        setattr(
            self,
            AlphabetTables.corporate_vehicle_tax.value,
            tvs_df,
        )
        return tvs_df

    def import_and(self) -> pd.DataFrame:
        and_df = self.agg_pdf_table(
            eligible_files=[
                os.path.join(self.folder, file_name)
                for file_name in os.listdir(self.folder)
                if re.match(
                    r'AND_CC_C\d{5}_20\d{2}\.pdf',
                    file_name,
                )
            ],
            col_lst=[
                BusinessUnitsModel.entity_1.return_variant(
                    post_processing=convert_new_lines,
                ),
                VehiclesModel.plate_number,
                CollaboratorsModel.employee_full_name.return_variant(
                    post_processing=convert_names(self.organization_name),
                ),
                VehiclesModel.full_model.return_variant(
                    post_processing=convert_new_lines,
                ),
                VehicleContractsModel.contract_reference,
                VehicleContractsModel.lease_start_date,
                TaxesModel.tax_status_end_date,
                VehicleContractsModel.lease_month_and_mileage,  # Need to separate
                VehiclesModel.theoretical_CO2_per_km,
                VehiclesModel.rebate_price_ttc.return_variant(
                    post_processing=convert_numeric,
                ),
                TaxesModel.amortization_deduction.return_variant(
                    post_processing=convert_numeric,
                ),
                TaxesModel.monthly_non_deductible_amortization.return_variant(
                    post_processing=convert_numeric,
                ),
                TaxesModel.nb_months.return_variant(
                    post_processing=convert_numeric,
                ),
                TaxesModel.declared_non_deductible_amortization.return_variant(
                    post_processing=convert_numeric,
                ),
            ],
            record_dates=[TaxesModel.tax_status_end_date.name],
            source_table=AlphabetTables.non_deductible_amortization.value,
            bounding_box=(20, 135, 1100, 725),
            skip_cols=lambda x: x.iloc[:, 3:],
            skip_rows=lambda x: x.loc[~x[1].isin(['Groupe', '1'])],
        )
        and_df[VehicleContractsModel.lease_months.name] = convert_numeric(
            and_df[
                VehicleContractsModel.lease_month_and_mileage.name
            ].str.split(' / ').str[0]
        )
        and_df[VehicleContractsModel.lease_mileage.name] = convert_numeric(
            and_df[
                VehicleContractsModel.lease_month_and_mileage.name
            ].str.split(' / ').str[1]
        )
        and_df.drop(
            VehicleContractsModel.lease_month_and_mileage.name,
            axis=1,
            inplace=True,
        )
        setattr(
            self,
            AlphabetTables.non_deductible_amortization.value,
            and_df,
        )
        return and_df

    @staticmethod
    def categorize(df: pd.DataFrame) -> pd.DataFrame:
        """ Categorize expense transactions assigning them a SoonGo Category.

        :param df: expense dataframe with a product column

        :returns: df with an expense_category column
        """
        df[ExpensesModel.expense_category.name] = (
            df[ExpensesModel.product.name].map(
                {
                    'COURROIE DISTRIBUTION': CostCategory.real_repairs.value,
                    'ECRAN THERMIQUE': CostCategory.real_repairs.value,
                    'RADIATEUR CHAUFFAGE': CostCategory.real_repairs.value,
                    'ECH STANDARD MOTEUR': CostCategory.real_repairs.value,
                    'Entretien et Assistance 24/24': CostCategory.rent_maintenance.value,
                    'Loyer Financier': CostCategory.financial_rent.value,
                    'Pastille CritAir': CostCategory.real_others.value,
                    'Perte Financiére': CostCategory.rent_financial_loss.value,
                }
            )
        )
        missing_categories = pd.isna(df[ExpensesModel.expense_category.name])
        if missing_categories.any():
            missed_products = df.loc[
                missing_categories,
                ExpensesModel.product.name,
            ].unique()
            raise ValueError(
                f'Missing category for products {missed_products}'
            )
        return df


def convert_quantity(
    series: pd.Series,
):
    return (
        convert_numeric(
            convert_string(series).str.split('/').str[0]
        ) /
        convert_numeric(
            convert_string(series).str.split('/').str[1]
        )
    )


def convert_new_lines(
    series: pd.Series
):
    return convert_string(series).str.replace(
        '\n',
        ' ',
    )


def convert_day_first_date(str_series: pd.Series) -> pd.Series:
    return convert_date(
        str_series,
        date_format=r'%d/%m/%Y',
    )


if __name__ == '__main__':
    import yaml

    organisation_name = 'Domino'
    connector_name = 'ALPHABET'
    config_file = os.path.join(
        os.path.dirname(
            os.path.dirname(
                os.path.realpath(__file__)
            )
        ),
        'connector_config.yaml',
    )

    with open(config_file) as config_path:
        connector_params = yaml.safe_load(
            config_path
        )[organisation_name][connector_name]

    flease_data = AlphabetData(
        folder='/home/matthieuglotz/Documents/Data/Domino/ALPHABET',
        organization_name=organisation_name,
        **connector_params,
    )
    i = 0
    for df in flease_data:
        df.to_csv(f'~/dev/temp/alphabet_df_{i}.csv')
        i += 1
        print(df)
