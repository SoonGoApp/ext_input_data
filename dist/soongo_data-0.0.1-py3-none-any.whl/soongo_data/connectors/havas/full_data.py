""" Havas Data

Class loading, normalizing and organizing all GAC Datasets for a given
organization
"""
import os
import re
import typing
from enum import Enum, unique

from data_models import (
    CollaboratorsModel, TrainPlaneTravelModel, HotelsModel, RentalCarsModel,
    BusinessUnitsModel
)
from utils.logging import gen_logger
from utils.dataset import Dataset, add_connector
from utils.enums import TravelTypes, SynchronizationTypes
from utils.type import convert_names


@unique
class HavasTables(Enum):
    train_planes = 'TRAIN_PLANES'
    hotel = 'HOTEL'
    rental_car = 'RENTAL_CAR'
    other_fees = 'OTHER_FEES'
    combined_travels = 'COMBINED_TRAVELS'


@add_connector
class HavasData(Dataset):
    SOURCE_CONNECTOR = 'HAVAS'
    NAME = 'HAVAS'
    TYPE = SynchronizationTypes.csv_upload.value

    def __init__(
        self,
        folder: str,
        organization_name: str,
        log_file: typing.Optional[str] = None,
    ) -> None:
        """ Instantiates HavasData object containing all the Havas tables

        :param folder: str path to the root folder where all the data is
            stored.
        :param log_file: file where to write logs

        :raises ValueError: if folder is not a valid path or does not
        contain all required subfolders
        """
        super().__init__(
            folder=folder,
            logger=gen_logger(
                name=self.__class__.__name__,
                file_path=log_file,
            ),
            source_connector=self.SOURCE_CONNECTOR,
            name=self.NAME,
            type=self.TYPE,
            organization_name=organization_name,
        )
        if not os.path.isdir(os.path.expanduser(folder)):
            raise ValueError(
                f'Provided root folder {folder} is not a valid directory'
            )
        self.import_air_rail()
        self.load_table(
            file_path=os.path.join(folder, 'hotel.xlsx'),
            col_lst=[
                HotelsModel.expense_id.return_variant(
                    raw_name='ID Interne',
                ),
                BusinessUnitsModel.organization_name,
                BusinessUnitsModel.organization_id,
                HotelsModel.billing_id,
                HotelsModel.billing_date.return_variant(
                    raw_name='Date Document',  # TODO: Check indeed equivalent
                ),
                HotelsModel.transaction_type,
                HotelsModel.booking_date,
                HotelsModel.booking_method,
                CollaboratorsModel.employee_full_name.return_variant(
                    raw_name='Voyageur principal',
                    post_processing=convert_names(self.organization_name)
                ),
                HotelsModel.demander,
                HotelsModel.supplier.return_variant(
                    raw_name='Hôtel',
                ),
                HotelsModel.start_country_code.return_variant(
                    raw_name='Code pays Hôtel',
                ),
                HotelsModel.start_country_name.return_variant(
                    raw_name='Pays Hôtel',
                ),
                HotelsModel.start_continent_name.return_variant(
                    raw_name='Continent Hôtel',
                ),
                HotelsModel.travel_level,
                HotelsModel.hotel_postal_code,
                HotelsModel.start_city.return_variant(
                    raw_name='Ville Hôtel',
                ),
                HotelsModel.hotel_phone_number,
                HotelsModel.start_datetime.return_variant(
                    raw_name='Date début',
                ),
                HotelsModel.end_datetime.return_variant(
                    raw_name='Date fin',
                ),
                HotelsModel.room_type,
                HotelsModel.room_count,
                HotelsModel.night_count,
                HotelsModel.room_night_count,
                HotelsModel.price_per_room_night,
                HotelsModel.amount_fees,
                HotelsModel.amount_tax_inc.return_variant(
                    raw_name='Prix total TTC',
                ),
                HotelsModel.booking_type,
                HotelsModel.was_negotiated,
                HotelsModel.negotiated_fare_code,
                HotelsModel.internal_category_1,
                HotelsModel.internal_category_2,
                HotelsModel.internal_category_3,
                HotelsModel.internal_category_4,
                HotelsModel.internal_category_5,
                HotelsModel.internal_category_6,
                HotelsModel.internal_category_7,
                HotelsModel.internal_category_8,
                HotelsModel.approver,
                HotelsModel.anticipated_days,
                HotelsModel.hotel_address_1,
                HotelsModel.hotel_address_2,
            ],
            skip_cols=['Client'],
            record_dates=[
                HotelsModel.billing_date.name,
                HotelsModel.booking_date.name,
            ],
            source_table=HavasTables.hotel.value,
        )

        self.load_table(
            file_path=os.path.join(folder, 'voiture.xlsx'),
            col_lst=[
                RentalCarsModel.expense_id.return_variant(
                    raw_name='ID Interne',
                ),
                BusinessUnitsModel.organization_name,
                BusinessUnitsModel.organization_id,
                RentalCarsModel.billing_id,
                RentalCarsModel.billing_date.return_variant(
                    raw_name='Date Document',  # TODO: Check indeed equivalent
                ),
                RentalCarsModel.transaction_type,
                RentalCarsModel.booking_date,
                RentalCarsModel.booking_method,
                CollaboratorsModel.employee_full_name.return_variant(
                    raw_name='Voyageur principal',
                    post_processing=convert_names(self.organization_name),
                ),
                RentalCarsModel.demander,
                RentalCarsModel.supplier.return_variant(
                    raw_name='Fournisseur'
                ),
                RentalCarsModel.car_segment,
                RentalCarsModel.car_type,
                RentalCarsModel.travel_level,
                RentalCarsModel.start_continent_name.return_variant(
                    raw_name='Continent Prise',
                ),
                RentalCarsModel.start_country_name.return_variant(
                    raw_name='Pays prise',
                ),
                RentalCarsModel.start_city.return_variant(
                    raw_name='Ville prise',
                ),
                RentalCarsModel.start_datetime.return_variant(
                    raw_name='Date prise',
                ),
                RentalCarsModel.arrival_continent_name.return_variant(
                    raw_name='Continent remise'
                ),
                RentalCarsModel.arrival_country_name.return_variant(
                    raw_name='Pays remise'
                ),
                RentalCarsModel.arrival_city.return_variant(
                    raw_name='Ville remise',
                ),
                RentalCarsModel.end_datetime.return_variant(
                    raw_name='Date remise',
                ),
                RentalCarsModel.rental_day_count,
                RentalCarsModel.price_per_day,
                RentalCarsModel.amount_fees,
                RentalCarsModel.amount_tax_inc.return_variant(
                    raw_name='Prix total TTC'
                ),
                RentalCarsModel.negotiated_fare_code,
                RentalCarsModel.booking_type,
                RentalCarsModel.internal_category_1,
                RentalCarsModel.internal_category_2,
                RentalCarsModel.internal_category_3,
                RentalCarsModel.internal_category_4,
                RentalCarsModel.internal_category_5,
                RentalCarsModel.internal_category_6,
                RentalCarsModel.internal_category_7,
                RentalCarsModel.internal_category_8,
                RentalCarsModel.approver,
                RentalCarsModel.anticipated_days,
            ],
            skip_cols=['Client'],
            record_dates=[
                RentalCarsModel.billing_date.name,
                RentalCarsModel.booking_date.name,
            ],
            source_table=HavasTables.rental_car.value,
        )
        self.load_table(
            file_path=os.path.join(folder, 'divers.xlsx'),
            col_lst=[
                TrainPlaneTravelModel.expense_id.return_variant(
                    raw_name='ID Interne',
                ),
                BusinessUnitsModel.organization_name,
                BusinessUnitsModel.organization_id,
                TrainPlaneTravelModel.billing_id,
                TrainPlaneTravelModel.billing_date.return_variant(
                    raw_name='Date Document',  # TODO: Check indeed equivalent
                ),
                TrainPlaneTravelModel.transaction_type,
                TrainPlaneTravelModel.booking_date,
                TrainPlaneTravelModel.booking_method,
                CollaboratorsModel.employee_full_name.return_variant(
                    raw_name='Voyageur principal',
                    post_processing=convert_names(self.organization_name),
                ),
                TrainPlaneTravelModel.demander,
                TrainPlaneTravelModel.activity_type,
                TrainPlaneTravelModel.travel_cost_type,
                TrainPlaneTravelModel.service_ref,
                TrainPlaneTravelModel.service_type,
                TrainPlaneTravelModel.base_service,
                TrainPlaneTravelModel.amount_tax_exc,
                TrainPlaneTravelModel.amount_tax_inc.return_variant(
                    raw_name='Montant TTC',
                ),
                TrainPlaneTravelModel.airport_tax.return_variant(
                    raw_name='Montant Taxes'
                ),
                TrainPlaneTravelModel.cabin_class,
                TrainPlaneTravelModel.pnr,
                TrainPlaneTravelModel.routing,
                TrainPlaneTravelModel.routing_countries,
                TrainPlaneTravelModel.travel_level,
                TrainPlaneTravelModel.internal_category_1,
                TrainPlaneTravelModel.internal_category_2,
                TrainPlaneTravelModel.internal_category_3,
                TrainPlaneTravelModel.internal_category_4,
                TrainPlaneTravelModel.internal_category_5,
                TrainPlaneTravelModel.internal_category_6,
                TrainPlaneTravelModel.internal_category_7,
                TrainPlaneTravelModel.internal_category_8,
                TrainPlaneTravelModel.approver,
                TrainPlaneTravelModel.anticipated_days,
            ],
            skip_cols=['Client'],
            record_dates=[
                TrainPlaneTravelModel.billing_date.name,
                TrainPlaneTravelModel.booking_date.name,
            ],
            source_table=HavasTables.other_fees.value,
        )
        self.import_all_combined()

    def import_air_rail(self):
        try:
            train_planes_df = self.agg_and_meld(
                eligible_files=[
                    os.path.join(self.folder, file_name)
                    for file_name in os.listdir(self.folder)
                    if re.match(r'air_fer_coupons(?:_\d{4})?\.xlsx', file_name)
                ],
                id_cols=[
                    TrainPlaneTravelModel.expense_id,
                    TrainPlaneTravelModel.leg_id,
                    BusinessUnitsModel.organization_name,
                    BusinessUnitsModel.organization_id,
                    TrainPlaneTravelModel.billing_id,
                    TrainPlaneTravelModel.billing_date,
                    TrainPlaneTravelModel.transaction_type,
                    TrainPlaneTravelModel.booking_date,
                    CollaboratorsModel.employee_full_name.return_variant(
                        raw_name='Voyageur principal',
                        post_processing=convert_names(self.organization_name),
                    ),
                    TrainPlaneTravelModel.booking_method,
                    TrainPlaneTravelModel.rail_code_type,
                    TrainPlaneTravelModel.rail_ticket_type,
                    TrainPlaneTravelModel.ticket_type,
                    TrainPlaneTravelModel.used_tickets,
                    TrainPlaneTravelModel.generated_tickets,
                    TrainPlaneTravelModel.amount_tax_inc,
                    TrainPlaneTravelModel.airport_tax,
                    TrainPlaneTravelModel.travel_type,
                    TrainPlaneTravelModel.ticket_ref,
                    TrainPlaneTravelModel.leg_number,
                    TrainPlaneTravelModel.pnr,
                    TrainPlaneTravelModel.start_location_code,
                    TrainPlaneTravelModel.start_station_code,
                    TrainPlaneTravelModel.start_location_name,
                    TrainPlaneTravelModel.start_city,
                    TrainPlaneTravelModel.start_country_code,
                    TrainPlaneTravelModel.start_country_name,
                    TrainPlaneTravelModel.start_continent_name,
                    TrainPlaneTravelModel.arrival_location_code,
                    TrainPlaneTravelModel.arrival_station_code,
                    TrainPlaneTravelModel.arrival_location_name,
                    TrainPlaneTravelModel.arrival_city,
                    TrainPlaneTravelModel.arrival_country_code,
                    TrainPlaneTravelModel.arrival_country_name,
                    TrainPlaneTravelModel.arrival_continent_name,
                    TrainPlaneTravelModel.routing,
                    TrainPlaneTravelModel.travel_level,
                    TrainPlaneTravelModel.supplier_code,
                    TrainPlaneTravelModel.supplier,
                    TrainPlaneTravelModel.supplier_alliance,
                    TrainPlaneTravelModel.transporter_code,
                    TrainPlaneTravelModel.transporter_name,
                    TrainPlaneTravelModel.transport_ref,
                    TrainPlaneTravelModel.transport_class,
                    TrainPlaneTravelModel.cabin_class,
                    TrainPlaneTravelModel.start_datetime,
                    TrainPlaneTravelModel.end_datetime,
                    TrainPlaneTravelModel.travel_time,
                    TrainPlaneTravelModel.layover_time,
                    TrainPlaneTravelModel.distance,
                    TrainPlaneTravelModel.CO2_footprint,
                    TrainPlaneTravelModel.internal_category_1,
                    TrainPlaneTravelModel.internal_category_2,
                    TrainPlaneTravelModel.internal_category_3,
                    TrainPlaneTravelModel.internal_category_4,
                    TrainPlaneTravelModel.internal_category_5,
                    TrainPlaneTravelModel.internal_category_6,
                    TrainPlaneTravelModel.internal_category_7,
                    TrainPlaneTravelModel.internal_category_8,
                    TrainPlaneTravelModel.approver,
                    TrainPlaneTravelModel.fare_class,
                    TrainPlaneTravelModel.fare_class_rail,
                    TrainPlaneTravelModel.leg_count,
                ],
                value_col=None,
                var_col=None,
                skip_cols=['Client'],
                record_dates=[
                    TrainPlaneTravelModel.billing_date.name,
                    TrainPlaneTravelModel.booking_date.name,
                ],
                source_table=HavasTables.train_planes.value,
                meld=False,
            )
        except ValueError:
            train_planes_df = self.load_table(
                file_path=os.path.join(
                    self.folder,
                    'air_fer_coupons.xlsx',
                ),
                col_lst=[
                    TrainPlaneTravelModel.expense_id.return_variant(
                        raw_name='ID Interne',
                    ),
                    BusinessUnitsModel.organization_name,
                    BusinessUnitsModel.organization_id,
                    TrainPlaneTravelModel.billing_id,
                    TrainPlaneTravelModel.billing_date.return_variant(
                        raw_name='Date Document',
                    ),
                    TrainPlaneTravelModel.booking_date,
                    CollaboratorsModel.employee_full_name.return_variant(
                        raw_name='Voyageur principal',
                        post_processing=convert_names(self.organization_name)
                    ),
                    TrainPlaneTravelModel.demander.return_variant(
                        raw_name='Demandeur'
                    ),
                    TrainPlaneTravelModel.booking_method,
                    TrainPlaneTravelModel.rail_ticket_type.return_variant(
                        raw_name='Type Billet Rail',
                    ),
                    TrainPlaneTravelModel.ticket_type.return_variant(
                        raw_name='Type Trajet',
                    ),
                    TrainPlaneTravelModel.is_low_cost,
                    TrainPlaneTravelModel.used_tickets,
                    TrainPlaneTravelModel.generated_tickets,
                    TrainPlaneTravelModel.amount_tax_inc.return_variant(
                        raw_name='Prix payé',
                    ),
                    TrainPlaneTravelModel.airport_tax.return_variant(
                        raw_name='Montant Taxes',
                    ),
                    TrainPlaneTravelModel.travel_type,
                    TrainPlaneTravelModel.ticket_ref.return_variant(
                        raw_name='N° Billet',
                    ),
                    TrainPlaneTravelModel.pnr,
                    TrainPlaneTravelModel.start_location_code,
                    TrainPlaneTravelModel.start_station_code,
                    TrainPlaneTravelModel.start_location_name.return_variant(
                        raw_name='Lieu départ',
                    ),
                    TrainPlaneTravelModel.start_city,
                    TrainPlaneTravelModel.start_country_code,
                    TrainPlaneTravelModel.start_country_name,
                    TrainPlaneTravelModel.arrival_location_code.return_variant(
                        raw_name='Code lieu dest',
                    ),
                    TrainPlaneTravelModel.arrival_station_code.return_variant(
                        raw_name='Code gare NLS dest',
                    ),
                    TrainPlaneTravelModel.arrival_location_name.return_variant(
                        raw_name='Lieu dest',
                    ),
                    TrainPlaneTravelModel.arrival_city.return_variant(
                        raw_name='Ville dest',
                    ),
                    TrainPlaneTravelModel.arrival_country_code.return_variant(
                        raw_name='Code pays dest',
                    ),
                    TrainPlaneTravelModel.arrival_country_name.return_variant(
                        raw_name='Pays dest',
                    ),
                    TrainPlaneTravelModel.arrival_continent_name.return_variant(
                        raw_name="Continent dest",
                    ),
                    TrainPlaneTravelModel.routing,
                    TrainPlaneTravelModel.travel_level,
                    TrainPlaneTravelModel.supplier_code.return_variant(
                        raw_name='Code Cie',
                    ),
                    TrainPlaneTravelModel.supplier.return_variant(
                        raw_name='Compagnie',
                    ),
                    TrainPlaneTravelModel.supplier_alliance,
                    TrainPlaneTravelModel.cabin_class,
                    TrainPlaneTravelModel.start_datetime,
                    TrainPlaneTravelModel.end_datetime.return_variant(
                        raw_name='Date fin',
                    ),
                    TrainPlaneTravelModel.internal_category_1,
                    TrainPlaneTravelModel.internal_category_2,
                    TrainPlaneTravelModel.internal_category_3,
                    TrainPlaneTravelModel.internal_category_4,
                    TrainPlaneTravelModel.internal_category_5,
                    TrainPlaneTravelModel.internal_category_6,
                    TrainPlaneTravelModel.internal_category_7,
                    TrainPlaneTravelModel.internal_category_8,
                    TrainPlaneTravelModel.approver,
                    TrainPlaneTravelModel.fare_class.return_variant(
                        raw_name='Classe tarifaire',
                    ),
                    TrainPlaneTravelModel.leg_count,
                ],
                skip_cols=[
                    'Client',
                    'Prestation',
                    r'% économies manquées',
                    'Type document',
                    'Trajet complet',
                    'Motif Refus',
                    r'% Economie réalisée',
                    'Prix proposé',
                    'Date émission',
                    r'% Economie potentielle',
                    'Type de transaction',
                    'Montant Economie réalisée',
                    'Transport service annexe',
                    'Anticipation jours',
                    'Transport',
                    'Motif Economie',
                    'Economies manquées',
                    'Montant Economie potentielle', 
                    'Routing pays',
                    'Montant Frais induits',
                    'Prix de référence',
                    'Durée jours',
                ],
                record_dates=[
                    TrainPlaneTravelModel.billing_date.name,
                    TrainPlaneTravelModel.booking_date.name,
                ],
                source_table=HavasTables.train_planes.value,
            )
        rail_val = TravelTypes.rail.value
        not_rail_cond = (
            train_planes_df[TrainPlaneTravelModel.travel_type.name] != rail_val
        )
        for location_col in [
            TrainPlaneTravelModel.start_location_code.name,
            TrainPlaneTravelModel.arrival_location_code.name,
        ]:
            train_planes_df[location_col] = (
                train_planes_df[location_col].where(
                    not_rail_cond,
                    train_planes_df[
                        location_col.replace('location', 'station')
                    ],
                )
            )

    def import_all_combined(self):
        all_combined_df = self.load_table(
            file_path=os.path.join(self.folder, 'all_combined.xlsx'),
            col_lst=[
                TrainPlaneTravelModel.transaction_type,
                TrainPlaneTravelModel.booking_date,
                CollaboratorsModel.organization_employee_id,
                TrainPlaneTravelModel.travel_type.return_variant(
                    raw_name='Activité',
                ),
                TrainPlaneTravelModel.service_type,
                TrainPlaneTravelModel.start_datetime.return_variant(
                    raw_name='Date départ/début',
                ),
                TrainPlaneTravelModel.end_datetime.return_variant(
                    raw_name='Date retour/fin',
                ),
                TrainPlaneTravelModel.amount_tax_inc.return_variant(
                    raw_name='Montant Net TTC',
                ),
                HotelsModel.nb_days,
                TrainPlaneTravelModel.start_city,
                TrainPlaneTravelModel.start_location_name.return_variant(
                    raw_name='Lieu départ',
                ),
                TrainPlaneTravelModel.start_country_name,
                TrainPlaneTravelModel.arrival_location_name.return_variant(
                    raw_name='Lieu dest',
                ),
                TrainPlaneTravelModel.arrival_city.return_variant(
                    raw_name='Ville dest'
                ),
                TrainPlaneTravelModel.arrival_country_name.return_variant(
                    raw_name='Pays dest'
                ),
                TrainPlaneTravelModel.ticket_type.return_variant(
                    raw_name='Type Trajet',
                ),
                HotelsModel.night_count,
                TrainPlaneTravelModel.anticipated_days,
                TrainPlaneTravelModel.is_aligned_policy,
            ],
            skip_cols=['ref601', 'Agences'],
            record_dates=[TrainPlaneTravelModel.booking_date.name],
            source_table=HavasTables.combined_travels.value,
        )
        setattr(
            self,
            HavasTables.combined_travels.value,
            all_combined_df,
        )
        return all_combined_df


if __name__ == '__main__':
    data = HavasData(
        folder='/home/matthieuglotz/Documents/Data/Domino/HAVAS',
        organization_name='Domino'
    )
    for df in data:
        print(df)
