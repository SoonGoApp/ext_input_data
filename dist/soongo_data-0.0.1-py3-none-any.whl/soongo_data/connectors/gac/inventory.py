"""Module to import data from GAC inventory section"""
import logging
import os
from enum import Enum, unique

import pandas as pd

from data_models import (
    VehiclesModel, FuelCardsModel, VehicleEquipmentsModel,
    VehicleContractsModel, BusinessUnitsModel, CollaboratorsModel,
    VehicleReportsModel, VehicleStatusModel, VehicleOrdersModel,
    VehicleAssociationsModel, MileageReportsModel, FinesModel
)
from utils.logging import gen_logger
from utils.dataset import Dataset
from utils.enums import AssignmentType, SynchronizationTypes
from utils.type import convert_names


@unique
class GacInventoryTables(Enum):
    fuel_card = 'FUEL_CARD'
    individual_orders = 'INDIVIDUAL_ORDER'
    equipments = 'EQUIPMENTS'
    vehicles = 'VEHICLES'


class GacInventoryData(Dataset):

    NAME = 'INVENTORY'
    TYPE = SynchronizationTypes.csv_upload.value

    def __init__(
        self,
        folder: str,
        logger: logging.Logger,
        source_connector: str,
        organization_name: str,
    ):
        super().__init__(
            folder=folder,
            logger=logger,
            source_connector=source_connector,
            name=self.NAME,
            type=self.TYPE,
            organization_name=organization_name,
        )
        self.load_table(
            file_path=os.path.join(
                folder,
                'cartes_carburants.csv',
            ),
            col_lst=[
                VehicleEquipmentsModel.equipment_supplier,
                VehicleEquipmentsModel.supplier_reference,
                VehicleEquipmentsModel.equipment_family,
                VehicleEquipmentsModel.equipment_type,
                VehicleEquipmentsModel.equipment_name,
                VehicleEquipmentsModel.equipment_ref.return_variant(
                    raw_name='Référence interne',
                ),
                VehicleEquipmentsModel.equipment_start_date,
                VehicleEquipmentsModel.equipment_end_date,
                VehicleContractsModel.contract_reference,
                BusinessUnitsModel.cost_center,
                BusinessUnitsModel.entity_1,
                BusinessUnitsModel.entity_2,
                BusinessUnitsModel.entity_3,
                CollaboratorsModel.employee_last_name,
                CollaboratorsModel.employee_first_name,
                CollaboratorsModel.organization_employee_id,
                FuelCardsModel.creation_date,
                FuelCardsModel.update_date,
                VehicleEquipmentsModel.comment_2,
                VehicleEquipmentsModel.comment_3,
                FuelCardsModel.secret_code_type,
                FuelCardsModel.secret_code,
                FuelCardsModel.driver_code,
                FuelCardsModel.fuel_card_status,
                FuelCardsModel.fuel_card_status_date,
                VehicleReportsModel.expense_count,
                VehicleEquipmentsModel.comment_1,
                VehicleStatusModel.vehicle_status,
                VehicleContractsModel.contract_end_date,
                VehiclesModel.fiscal_type.return_variant(
                    raw_name='Véhicule - Genre de véhicule',
                )
            ],
            record_dates=[
                VehicleEquipmentsModel.equipment_start_date.name,
                FuelCardsModel.fuel_card_status_date.name,
            ],
            source_table=GacInventoryTables.fuel_card.value,
        )
        self.load_table(
            file_path=os.path.join(
                folder,
                'commandes_individuelles.csv',
            ),
            col_lst=[
                VehicleOrdersModel.order_reference.return_variant(
                    raw_name="#",
                ),
                VehicleOrdersModel.buyer_name,
                VehicleOrdersModel.order_status_date,
                VehicleOrdersModel.order_status,
                VehicleOrdersModel.order_step,
                CollaboratorsModel.employee_full_name.return_variant(
                    post_processing=convert_names(self.organization_name),
                ),
                BusinessUnitsModel.entity_1,
                BusinessUnitsModel.entity_2,
                BusinessUnitsModel.entity_3,
                BusinessUnitsModel.cost_center.return_variant(
                    raw_name='Centre de Coûts',
                ),
                VehicleAssociationsModel.previous_vehicle,
                VehicleOrdersModel.catalog,
                VehiclesModel.make,
                VehiclesModel.model,
                VehiclesModel.fiscal_type,
                VehiclesModel.car_supplier,
            ],
            record_dates=[
                VehicleOrdersModel.order_status_date.name,
            ],
            source_table=GacInventoryTables.individual_orders.value,
        )
        self.load_table(
            file_path=os.path.join(
                folder,
                'équipements.csv',
            ),
            col_lst=[
                VehicleEquipmentsModel.equipment_supplier,
                VehicleEquipmentsModel.supplier_reference,
                VehicleEquipmentsModel.equipment_family,
                VehicleEquipmentsModel.equipment_type,
                VehicleEquipmentsModel.equipment_name,
                VehicleEquipmentsModel.equipment_ref.return_variant(
                    raw_name='Référence interne',
                ),
                VehicleEquipmentsModel.equipment_start_date,
                VehicleEquipmentsModel.equipment_end_date,
                VehicleContractsModel.contract_reference,
                BusinessUnitsModel.cost_center,
                BusinessUnitsModel.entity_1,
                BusinessUnitsModel.entity_2,
                BusinessUnitsModel.entity_3,
                CollaboratorsModel.employee_last_name,
                CollaboratorsModel.employee_first_name,
                CollaboratorsModel.organization_employee_id,
                FuelCardsModel.creation_date,
                FuelCardsModel.update_date,
                VehicleEquipmentsModel.comment_2,
                VehicleEquipmentsModel.comment_3,
                FuelCardsModel.secret_code_type,
                FuelCardsModel.secret_code,
                FuelCardsModel.driver_code,
                VehicleEquipmentsModel.equipment_status,
                VehicleEquipmentsModel.equipment_status_date,
                VehicleReportsModel.expense_count,
                VehicleEquipmentsModel.comment_1,
                VehicleStatusModel.vehicle_status,
                VehicleContractsModel.contract_end_date,
                VehiclesModel.fiscal_type.return_variant(
                    raw_name='Véhicule - Genre de véhicule',
                ),
            ],
            record_dates=[
                VehicleEquipmentsModel.equipment_start_date.name,
                FuelCardsModel.update_date.name,
                FuelCardsModel.creation_date.name,
            ],
            source_table=GacInventoryTables.equipments.value,
        )
        self.import_vehicles()

    def import_vehicles(self) -> pd.DataFrame:
        vehicle_df = self.load_table(
            file_path=os.path.join(
                self.folder,
                'vehicules.csv',
            ),
            col_lst=[
                VehiclesModel.plate_number.return_variant(
                    raw_name='Immat..1',
                ),
                VehicleAssociationsModel.previous_vehicle,
                BusinessUnitsModel.billed_entity,
                VehicleOrdersModel.order_reference,
                VehiclesModel.car_supplier,
                VehiclesModel.make,
                VehiclesModel.model,
                VehiclesModel.full_model,
                VehiclesModel.vehicle_tag,
                VehiclesModel.fiscal_type,
                VehiclesModel.registration_type,
                VehiclesModel.fiscal_power,
                VehiclesModel.theoretical_CO2_per_km.return_variant(
                    raw_name='Émissions de CO2',
                ),
                VehiclesModel.energy,
                VehiclesModel.serial_number,
                VehiclesModel.manufacturer_price_tax_inc,
                VehiclesModel.manufacturer_price_tax_exc,
                VehiclesModel.rebate_rate,
                VehiclesModel.rebate_price_ttc,
                VehicleContractsModel.contract_type,
                VehicleOrdersModel.expected_delivery_date,
                VehiclesModel.entry_into_service_date,
                VehicleAssociationsModel.pool_vehicle,
                VehicleContractsModel.lease_start_date,
                VehicleStatusModel.vehicle_status_start_date,
                VehicleStatusModel.vehicle_status_end_date,
                VehicleContractsModel.lease_end_date,
                VehicleContractsModel.lease_months,
                VehicleContractsModel.lease_mileage,
                VehicleStatusModel.vehicle_status.return_variant(
                    raw_name='Statut actuel',
                ),
                VehicleContractsModel.lease_closure_ground,
                VehicleStatusModel.vehicle_availability,
                CollaboratorsModel.organization_employee_id,
                CollaboratorsModel.employee_last_name,
                CollaboratorsModel.employee_first_name,
                CollaboratorsModel.employee_role,
                BusinessUnitsModel.entity_1,
                BusinessUnitsModel.entity_2,
                BusinessUnitsModel.entity_3,
                BusinessUnitsModel.cost_center,
                VehicleContractsModel.financial_rent_ttc,
                VehicleContractsModel.insurance_rent_ttc,
                VehicleContractsModel.management_fee_rent_ttc,
                VehicleContractsModel.accident_management_fee_rent_ttc,
                VehicleContractsModel.tires_rent_ttc,
                VehicleContractsModel.maintenance_rent_ttc,
                VehicleContractsModel.fuel_card_management_fee_rent_ttc,
                VehicleContractsModel.relay_car_rent_ttc,
                VehicleContractsModel.roadside_assistance_rent_ttc,
                VehicleContractsModel.financial_loss_rent_ttc,
                VehicleContractsModel.electricity_rent_ttc,
                VehicleContractsModel.telematics_rent_ttc,
                VehicleContractsModel.other_rent_ttc,
                VehicleContractsModel.total_rent_ttc,
                VehicleContractsModel.is_tax_included,
                MileageReportsModel.mileage.return_variant(
                    raw_name='Kilométrage'
                ),
                MileageReportsModel.mileage_date,
                VehicleReportsModel.vehicle_avg_monthly_mileage,
                CollaboratorsModel.employee_avg_monthly_mileage,
                VehicleContractsModel.lease_comment,
                VehicleStatusModel.status_comment,
                VehicleEquipmentsModel.equipment_ref.return_variant(
                    raw_name="Carte / Equipement",
                ),
                VehicleAssociationsModel.participation,
                VehiclesModel.vehicle_age,
                VehiclesModel.vehicle_time_in_fleet,
                VehicleContractsModel.interest_rate,
                VehiclesModel.door_count,
                VehiclesModel.seat_count,
                VehiclesModel.vehicle_country,
                VehiclesModel.montain_law_applicable,
                VehiclesModel.winter_gear,
                VehiclesModel.winter_gear_type,
                VehiclesModel.to_renew,
                VehiclesModel.steps_before_issuance,
                VehiclesModel.air_quality_certificate_number,
                VehiclesModel.is_air_quality_certified,
                CollaboratorsModel.employee_internal_category,
                FinesModel.antai_status,
                FinesModel.antai_submission_date,
                FinesModel.currency.return_variant(
                    raw_name='Devise',
                ),
            ],
            record_dates=[
                VehicleContractsModel.lease_start_date.name,
                VehicleStatusModel.vehicle_status_start_date.name,
                MileageReportsModel.mileage_date.name,
            ],
            source_table=GacInventoryTables.vehicles.value,
            skip_cols=['Immat.'],
        )
        vehicle_df[VehicleAssociationsModel.assignment_type.name] = (
            AssignmentType.company_vehicle.value
        )
        setattr(
            self,
            GacInventoryTables.vehicles.value,
            vehicle_df
        )
        return vehicle_df


if __name__ == "__main__":
    logger = gen_logger("GacInventory")
    gac_export_data = GacInventoryData(
        folder=os.path.join(
            '/home/matthieuglotz/Documents/Data/Quartus/GAC',
            GacInventoryData.NAME,
        ),
        logger=logger,
        source_connector="GAC",
        organization_name='Quartus',
    )
    for dataframe in gac_export_data:
        print(dataframe)
