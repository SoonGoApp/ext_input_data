""" A module to import data from GAC fleet section"""
import logging
import os
from enum import Enum, unique

from data_models import (
    VehiclesModel, FuelCardsModel, AccidentsModel,
    VehicleContractsModel, BusinessUnitsModel, CollaboratorsModel,
    VehicleReportsModel, ExpensesModel,
    MileageReportsModel, FinesModel, VehicleMaintenanceModel
)
from utils.logging import gen_logger
from utils.dataset import Dataset
from utils.type import convert_boolean
from utils.enums import SynchronizationTypes


@unique
class GacRiskTables(Enum):
    mean_consumption = 'MEAN_CONSUMPTION'
    fines = 'FINES'
    parking_tickets = 'PARKING_TICKETS'
    maintenance = 'MAINTENANCE'
    detailed_fines = 'DETAILED_FINES'
    accidents = 'ACCIDENTS'


class GacRiskData(Dataset):

    NAME = 'RISK'
    TYPE = SynchronizationTypes.csv_upload.value

    def __init__(
        self,
        folder: str,
        logger: logging.Logger,
        source_connector: str,
        organization_name: str,
    ):
        super().__init__(
            folder=folder,
            logger=logger,
            source_connector=source_connector,
            name=self.NAME,
            type=self.TYPE,
            organization_name=organization_name,
        )
        self.load_table(
            file_path=os.path.join(folder, 'consommation_moyenne.csv'),
            col_lst=[
                VehiclesModel.plate_number,
                CollaboratorsModel.employee_first_name,
                CollaboratorsModel.employee_last_name,
                BusinessUnitsModel.entity_1,
                BusinessUnitsModel.entity_2,
                BusinessUnitsModel.entity_3,
                MileageReportsModel.kilometers_driven,
                VehicleReportsModel.fuel_consumption,
                VehiclesModel.estimated_fuel_consumption,
                VehiclesModel.manufacturer_fuel_consumption,
                VehicleReportsModel.consumption_gap,
                VehiclesModel.make,
                VehiclesModel.model,
                VehiclesModel.vehicle_internal_category,
                VehiclesModel.full_model.return_variant(
                    raw_name='Véhicule'
                ),
                FuelCardsModel.fuel_type,
                VehiclesModel.entry_into_service_date.return_variant(
                    raw_name='Date de première MEC',
                ),
                VehiclesModel.vehicle_age,
            ],
            record_dates=[VehiclesModel.entry_into_service_date.name],
            source_table=GacRiskTables.mean_consumption.value,
        )
        self.load_table(
            file_path=os.path.join(folder, 'demandes_antai.csv'),
            col_lst=[
                VehiclesModel.plate_number.return_variant(
                    raw_name='Immat.'
                ),
                FinesModel.offense_date,
                FinesModel.offense_type,
                FinesModel.antai_number,
                FinesModel.first_request_date,
                FinesModel.reminder_count,
                FinesModel.response_datetime,
                FinesModel.employee_notification_date,
                FinesModel.aknowledgement_date,
                FinesModel.antai_status.return_variant(
                    raw_name='Statut',
                ),
                CollaboratorsModel.employee_title,
                CollaboratorsModel.employee_last_name.return_variant(
                    raw_name='Nom conducteur',
                ),
                CollaboratorsModel.employee_first_name.return_variant(
                    raw_name='Prénom conducteur',
                ),
                VehicleContractsModel.lease_start_date.return_variant(
                    raw_name='Début de location',
                ),
                VehicleContractsModel.lease_end_date.return_variant(
                    raw_name='Fin théorique de location',
                ),
                BusinessUnitsModel.company_name,
                BusinessUnitsModel.company_number,
                BusinessUnitsModel.entity_1,
                BusinessUnitsModel.entity_2,
                BusinessUnitsModel.entity_3,
                BusinessUnitsModel.cost_center.return_variant(
                    raw_name='Centre de Coût',
                ),
            ],
            skip_cols=["Date d'envoi", 'N° ANTAI.1'],
            record_dates=[
                FinesModel.offense_date.name,
                FinesModel.response_datetime.name,
                FinesModel.employee_notification_date.name,
                FinesModel.aknowledgement_date.name,
                VehicleContractsModel.lease_start_date.name,
            ],
            source_table=GacRiskTables.fines.value,
        )
        self.load_table(
            file_path=os.path.join(folder, 'fps_détaillés.csv'),
            col_lst=[
                VehiclesModel.plate_number,
                FinesModel.fine_ref,
                FinesModel.offense_date.return_variant(
                    raw_name="Date de l'évènement",
                ),
                CollaboratorsModel.employee_first_name,
                CollaboratorsModel.employee_last_name,
                BusinessUnitsModel.billed_entity.return_variant(
                    raw_name='Entité FPS'
                ),
                FinesModel.surcharge_date,
                FinesModel.total_cost,
                FinesModel.fine_status,
                FinesModel.ticket_last_send,
                FinesModel.ticket_send_n1,
                FinesModel.ticket_send_n2,
                BusinessUnitsModel.employee_entity,
                CollaboratorsModel.organization_employee_id,
                FinesModel.surcharge_ref,
                FinesModel.ticket_base_value,
                FinesModel.surcharge_value,
                FinesModel.offense_comment,
                FinesModel.fine_payer,
                FinesModel.creation_date.return_variant(
                    raw_name='Date de création',
                ),
                BusinessUnitsModel.cost_center.return_variant(
                    raw_name='Centre de Coût',
                ),
            ],
            record_dates=[
                FinesModel.offense_date.name,
                FinesModel.surcharge_date.name,
                FinesModel.creation_date.name,
            ],
            source_table=GacRiskTables.parking_tickets.value,
        )
        self.load_table(
            file_path=os.path.join(folder, 'maintenance.csv'),
            col_lst=[
                VehiclesModel.plate_number,
                CollaboratorsModel.organization_employee_id,
                CollaboratorsModel.employee_last_name,
                CollaboratorsModel.employee_first_name,
                BusinessUnitsModel.entity_1,
                BusinessUnitsModel.entity_2,
                BusinessUnitsModel.entity_3,
                BusinessUnitsModel.cost_center,
                VehicleMaintenanceModel.maintenance_type,
                VehicleMaintenanceModel.intervention_number,
                VehicleMaintenanceModel.target_date,
                VehicleMaintenanceModel.target_mileage,
                VehicleMaintenanceModel.maintenance_date,
                VehicleMaintenanceModel.maintenance_mileage,
                VehicleMaintenanceModel.periodicity,
                VehicleMaintenanceModel.maintenance_status,
                VehicleMaintenanceModel.maintenance_supplier,
                VehicleMaintenanceModel.operation_description,
                VehiclesModel.make,
                VehiclesModel.model,
                VehiclesModel.registration_type,
                VehiclesModel.maximum_load_weight,
                VehiclesModel.entry_into_service_date.return_variant(
                    raw_name='Date de 1ère MEC',
                ),
                VehiclesModel.vehicle_site,
                VehiclesModel.energy,
                ExpensesModel.amount_tax_inc,
                ExpensesModel.amount_tax_exc,
                ExpensesModel.amount_tax_inc_loc,
                ExpensesModel.amount_tax_exc_loc,
                ExpensesModel.billing_ref.return_variant(
                    raw_name='N° de référence'
                ),
            ],
            skip_cols=['Montant du devis'],
            record_dates=[
                VehicleMaintenanceModel.maintenance_date.name,
            ],
            source_table=GacRiskTables.maintenance.value,
        )
        self.load_table(
            file_path=os.path.join(folder, 'procès_verbaux_détaillés.csv'),
            col_lst=[
                VehiclesModel.plate_number,
                CollaboratorsModel.driving_licence_number,
                FinesModel.offense_date.return_variant(
                    raw_name="Date de l'évènement",
                ),
                FinesModel.fine_ref,
                CollaboratorsModel.organization_employee_id,
                CollaboratorsModel.employee_first_name,
                CollaboratorsModel.employee_last_name,
                BusinessUnitsModel.entity_1,
                BusinessUnitsModel.entity_2,
                BusinessUnitsModel.entity_3,
                BusinessUnitsModel.cost_center,
                FinesModel.fine_type,
                FinesModel.road_type,
                FinesModel.ticket_base_value,
                FinesModel.surcharge_value,
                FinesModel.surcharge_date,
                FinesModel.total_cost,
                FinesModel.fine_payer,
                FinesModel.fine_status,
                FinesModel.notice_date,
                FinesModel.remote_payment_ref,
                FinesModel.licence_points_lost,
                FinesModel.payment_date,
                FinesModel.offense_comment,
                FinesModel.creation_date.return_variant(
                    raw_name='Date de création'
                ),
                FinesModel.fine_overdue,
            ],
            record_dates=[
                FinesModel.offense_date.name,
                FinesModel.surcharge_date.name,
                FinesModel.payment_date.name,
                FinesModel.creation_date.name,
            ],
            source_table=GacRiskTables.detailed_fines.value,
        )
        self.load_table(
            file_path=os.path.join(folder, 'sinistres_détaillés.csv'),
            col_lst=[
                ExpensesModel.expense_reference,
                AccidentsModel.accident_date,
                AccidentsModel.accident_ref,
                VehiclesModel.plate_number,
                AccidentsModel.accident_type,
                AccidentsModel.accident_context,
                AccidentsModel.third_party.return_variant(
                    post_processing=lambda x: convert_boolean(
                        x.mask(
                            x == 'Non identifié',
                            'non',
                        )
                    )
                ),
                AccidentsModel.responsibility,
                CollaboratorsModel.employee_last_name,
                CollaboratorsModel.employee_first_name,
                AccidentsModel.insurer,
                BusinessUnitsModel.entity_1,
                BusinessUnitsModel.entity_2,
                BusinessUnitsModel.entity_3,
                BusinessUnitsModel.cost_center,
                AccidentsModel.insurer_cost,
                AccidentsModel.self_insurance_cost,
                AccidentsModel.organization_cost,
                AccidentsModel.total_accident_cost,
                AccidentsModel.repair_provider.return_variant(
                    raw_name='Fournisseur',
                ),
                AccidentsModel.accident_status,
                AccidentsModel.accident_description.return_variant(
                    raw_name='Description',
                ),
                AccidentsModel.creation_date,
                VehiclesModel.fiscal_type,
                AccidentsModel.expert_first_name,
                AccidentsModel.expert_last_name,
                AccidentsModel.expert_phone_number,
                AccidentsModel.expert_email,
                AccidentsModel.expert_days,
                AccidentsModel.expert_date,
                AccidentsModel.was_reimbursed,
                AccidentsModel.complaint_filed,
                AccidentsModel.claim_reception_date,
                AccidentsModel.claim_sent_insurer,
                AccidentsModel.claim_sent_insurer_date,
                AccidentsModel.deductible_higher_than_damage,
                AccidentsModel.commute_accident,
                AccidentsModel.weekend_accident,
                AccidentsModel.expert_rapport_date,
                AccidentsModel.accident_repair_start_date,
                AccidentsModel.accident_repair_end_date,
                AccidentsModel.vehicle_return_date,
                AccidentsModel.accident_location,
            ],
            skip_cols=['Expert - Établissements', 'Resp..1'],
            decimal='.',
            record_dates=[
                AccidentsModel.accident_date.name,
                AccidentsModel.creation_date.name,
                AccidentsModel.claim_reception_date.name,
                AccidentsModel.claim_sent_insurer_date.name,
                AccidentsModel.expert_rapport_date.name,
                AccidentsModel.accident_repair_start_date.name,
                AccidentsModel.accident_repair_end_date.name,
                AccidentsModel.vehicle_return_date.name,
            ],
            source_table=GacRiskTables.accidents.value,
        )


if __name__ == "__main__":
    logger = gen_logger("GacRisk")
    organization_name = 'Quartus'
    gac_export_data = GacRiskData(
        folder=os.path.join(
            f'/home/matthieuglotz/Documents/Data/{organization_name}/GAC',
            GacRiskData.NAME,
        ),
        logger=logger,
        source_connector="GAC",
        organization_name=organization_name,
    )
    for dataframe in gac_export_data:
        print(dataframe)
