""" Gac Data

Class loading, normalizing and organizing all GAC Datasets for a given
organization
"""
import os
import typing
from functools import cached_property
from enum import Enum, unique

from connectors.gac.budget import GacBudgetData
from connectors.gac.fleet import GacFleetData
from connectors.gac.inventory import GacInventoryData
from connectors.gac.risk import GacRiskData
from connectors.gac.steering import GacSteeringData
from connectors.gac.taxes import GacTaxData
from connectors.gac.exports import GacExportData
from utils.logging import gen_logger
from utils.dataset import Dataset, add_connector


@unique
class GacDatasets(Enum):
    budget = GacBudgetData.NAME
    inventory = GacInventoryData.NAME
    steering = GacSteeringData.NAME
    risk = GacRiskData.NAME
    fleet = GacFleetData.NAME
    taxes = GacTaxData.NAME
    exports = GacExportData.NAME


@add_connector
class GacData:

    SOURCE_CONNECTOR = 'GAC'

    def __init__(
        self,
        folder: str,
        organization_name: str,
        log_file: typing.Optional[str] = None,
    ) -> None:
        """ Instantiates GacData object containing all the GAC Data

        :param root_folder: str path to the root folder where all the data is
            stored. Must have expected subfolders
        :param log_file: optional str path to write logs to.

        :raises ValueError: if root_folder is not a valid path or does not
        contain all required subfolders
        """
        self.root_folder = os.path.expanduser(folder)
        self.logger = gen_logger(
            name=self.__class__.__name__,
            file_path=log_file,
        )
        self.organization_name = organization_name
        if not os.path.isdir(self.root_folder):
            self.logger.error(
                'Provided root folder %s is not a valid directory',
                self.root_folder,
            )

        for subfolder in GacDatasets:
            subfolder_path = os.path.join(
                self.root_folder,
                subfolder.value,
            )
            if not os.path.isdir(subfolder_path):
                self.logger.error(
                    'The provided root folder %s does not have '
                    'the required subfolder %s',
                    folder,
                    subfolder.value,
                )

    @cached_property
    def BUDGET(self) -> Dataset:
        budget_subfolder = os.path.join(
            self.root_folder,
            GacDatasets.budget.value,
        )
        if not os.path.isdir(budget_subfolder):
            return Dataset(
                folder=budget_subfolder,
                logger=self.logger,
                source_connector=self.SOURCE_CONNECTOR,
                organization_name=self.organization_name,
                name='EMPTY'
            )
        return GacBudgetData(
            folder=budget_subfolder,
            logger=self.logger,
            source_connector=self.SOURCE_CONNECTOR,
            organization_name=self.organization_name,
        )

    @cached_property
    def INVENTORY(self) -> Dataset:
        inventory_subfolder = os.path.join(
            self.root_folder,
            GacDatasets.inventory.value,
        )
        if not os.path.isdir(inventory_subfolder):
            return Dataset(
                folder=inventory_subfolder,
                logger=self.logger,
                source_connector=self.SOURCE_CONNECTOR,
                organization_name=self.organization_name,
                name='EMPTY'
            )
        return GacInventoryData(
            folder=inventory_subfolder,
            logger=self.logger,
            source_connector=self.SOURCE_CONNECTOR,
            organization_name=self.organization_name,
        )

    @cached_property
    def STEERING(self) -> Dataset:
        steering_subfolder = os.path.join(
            self.root_folder,
            GacDatasets.steering.value,
        )
        if not os.path.isdir(steering_subfolder):
            return Dataset(
                folder=steering_subfolder,
                logger=self.logger,
                source_connector=self.SOURCE_CONNECTOR,
                organization_name=self.organization_name,
                name='EMPTY'
            )
        return GacSteeringData(
            folder=steering_subfolder,
            logger=self.logger,
            source_connector=self.SOURCE_CONNECTOR,
            organization_name=self.organization_name,
        )

    @cached_property
    def FLEET(self) -> Dataset:
        fleet_subfolder = os.path.join(
            self.root_folder,
            GacDatasets.fleet.value,
        )
        if not os.path.isdir(fleet_subfolder):
            return Dataset(
                folder=fleet_subfolder,
                logger=self.logger,
                source_connector=self.SOURCE_CONNECTOR,
                organization_name=self.organization_name,
                name='EMPTY',
            )
        return GacFleetData(
            folder=fleet_subfolder,
            logger=self.logger,
            source_connector=self.SOURCE_CONNECTOR,
            organization_name=self.organization_name,
        )

    @cached_property
    def RISK(self) -> Dataset:
        risk_subfolder = os.path.join(
            self.root_folder,
            GacDatasets.risk.value,
        )
        if not os.path.isdir(risk_subfolder):
            return Dataset(
                folder=risk_subfolder,
                logger=self.logger,
                source_connector=self.SOURCE_CONNECTOR,
                organization_name=self.organization_name,
                name='EMPTY',
            )
        return GacRiskData(
            folder=risk_subfolder,
            logger=self.logger,
            source_connector=self.SOURCE_CONNECTOR,
            organization_name=self.organization_name,
        )

    @cached_property
    def TAXES(self) -> Dataset:
        tax_subfolder = os.path.join(
            self.root_folder,
            GacDatasets.taxes.value,
        )
        if not os.path.isdir(tax_subfolder):
            return Dataset(
                folder=tax_subfolder,
                logger=self.logger,
                source_connector=self.SOURCE_CONNECTOR,
                organization_name=self.organization_name,
                name='EMPTY',
            )

        return GacTaxData(
            folder=tax_subfolder,
            logger=self.logger,
            source_connector=self.SOURCE_CONNECTOR,
            organization_name=self.organization_name,
        )

    @cached_property
    def EXPORTS(self) -> Dataset:
        exports_subfolder = os.path.join(
            self.root_folder,
            GacDatasets.exports.value,
        )
        if not os.path.isdir(exports_subfolder):
            return Dataset(
                folder=exports_subfolder,
                logger=self.logger,
                source_connector=self.SOURCE_CONNECTOR,
                organization_name=self.organization_name,
                name='EMPTY',
            )

        return GacExportData(
            folder=exports_subfolder,
            logger=self.logger,
            source_connector=self.SOURCE_CONNECTOR,
            organization_name=self.organization_name,
        )

    def __iter__(self) -> typing.Generator[Dataset, None, None]:
        """ Turn the class iterable. Only return groups of dataframes."""
        for attr in [
            self.BUDGET, self.FLEET, self.INVENTORY, self.RISK, self.STEERING,
            self.TAXES, self.EXPORTS,
        ]:
            yield attr


if __name__ == "__main__":
    data = GacData(
        folder='/home/matthieuglotz/Documents/Data/Quartus/GAC',
        organization_name='Quartus',
    )
    for dataset in data:
        for table in dataset:
            print(table)
