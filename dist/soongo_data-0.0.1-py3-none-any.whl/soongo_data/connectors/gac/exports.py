"""Module to import data from GAC exports section"""
import logging
import os
from enum import Enum, unique

import pandas as pd

from data_models import (
    VehiclesModel, VehicleReportsModel, VehicleAssociationsModel,
    VehicleContractsModel, VehicleOrdersModel, CollaboratorsModel,
    BusinessUnitsModel, MileageReportsModel, SoonGoRecordsModel,
    VehicleStatusModel
)
from utils.logging import gen_logger
from utils.type import convert_numeric, convert_date, convert_names
from utils.dataset import Dataset
from utils.enums import SynchronizationTypes


@unique
class GacExportsTables(Enum):
    fleet_status = 'FLEET_STATUS'
    associations = 'ASSOCIATIONS'


class GacExportData(Dataset):

    NAME: str = 'EXPORTS'
    TYPE: SynchronizationTypes = SynchronizationTypes.csv_upload.value

    def __init__(
        self,
        folder: str,
        logger: logging.Logger,
        organization_name: str,
        source_connector: str,
    ):
        super().__init__(
            folder=folder,
            logger=logger,
            source_connector=source_connector,
            name=self.NAME,
            type=self.TYPE,
            organization_name=organization_name,
        )
        self.load_table(
            file_path=os.path.join(
                folder,
                'Etat de Parc Contrat et Véhicule.csv',
            ),
            col_lst=[
                VehiclesModel.plate_number.return_variant(
                    raw_name='Contrat - Référence Immatriculation',
                ),
                VehicleContractsModel.contract_reference.return_variant(
                    raw_name='Contrat - Référence de commande',
                ),
                VehicleContractsModel.contract_status,
                VehiclesModel.manufacturer_price_tax_inc.return_variant(
                    raw_name='Contrat - Prix constructeur TTC',
                    post_processing=convert_numeric,
                ),
                VehiclesModel.manufacturer_price_tax_exc.return_variant(
                    raw_name='Contrat - Prix constructeur HT',
                    post_processing=convert_numeric,
                ),
                VehiclesModel.rebate_rate.return_variant(
                    raw_name='Contrat - Pourcentage de remise %',
                ),
                VehiclesModel.manufacturer_rebate_value_tax_inc,
                VehiclesModel.manufacturer_rebate_value_tax_exc,
                VehiclesModel.rebate_price_ttc.return_variant(
                    raw_name="Contrat - Prix d'achat remisé TTC"
                ),
                VehiclesModel.rebate_price_ht,
                VehiclesModel.entry_into_service_date.return_variant(
                    raw_name='Contrat - Première mise en circulation'
                ),
                VehiclesModel.order_date,
                VehiclesModel.participation_at_purchase,
                VehiclesModel.accessory_price_tax_inc,
                VehiclesModel.accessory_price_tax_exc,
                VehiclesModel.option_price_tax_inc,
                VehiclesModel.option_price_tax_exc,
                VehiclesModel.residual_value,
                VehicleOrdersModel.expected_delivery_date.return_variant(
                    raw_name='Contrat - Date de livraison attendue',
                ),
                VehicleContractsModel.contract_record_date,
                VehicleContractsModel.interest_rate.return_variant(
                    raw_name="Contrat - Taux d'intérêt",
                ),
                VehiclesModel.battery_price_tax_inc,
                VehiclesModel.battery_price_tax_exc,
                VehicleContractsModel.close_date.return_variant(
                    raw_name="Contrat - Date de clôture",
                ),
                VehicleContractsModel.lease_closure_ground.return_variant(
                    raw_name='Contrat - Motif de clôture',
                ),
                VehicleContractsModel.resale_price,
                VehicleOrdersModel.buyer_name.return_variant(
                    raw_name="Contrat - Nom de l'acheteur",
                ),
                VehiclesModel.vehicle_internal_category.return_variant(
                    raw_name="Véhicule - Catégorie interne",
                ),
                VehicleReportsModel.refurbishment_charges,
                VehicleContractsModel.contract_comment,
                VehicleReportsModel.restitution_charges,
                VehicleContractsModel.contract_final_mileage,
                VehiclesModel.full_model.return_variant(
                    raw_name='Véhicule - Description du véhicule',
                ),
                VehiclesModel.fiscal_type.return_variant(
                    raw_name='Véhicule - Genre fiscal',
                ),
                VehiclesModel.fiscal_power.return_variant(
                    raw_name='Véhicule - Puissance fiscale',
                ),
                VehiclesModel.theoretical_CO2_per_km.return_variant(
                    raw_name='Véhicule - Émissions de CO2',
                ),
                VehiclesModel.CO2_emissions_norm,
                VehiclesModel.energy.return_variant(
                    raw_name='Véhicule - Énergie'
                ),
                VehiclesModel.vehicle_type_identification_code,
                VehiclesModel.model.return_variant(
                    raw_name='Véhicule - Modèle',
                ),
                VehiclesModel.vehicle_finishing,
                VehiclesModel.vehicle_serial_number,
                VehiclesModel.vehicle_external_colour,
                VehiclesModel.theoretical_fuel_consumption.return_variant(
                    raw_name='Véhicule - Conso. moy. constructeur'
                ),
                VehiclesModel.hybrid_theoretical_consumption,
                VehiclesModel.fuel_tank_capacity,
                VehiclesModel.door_count.return_variant(
                    raw_name="Véhicule - Nombre de portes",
                ),
                VehiclesModel.transmission_type,
                VehiclesModel.transmission_details,
                VehiclesModel.transmission_description,
                VehiclesModel.gear_count,
                VehiclesModel.vehicle_variant,
                VehiclesModel.vehicle_max_technical_weight,
                VehiclesModel.maximum_load_weight.return_variant(
                    raw_name='Véhicule - PTAC',
                ),
                VehiclesModel.vehicle_max_rolling_weight,
                VehiclesModel.vehicle_empty_weight,
                VehiclesModel.vehicle_official_category,
                VehiclesModel.official_body_category,
                VehiclesModel.gac_body_category,
                VehiclesModel.motor_volume,
                VehiclesModel.motor_power,
                VehiclesModel.motor_speed,
                VehiclesModel.order_dealership,
                VehiclesModel.order_delivery_place,
                VehiclesModel.restitution_address,
                VehiclesModel.front_tire_size,
                VehiclesModel.back_tire_size,
                VehiclesModel.has_speed_limiter,
                VehiclesModel.has_speed_regulator,
                VehiclesModel.has_particle_filter,
                VehiclesModel.vehicle_length,
                VehiclesModel.vehicle_width,
                VehiclesModel.has_double_cabin,
                VehiclesModel.is_air_quality_certified.return_variant(
                    raw_name="Véhicule - Vignette Crit'Air reçue"
                ),
                VehiclesModel.battery_capacity,
                VehiclesModel.machinery_insurance,
                VehiclesModel.vehicle_record_date,
                VehiclesModel.vehicle_last_update,
                VehiclesModel.make.return_variant(
                    raw_name='Véhicule - Marque du véhicule'
                ),
                VehiclesModel.montain_law_applicable.return_variant(
                    raw_name='Contrat - Concerné par la loi montagne'
                ),
                VehiclesModel.winter_gear.return_variant(
                    raw_name="Contrat - Dispose d'un équipement hivernal"
                ),
                CollaboratorsModel.employee_full_name.return_variant(
                    raw_name='Collaborateur : Collaborateur',
                    post_processing=convert_names(self.organization_name),
                ),
                CollaboratorsModel.employee_last_name.return_variant(
                    raw_name='Collaborateur : Nom'
                ),
                CollaboratorsModel.employee_first_name.return_variant(
                    raw_name='Collaborateur : Prénom',
                ),
                CollaboratorsModel.employee_email,
                CollaboratorsModel.organization_employee_id.return_variant(
                    raw_name="Collaborateur : Matricule"
                ),
                CollaboratorsModel.is_validated_driving_license,
                CollaboratorsModel.driving_licence_validation_date,
                CollaboratorsModel.employee_role.return_variant(
                    raw_name='Collaborateur : Fonction actuelle',
                ),
                VehicleAssociationsModel.previous_vehicle.return_variant(
                    raw_name=(
                        "Véhicule précédent - Référence Immatriculation"
                    ),
                ),
                VehicleAssociationsModel.next_vehicle_plate,
                VehicleContractsModel.financial_rent_ttc.return_variant(
                    raw_name='Loyer financier théorique (mensuel) TTC'
                ),
                VehicleContractsModel.financial_rent_ht,
                VehicleContractsModel.management_fee_rent_ttc.return_variant(
                    raw_name="Loyer gestion théorique (mensuel) TTC"
                ),
                VehicleContractsModel.management_fee_rent_ht,
                VehicleContractsModel.accident_management_fee_rent_ht,
                VehicleContractsModel.accident_management_fee_rent_ttc.return_variant(
                    raw_name="Loyer gest. sinistre théorique (mensuel) TTC",
                ),
                VehicleContractsModel.tires_rent_ht,
                VehicleContractsModel.tires_rent_ttc.return_variant(
                    raw_name="Loyer pneumatiques théorique (mensuel) TTC",
                ),
                VehicleContractsModel.maintenance_rent_ht,
                VehicleContractsModel.maintenance_rent_ttc.return_variant(
                    raw_name=(
                        "Loyer maint. / entretien théorique (mensuel) TTC"
                    ),
                ),
                VehicleContractsModel.fuel_card_management_fee_rent_ht,
                VehicleContractsModel.fuel_card_management_fee_rent_ttc.return_variant(
                    raw_name=(
                        "Loyer gestion carte carbu. théorique (mensuel) TTC"
                    ),
                ),
                VehicleContractsModel.relay_car_rent_ht,
                VehicleContractsModel.relay_car_rent_ttc.return_variant(
                    raw_name=(
                        "Loyer vehicule relais théorique (mensuel) TTC"
                    ),
                ),
                VehicleContractsModel.insurance_rent_ht,
                VehicleContractsModel.insurance_rent_ttc.return_variant(
                    raw_name="Loyer assurance théorique (mensuel) TTC",
                ),
                VehicleContractsModel.financial_loss_rent_ht,
                VehicleContractsModel.financial_loss_rent_ttc.return_variant(
                    raw_name="Loyer perte financière théorique (mensuel) TTC",
                ),
                VehicleContractsModel.other_rent_ht,
                VehicleContractsModel.other_rent_ttc.return_variant(
                    raw_name="Autres loyers théoriques (mensuel) TTC",
                ),
                VehicleContractsModel.electricity_rent_ht,
                VehicleContractsModel.electricity_rent_ttc.return_variant(
                    raw_name="Loyer électrique théorique (mensuel) TTC"
                ),
                VehicleContractsModel.total_rent_ht,
                VehicleContractsModel.total_rent_ttc.return_variant(
                    raw_name="Total des loyers théoriques (mensuel) TTC"
                ),
                VehicleContractsModel.roadside_assistance_rent_ht,
                VehicleContractsModel.roadside_assistance_rent_ttc.return_variant(
                    raw_name="Loyer assistance (mensuel) TTC",
                ),
                VehicleContractsModel.telematics_rent_ht,
                VehicleContractsModel.telematics_rent_ttc.return_variant(
                    raw_name=(
                        "Loyer boitier Télématique théorique (mensuel) TTC"
                    ),
                ),
                VehicleReportsModel.entry_into_circulation_fees_tax_exc,
                VehicleReportsModel.entry_into_circulation_fees_tax_inc,
                VehicleContractsModel.contract_file_count,
                VehicleContractsModel.contract_start_date.return_variant(
                    raw_name="Date de début"
                ),
                VehiclesModel.car_supplier.return_variant(
                    raw_name="Fournisseur"
                ),
                VehicleAssociationsModel.employee_attribution_date,
                BusinessUnitsModel.business_unit_attribution_date,
                VehiclesModel.vehicule_sound_level,
                VehicleStatusModel.vehicle_availability.return_variant(
                    raw_name="Dernier évènement : Disponibilité du véhicule",
                ),
                VehicleAssociationsModel.association_start_date,
                VehicleAssociationsModel.association_end_date,
                VehicleContractsModel.lease_months.return_variant(
                    raw_name="Dernier évènement : Durée souscrite",
                ),
                VehicleContractsModel.lease_mileage.return_variant(
                    raw_name="Dernier évènement : Distance souscrite",
                ),
                VehicleContractsModel.contract_type.return_variant(
                    raw_name="Evènement en cours : Type de contrat",
                ),
                VehicleAssociationsModel.monthly_participation,
                VehiclesModel.vehicle_age.return_variant(
                    raw_name="Âge du véhicule"
                ),
                BusinessUnitsModel.business_unit.return_variant(
                    raw_name='Entité',
                    post_processing=lambda x: x.str.replace("/", ">"),
                ),
                VehiclesModel.estimated_fuel_consumption.return_variant(
                    raw_name="Conso. moy. véhicule",
                ),
                MileageReportsModel.mileage.return_variant(
                    raw_name="Dernier Km."
                ),
                MileageReportsModel.mileage_date.return_variant(
                    raw_name="Date du relevé",
                ),
                CollaboratorsModel.employee_avg_monthly_mileage,
                VehicleReportsModel.vehicle_avg_monthly_mileage,
                VehicleContractsModel.lease_month_at_constant_km,
                VehicleContractsModel.lease_mileage_at_constant_months,
                VehiclesModel.accessories_employee,
                VehiclesModel.accessories_organisation,
                VehiclesModel.options_employee,
                VehiclesModel.options_organisation,
                VehiclesModel.registration_date,
                VehiclesModel.registration_update_date,
                VehiclesModel.registration_record_date,
                CollaboratorsModel.employee_address,
                CollaboratorsModel.employee_postal_code,
                CollaboratorsModel.employee_city,
                CollaboratorsModel.employee_country,
                CollaboratorsModel.licence_issuance_date,
                CollaboratorsModel.employee_internal_category.return_variant(
                    raw_name="Catégorie interne (Collaborateur)",
                ),
                BusinessUnitsModel.entity_1,
                BusinessUnitsModel.entity_2,
                BusinessUnitsModel.entity_3,
            ],
            skip_cols=[
                "Pays",
                "Dernier évènement : Participation / Redevance (\x80 / mois)",
                "Collaborateur : Sigle d'entité 3",
                "Sigle d'entité 3",
                "Collaborateur : Sigle d'entité 2",
                "Sigle d'entité 2",
                "Collaborateur : Sigle d'entité 1",
                "Sigle d'entité 1",
                "Collaborateur : Entité 3",
                "Collaborateur : Entité 2",
                "Collaborateur : Entité 1",
                "Collaborateur : Délivré par",
                "Collaborateur : Numéro de permis",
                "Collaborateur : Information adresse",
                "Collaborateur : Adresse (ligne 2)",
                "Périodicité de paiement",
                "Prochain contrôle technique",
                "Équipement",
                "Equipement : Libellé de carte",
                "Equipement : N° de carte",
                "Participation / Redevance à M-1 ( / mois)",
                "Montant AN personnalisé à M-1 ( / mois)",
                "Montant AN personnalisé à M ( / mois)",
                "Valeur retenue M-1 (Actuel - Particip. Récur.)",
                "Montant AVN M-1",
                "Valeur retenue (Actuel - Particip. Récur.)",
                "Montant AN 30%",
                "Montant AVN",
                "LDR en conservant le km (Nouvelle date de fin)",
                (
                    "LDR en conservant la durée actuelle (affiché au compteur)"
                    " (Km)"
                ),
                "Moyenne kilométrique : depuis le début (Km (s) par mois)",
                "Km théorique",
                "Loyers HT/TTC",
                "Libellé Centre de Coût (Complet)",
                "Libellé Centre de Coût",
                "Centre de Coût",
                "Collaborateur : Sigle d'entité",
                "Collaborateur : Entité",
                "Sigle d'entité",
                "N° Siret",
                "Responsable hiérarchique",
                "Ancienneté dans le parc",
                "Nombre de jours avant échéance",
                "Evènement en cours : Méthode de calcul de l'AN",
                "Evènement en cours : Distance souscrite",
                "Evènement en cours : Durée souscrite",
                "Evènement en cours : Commentaires",
                "Evènement en cours : Date de fin",
                "Evènement en cours : Date d'effet",
                "Dernier évènement : Méthode de calcul de l'AN",
                'Sigle de la société',
                'Nom de la société',
                'Loyer Intérêts (mensuel)',
                'Loyer Intérêts (mensuel) HT',
                'Loyer Intérêts (mensuel) TTC',
                'Colonne Vide/Libre',
                'Contrat - Immat.',
                "Contrat - Immatriculation EDI Ref avec tiret",
                "Véhicule - Montant taxe dév. (Y.2)",
                ' Loi de roulage en conservant le kilométrage actuel',
                'Écart (%)',
                (
                    'LDR en conservant la durée actuelle (affiché au compteur)'
                    ' (Km)'
                ),
                'Véhicule - Code référentiel véhicules',
                'Véhicule - Ind. de la classe env. (V.9)',
                'Responsable RH',
                'Véhicule - Contrôle technique',
                'Véhicule - Hauteur',
                'Contrat - Référence GAC',
                'Dernier évènement : Commentaires',
                'Véhicule - Montant taxe rég. (Y.1)',
                'Moyenne kilométrique : depuis le début (Km (s) par mois)',
                'Evènement en cours : Disponibilité du véhicule',
                'Loyer gestion théorique (mensuel)',
                'Collaborateur : Description',
                'Véhicule - Étiquette',
                'Contrat - Immatriculation EDI',
                'Contrat - Immatriculation EDI avec tiret',
                'Contrat - Immatriculation EDI Ref',
                'Contrat - Immatriculation complète',
                'Contrat - Entité Facturée',
                'Contrat - Montant remise TTC',
                'Contrat - Montant remise HT',
                'Contrat - Montant remise additionnelle TTC',
                'Contrat - Montant remise additionnelle HT',
                'Contrat - Montant remise arrière pourcentage %',
                'Contrat - Remise arrière additionnelle TTC',
                'Contrat - Remise arrière additionnelle HT',
                "Contrat - Prix d'achat remisé (plafonné) TTC",
                "Contrat - Prix d'achat remisé (plafonné) HT",
                "Contrat - Prix accessoires (Client) TTC",
                'Contrat - Prix accessoires (Collaborateur) TTC',
                'Contrat - Prix des options (Client) TTC',
                'Contrat - Prix des options (Collaborateur) TTC',
                'Véhicule - Type de véhicule',
                'Véhicule - Id du véhicule',
                'Véhicule - Genre carte grise',
                'Véhicule - Émissions de CO2 (norme NEDC)',
                'Véhicule - Émissions de CO2 (norme WLTP)',
                'Véhicule - id technique',
                'Véhicule - Couleur intérieure',
                'Véhicule - Conso. hybride moteur électrique',
                'Véhicule - Catégorie interne - ID GAC',
                'Véhicule - Masse max. véh. (F.2)',
                "Véhicule - Numéro vignette Crit'Air",
                'Véhicule - Connecté au service MBF',
                'Véhicule - Code constructeur',
                'Véhicule - Montant BMVI',
                'Véhicule - Véhicule autoporté',
                'Véhicule - Caisse',
                'Véhicule - Suspension',
                "Contrat - Type d'équipement",
                'Collaborateur : Civilité',
                'Collaborateur : Numéro de Téléphone',
                'Contrat type : Dénomination',
                'Contrat type : Montant TTC',
                'Contrat type : Montant HT',
                'Contrat type : Type de dépenses',
                'Contrat type : Etat',
                "Contrat type : Date d'effet",
                'Contrat type : Date de fin',
                "Véhicule - Montant total taxes (Y.6)",
                'TVS : Période',
                'TVS : Montant total',
                'TVS année dernière : Période',
                'TVS année dernière : Montant total',
                'field_grcf_taxation_air_pollutant:période',
                'field_grcf_taxation_air_pollutant:Total (en )',
                'field_grcf_taxation_co2_emission:période',
                'field_grcf_taxation_co2_emission:Total (en )',
                "Taxe annuelle sur l'ancienneté des véhicules "
                "de tourisme année dernière:période",
                "Taxe annuelle sur l'ancienneté des "
                "véhicules de tourisme année dernière:Total (en )",
                "Taxe sur les émissions de co2 année dernière:période",
                "Taxe sur les émissions de co2 année dernière:Total (en )",
                "Véhicule précédent - Immat.",
                "Véhicule précédent - Immatriculation EDI",
                "Véhicule précédent - Référence GAC",
                "Véhicule précédent - Immatriculation EDI Ref",
                "Véhicule précédent - Immatriculation EDI Ref avec tiret",
                "Véhicule précédent - Immatriculation EDI avec tiret",
                "Véhicule suivant - Immat.",
                "Véhicule suivant - Immatriculation EDI",
                "Véhicule suivant - Référence GAC",
                "Véhicule suivant - Immatriculation EDI Ref",
                "Véhicule suivant - Immatriculation EDI Ref avec tiret",
                "Véhicule suivant - Immatriculation EDI avec tiret",
                "Site de rattachement - Entité",
                "TVA (%) associée au loyer",
                "Loyer financier théorique (mensuel)",
                "Loyer gest. sinistre théorique (mensuel)",
                "Loyer pneumatiques théorique (mensuel)",
                "Loyer maint. / entretien théorique (mensuel)",
                "Loyer gestion carte carbu. théorique (mensuel)",
                "Loyer vehicule relais théorique (mensuel)",
                "Loyer assurance théorique (mensuel)",
                "Loyer perte financière théorique (mensuel)",
                "Autres loyers théoriques (mensuel)",
                "Loyer électrique théorique (mensuel)",
                "Total des loyers théoriques (mensuel)",
                "Total des loyers",
                "Total des loyers en HT",
                "Total des loyers en TTC",
                "Catalogue - Libellé",
                "Catalogue - Date de début",
                "Catalogue - Date de fin",
                "Catalogue - Statut",
                "Référence",
                "Commande",
                "Contrat - Taux de TVA",
            ],
            record_dates=[
                VehiclesModel.vehicle_record_date.name,
                VehiclesModel.registration_record_date.name,
                VehiclesModel.contract_record_date.name,
            ],
            source_table=GacExportsTables.fleet_status.value,
        )
        self.import_vehicle_associations()

    def import_vehicle_associations(self) -> pd.DataFrame:
        """ Import vehicle associations from exports and set it as attribute"""
        association_df = self.load_table(
            file_path=os.path.join(
                self.folder,
                'Historique affectation.csv',
            ),
            col_lst=[
                CollaboratorsModel.employee_full_name.return_variant(
                    raw_name='Collaborateur',
                    post_processing=convert_names(self.organization_name),
                ),
                CollaboratorsModel.organization_employee_id.return_variant(
                    raw_name='Matricule',
                ),
                VehiclesModel.plate_number.return_variant(
                    raw_name='Contrat - Immatriculation EDI avec tiret',
                ),
                VehiclesModel.vehicle_empty_weight,
                VehicleAssociationsModel.association_start_date.return_variant(
                    raw_name='Date de début',
                    post_processing=(
                        lambda x: convert_date(x, date_format=r'%m/%d/%Y')
                    ),
                ),
                VehicleAssociationsModel.association_end_date.return_variant(
                    raw_name='Date de fin',
                    post_processing=(
                        lambda x: convert_date(x, date_format=r'%m/%d/%Y')
                    ),
                ),
            ],
            skip_cols=[
                'Entité 1',  # Inconsistent BUs, not of use here
                'Entité 2',
                'Entité 3',
            ],
            record_dates=[
                VehicleAssociationsModel.association_start_date.name,
                VehicleAssociationsModel.association_end_date.name,
            ],
            source_table=GacExportsTables.associations.value,
            encoding='utf-8',
        )
        assert (
            pd.notna(association_df.loc[
                pd.notna(
                    association_df[
                        CollaboratorsModel.organization_employee_id.name
                    ]
                ),
                CollaboratorsModel.employee_full_name.name,
            ]).all()
        )
        # We can therefore rely on full name to assert a vehicle is attributed
        association_df[VehicleAssociationsModel.association_end_date.name] = (
            association_df[
                VehicleAssociationsModel.association_end_date.name
            ].where(
                pd.notna(
                    association_df[CollaboratorsModel.employee_full_name.name]
                ),
                association_df.groupby(
                    [
                        VehiclesModel.plate_number.name,
                        CollaboratorsModel.employee_full_name.name,
                        VehicleAssociationsModel.association_start_date.name,
                    ]
                )[
                    VehicleAssociationsModel.association_end_date.name
                ].transform('max'),
            )
        )
        association_df = association_df[
            [
                VehiclesModel.plate_number.name,
                CollaboratorsModel.employee_full_name.name,
                CollaboratorsModel.organization_employee_id.name,
                VehicleAssociationsModel.association_start_date.name,
                VehicleAssociationsModel.association_end_date.name,
                SoonGoRecordsModel.source_connector.name,
                SoonGoRecordsModel.source_dataset.name,
                SoonGoRecordsModel.source_table.name,
                SoonGoRecordsModel.synchronisation_type.name,
            ]
        ].drop_duplicates()
        association_df = association_df.sort_values(
            [
                VehiclesModel.plate_number.name,
                VehicleAssociationsModel.association_start_date.name,
                VehicleAssociationsModel.association_end_date.name,
            ]
        )
        association_df['previous_end_date'] = association_df.groupby(
            [
                VehiclesModel.plate_number.name,
                VehicleAssociationsModel.association_start_date.name,
            ]
        )[VehicleAssociationsModel.association_end_date.name].shift()
        association_df[VehicleAssociationsModel.association_start_date.name] = (
            association_df[
                VehicleAssociationsModel.association_start_date.name
            ].where(
                (
                    association_df[
                        VehicleAssociationsModel.association_start_date.name
                    ] >=
                    association_df['previous_end_date']
                ) | pd.isna(association_df['previous_end_date']),
                association_df['previous_end_date'],
                # Start date is not always updated when new owner.
                # Validated with Holson.
            )
        )
        setattr(
            self,
            GacExportsTables.associations.value,
            association_df,
        )
        return association_df


if __name__ == "__main__":
    logger = gen_logger("GacExports")
    gac_export_data = GacExportData(
        folder=os.path.join(
            '/home/matthieuglotz/Documents/Data/Quartus/GAC',
            GacExportData.NAME,
        ),
        logger=logger,
        source_connector="GAC",
        organization_name="Quartus",
    )
    for dataframe in gac_export_data:
        print(dataframe)
