"""Module to import data from GAC steering section"""
import logging
import os
from enum import Enum, unique

from data_models import (
    CollaboratorsModel, VehiclesModel, BusinessUnitsModel, MileageReportsModel
)
from utils.logging import gen_logger
from utils.dataset import Dataset
from utils.enums import SynchronizationTypes


@unique
class GacSteeringTables(Enum):
    employee_monthly_mileage = 'EMPLOYEE_MONTHLY_MILEAGE'


class GacSteeringData(Dataset):

    NAME = 'STEERING'
    TYPE = SynchronizationTypes.csv_upload.value

    def __init__(
        self,
        folder: str,
        logger: logging.Logger,
        source_connector: str,
        organization_name: str,
    ):
        super().__init__(
            folder=folder,
            logger=logger,
            source_connector=source_connector,
            name=self.NAME,
            type=self.TYPE,
            organization_name=organization_name,
        )
        self.employee_monthly_mileage = self.load_table(
            file_path=os.path.join(self.folder, 'kilometrage_conducteur.csv'),
            col_lst=[
                CollaboratorsModel.employee_first_name,
                CollaboratorsModel.employee_last_name,
                VehiclesModel.plate_number,
                BusinessUnitsModel.entity_1,
                BusinessUnitsModel.entity_2,
                BusinessUnitsModel.entity_3,
                MileageReportsModel.mileage.return_variant(
                    raw_name='Total',
                ),
            ],
            record_dates=[],
            source_table=GacSteeringTables.employee_monthly_mileage.value,
        )


if __name__ == "__main__":
    logger = gen_logger("GacRisk")
    gac_export_data = GacSteeringData(
        folder=os.path.join(
            '/home/matthieuglotz/Documents/Data/Quartus/GAC',
            GacSteeringData.NAME,
        ),
        logger=logger,
        source_connector="GAC",
        organization_name='Quartus',
    )
    for dataframe in gac_export_data:
        print(dataframe)
