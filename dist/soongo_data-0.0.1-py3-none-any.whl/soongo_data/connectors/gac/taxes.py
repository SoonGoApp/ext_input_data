"""Module to import data from GAC tax section"""
import datetime
import logging
import os
import re
from enum import Enum, unique

import numpy as np
import pandas as pd

from data_models import (
    CollaboratorsModel, VehiclesModel, TaxesModel, BusinessUnitsModel,
    VehicleContractsModel, VehicleReportsModel, VehicleAssociationsModel,
    VehicleStatusModel, MileageReportsModel, SoonGoRecordsModel
)
from utils.dataset import (
    Dataset
)
from utils.logging import gen_logger
from utils.type import convert_numeric
from utils.enums import SynchronizationTypes


@unique
class GacTaxesTables(Enum):
    in_kind_benefit = 'IN_KIND_BENEFIT'
    amortization = 'AMORTIZATION'
    seniority_tax = 'SENIORITY_TAX'
    CO2_tax = 'CO2_TAX'
    corporate_car_tax = 'CORPORATE_CAR_TAX'


class GacTaxData(Dataset):

    NAME = 'TAXES'
    TYPE = SynchronizationTypes.csv_upload.value

    def __init__(
        self,
        folder: str,
        logger: logging.Logger,
        source_connector: str,
        organization_name: str,
    ):
        super().__init__(
            folder=folder,
            logger=logger,
            source_connector=source_connector,
            name=self.NAME,
            type=self.TYPE,
            organization_name=organization_name,
        )
        self.load_in_kind_benefits()
        self.meld_df(
            file_path=os.path.join(
                folder,
                'amortissements_non_deductibles.csv',
            ),
            id_cols=[
                CollaboratorsModel.employee_last_name,
                CollaboratorsModel.employee_first_name,
                VehiclesModel.plate_number.return_variant(
                    raw_name='Immat.',
                ),
                BusinessUnitsModel.entity_1,
                BusinessUnitsModel.entity_2,
                BusinessUnitsModel.entity_3,
                TaxesModel.amortization_start_date,
                TaxesModel.amortization_end_date,
                TaxesModel.amortization_length,
                VehiclesModel.model,
                VehiclesModel.vehicle_internal_category,
                VehiclesModel.fiscal_type.return_variant(
                    raw_name='Genre',
                ),
                VehiclesModel.theoretical_CO2_per_km.return_variant(
                    raw_name='Émissions de CO2',
                ),
                VehiclesModel.vehicle_status.return_variant(
                    raw_name='Statut actuel',
                ),
                VehicleContractsModel.contract_type.return_variant(
                    raw_name='Type de contrat',
                ),
                VehicleReportsModel.tco_tax_inc.return_variant(
                    raw_name='Coût',  # Coût
                ),
                VehiclesModel.car_supplier,
            ],
            value_col=TaxesModel.declared_non_deductible_amortization,
            var_col=VehicleReportsModel.year,
            record_dates=[TaxesModel.amortization_start_date.name],
            source_table=GacTaxesTables.amortization.value,
        )
        self.agg_and_meld(
            eligible_files=[
                os.path.join(self.folder, file)
                for file in os.listdir(self.folder)
                if re.match(r'^taxe_ancienneté_\d{4}\.csv$', file)
            ],
            id_cols=[
                VehicleReportsModel.year.return_variant(
                    raw_name='période',
                ),
                BusinessUnitsModel.entity_1,
                BusinessUnitsModel.entity_2,
                BusinessUnitsModel.entity_3,
                BusinessUnitsModel.company_name,
                BusinessUnitsModel.company_number.return_variant(
                    raw_name='Siren',
                ),
                BusinessUnitsModel.company_number_detail,
                CollaboratorsModel.employee_first_name,
                CollaboratorsModel.employee_last_name,
                CollaboratorsModel.organization_employee_id,
                BusinessUnitsModel.cost_center.return_variant(
                    raw_name='Centre de Coût',
                ),
                VehiclesModel.car_supplier,
                VehiclesModel.plate_number.return_variant(
                    raw_name='Immat.'
                ),
                VehiclesModel.make,
                VehiclesModel.model,
                VehiclesModel.registration_date,
                VehiclesModel.entry_into_service_date.return_variant(
                    raw_name='Première mise en circulation'
                ),
                VehicleContractsModel.sales_date,
                TaxesModel.tax_status_start_date,
                TaxesModel.tax_status_end_date,
                VehicleContractsModel.contract_type,
                VehicleContractsModel.close_date,
                VehicleContractsModel.restitution_date,
                VehicleReportsModel.days_hired.return_variant(
                    raw_name="Nombre de jours d'utilisation",
                ),
                VehiclesModel.full_model,
                VehiclesModel.energy,
                VehiclesModel.fiscal_power.return_variant(
                    raw_name='Puissance Fiscale'
                ),
                VehiclesModel.theoretical_CO2_per_km.return_variant(
                    raw_name='Émissions de CO2 (g CO2/km)'
                ),
                TaxesModel.tax_category,
                TaxesModel.tax_vehicle_age,
                TaxesModel.tax_error,
                TaxesModel.tax_credit_description,
            ],
            skip_cols=['Libellé Centre de Coût'],  # Same as centre de coût
            record_dates=[
                TaxesModel.tax_status_start_date.name,
            ],
            source_table=GacTaxesTables.seniority_tax.value,
            meld=False,
            value_col=None,
            var_col=None,
        )
        self.agg_and_meld(
            eligible_files=[
                os.path.join(self.folder, file)
                for file in os.listdir(self.folder)
                if re.match(r'^taxe_CO2_\d{4}\.csv$', file)
            ],
            id_cols=[
                VehicleReportsModel.year.return_variant(
                    raw_name='période',
                ),
                BusinessUnitsModel.entity_1,
                BusinessUnitsModel.entity_2,
                BusinessUnitsModel.entity_3,
                BusinessUnitsModel.company_name,
                BusinessUnitsModel.company_number_detail,
                BusinessUnitsModel.company_number.return_variant(
                    raw_name='Siren',
                ),
                CollaboratorsModel.employee_last_name,
                CollaboratorsModel.employee_first_name,
                CollaboratorsModel.organization_employee_id,
                BusinessUnitsModel.cost_center.return_variant(
                    raw_name='Centre de Coût',
                ),
                VehiclesModel.car_supplier,
                VehiclesModel.plate_number.return_variant(
                    raw_name='Immat.'
                ),
                VehicleContractsModel.contract_type,
                VehiclesModel.make,
                VehiclesModel.model,
                VehiclesModel.registration_date,
                VehiclesModel.entry_into_service_date.return_variant(
                    raw_name='Première mise en circulation'
                ),
                VehicleContractsModel.sales_date,
                TaxesModel.tax_status_start_date,
                TaxesModel.tax_status_end_date,
                VehicleContractsModel.close_date,
                VehicleContractsModel.restitution_date,
                VehicleReportsModel.days_hired.return_variant(
                    raw_name="Nombre de jours d'utilisation",
                ),
                VehiclesModel.full_model,
                VehiclesModel.energy,
                VehiclesModel.theoretical_CO2_per_km.return_variant(
                    raw_name='Émissions de CO2 (g CO2/km)',
                ),
                VehiclesModel.fiscal_power.return_variant(
                    raw_name='Puissance Fiscale',
                ),
                TaxesModel.tax_category,
                TaxesModel.tax_CO2_emission.return_variant(
                    post_processing=convert_numeric,
                ),
                TaxesModel.tax_error,
                TaxesModel.tax_credit_description,
            ],
            skip_cols=['Libellé Centre de Coût'],  # Same as cost center
            record_dates=[
                TaxesModel.tax_status_start_date.name,
            ],
            source_table=GacTaxesTables.CO2_tax.value,
            meld=False,
            value_col=None,
            var_col=None,
        )
        self.agg_and_meld(
            eligible_files=[
                os.path.join(self.folder, file)
                for file in os.listdir(self.folder)
                if re.match(r'^tvs_\d{4}\.csv$', file)
            ],
            id_cols=[
                VehicleReportsModel.year.return_variant(
                    raw_name='Période',
                ),
                BusinessUnitsModel.entity_1.return_variant(
                    post_processing=lambda x: x.where(
                        x != 'Non affectée',
                        '',
                    ),
                ),
                BusinessUnitsModel.entity_2,
                BusinessUnitsModel.entity_3,
                BusinessUnitsModel.company_number_detail,
                BusinessUnitsModel.company_number.return_variant(
                    raw_name='Siren'
                ),
                CollaboratorsModel.employee_last_name,
                CollaboratorsModel.employee_first_name,
                CollaboratorsModel.organization_employee_id,
                BusinessUnitsModel.cost_center.return_variant(
                    raw_name='Centre de Coût'
                ),
                VehiclesModel.car_supplier,
                VehiclesModel.plate_number.return_variant(
                    raw_name='Immat.'
                ),
                VehicleContractsModel.contract_type,
                VehiclesModel.make,
                VehiclesModel.model,
                VehiclesModel.registration_date,
                VehiclesModel.entry_into_service_date.return_variant(
                    raw_name='Première mise en circulation'
                ),
                VehicleContractsModel.resale_date,
                TaxesModel.tax_status_start_date,
                TaxesModel.tax_status_end_date.return_variant(
                    raw_name="Date de fin de l'événement",
                ),
                VehicleContractsModel.close_date,
                VehicleContractsModel.restitution_date,
                VehicleReportsModel.days_hired.return_variant(
                    raw_name="Nombre de jours effectifs",
                ),
                VehiclesModel.full_model,
                VehiclesModel.energy,
                VehiclesModel.theoretical_CO2_per_km.return_variant(
                    raw_name='Emission de CO2',
                ),
                VehiclesModel.fiscal_power,
                TaxesModel.company_car_tax_method,
                TaxesModel.tax_CO2_base,
                TaxesModel.tax_power_base,
                TaxesModel.tax_clean_air,
                TaxesModel.tax_credit_previous_plate,
                TaxesModel.tax_credit_next_plate,
                TaxesModel.nb_quarters,
                TaxesModel.yearly_corporate_car_tax,
            ],
            skip_cols=['Libellé Centre de Coût'],  # Same as cost center
            value_col=TaxesModel.tax_corporate_vehicles,
            var_col=TaxesModel.quarter,
            record_dates=[
                TaxesModel.tax_status_start_date.name,
            ],
            source_table=GacTaxesTables.corporate_car_tax.value,
        )

    def load_in_kind_benefits(self) -> pd.DataFrame:
        """ Load in kind benefits table. Derive period start and end and
        compute daily participation.

        :returns: DataFrame of daily participations
        """
        file_path = os.path.join(self.folder, 'aen.csv')
        df = self.load_table(
            file_path=file_path,
            col_lst=[
                CollaboratorsModel.employee_first_name,
                CollaboratorsModel.employee_last_name,
                CollaboratorsModel.organization_employee_id,
                CollaboratorsModel.employee_role,
                BusinessUnitsModel.entity_1,
                BusinessUnitsModel.entity_2,
                BusinessUnitsModel.entity_3,
                BusinessUnitsModel.cost_center,
                VehiclesModel.plate_number.return_variant(
                    raw_name='Immat.'
                ),
                VehicleContractsModel.contract_type,
                TaxesModel.ikb_period,
                VehicleReportsModel.total_days.return_variant(
                    raw_name='Nombre de jours couverts',
                ),
                VehicleContractsModel.contract_start_date,
                VehiclesModel.entry_into_service_date.return_variant(
                    raw_name='Date de première MEC',
                ),
                TaxesModel.tax_status_start_date,
                VehiclesModel.rebate_price_ttc.return_variant(
                    post_processing=lambda x: convert_numeric(
                        x.str.replace(' ', '')
                    )
                ),
                VehicleContractsModel.financial_rent_ttc.return_variant(
                    raw_name='Loyer Financier',
                    post_processing=lambda x: convert_numeric(
                        x.str.replace(' ', '')
                    )
                ),
                VehicleContractsModel.tires_rent_ttc.return_variant(
                    post_processing=lambda x: convert_numeric(
                        x.str.replace(' ', '')
                    )
                ),
                VehicleContractsModel.maintenance_rent_ttc.return_variant(
                    post_processing=lambda x: convert_numeric(
                        x.str.replace(' ', '')
                    )
                ),
                VehicleContractsModel.other_rent_ttc.return_variant(
                    raw_name='Autre',
                ),
                VehicleReportsModel.insurance_ttc.return_variant(
                    post_processing=lambda x: convert_numeric(
                        x.str.replace(' ', '')
                    )
                ),
                VehicleReportsModel.insurance_final.return_variant(
                    post_processing=lambda x: convert_numeric(
                        x.str.replace(' ', '')
                    )
                ),
                VehicleReportsModel.fuel_cost.return_variant(
                    post_processing=lambda x: convert_numeric(
                        x.str.replace(' ', '')
                    )
                ),
                VehicleReportsModel.other_cost,
                VehiclesModel.fiscal_type,
                TaxesModel.ikb_current.return_variant(
                    post_processing=lambda x: convert_numeric(
                        x.str.replace(' ', '')
                    )
                ),
                TaxesModel.ikb_prorata.return_variant(
                    post_processing=lambda x: convert_numeric(
                        x.str.replace(' ', '')
                    )
                ),
                TaxesModel.ikb_price_based_nofuel.return_variant(
                    post_processing=lambda x: convert_numeric(
                        x.str.replace(' ', '')
                    )
                ),
                TaxesModel.ikb_price_based_fuel.return_variant(
                    post_processing=lambda x: convert_numeric(
                        x.str.replace(' ', '')
                    )
                ),
                VehicleAssociationsModel.participation.return_variant(
                    raw_name=(
                        'Participation récurrente pour la période sélectionnée'
                    ),
                    post_processing=lambda x: -convert_numeric(
                        x.str.replace(' ', '')
                    )
                    # Participation is an expense reimbursement for the client
                    # reiumbursement should be recorded as negative values
                ),
                TaxesModel.ikb_net_participation.return_variant(
                    post_processing=lambda x: convert_numeric(
                        x.str.replace(' ', '')
                    )
                ),
                TaxesModel.adjusted_ikb_net_participation.return_variant(
                    post_processing=lambda x: convert_numeric(
                        x.str.replace(' ', '')
                    )
                ),
                VehicleStatusModel.vehicle_status.return_variant(
                    raw_name='Statut actuel'
                ),
                VehiclesModel.theoretical_CO2_per_km.return_variant(
                    raw_name='Émission de CO2',
                ),
                MileageReportsModel.mileage.return_variant(
                    raw_name='Dernier relevé Km',
                ),
                VehicleContractsModel.total_rent_ttc.return_variant(
                    raw_name='Total des loyers',
                    post_processing=lambda x: convert_numeric(
                        x.str.replace(' ', '')
                    ),
                ),
                TaxesModel.ikb_method,
                TaxesModel.ikb_personalized,
                TaxesModel.ikb_end_date,
            ],
            record_dates=[],
            source_table=GacTaxesTables.in_kind_benefit.value,
            skip_cols=['Valeur retenue (Actuel - Particip. Récur.).1'],
        )

        # Derive period_start and period_end from period string
        df[TaxesModel.ikb_period_start.name] = pd.to_datetime(
            df[TaxesModel.ikb_period.name].str[:10],
            format=r'%d/%m/%Y',
        )
        import_date = datetime.datetime.fromtimestamp(
            os.path.getmtime(file_path)
        )
        df[TaxesModel.ikb_period_end.name] = np.where(
            df[TaxesModel.ikb_period.name].str.endswith("aujourd'hui"),
            import_date.strftime(r'%d/%m/%Y'),
            df[TaxesModel.ikb_period.name].str[-10:],
        )
        df[TaxesModel.ikb_period_end.name] = pd.to_datetime(
            df[TaxesModel.ikb_period_end.name],
            format=r'%d/%m/%Y',
        )
        df[SoonGoRecordsModel.record_date.name] = (
            df[TaxesModel.ikb_period_start.name]
        )
        df = df.drop(columns=TaxesModel.ikb_period.name)

        # Convert participation to daily participation
        # any month started is due (participation is paid at month start)
        day_length = ((
            df[TaxesModel.ikb_period_end.name] -
            df[TaxesModel.ikb_period_start.name]
        ) // 30 + 1 * datetime.timedelta(days=1)) * 30
        assert (day_length >= pd.Timedelta(0)).all()
        df[VehicleAssociationsModel.daily_participation.name] = (
            df[VehicleAssociationsModel.participation.name] /
            day_length.dt.days
        )
        df = df.drop(
            columns=VehicleAssociationsModel.participation.name,
        )
        setattr(
            self,
            GacTaxesTables.in_kind_benefit.value,
            df,
        )

        return df


if __name__ == "__main__":
    organization_name = 'Quartus'
    tax_data = GacTaxData(
        folder=(
            f'/home/matthieuglotz/Documents/Data/{organization_name}/GAC/TAXES'
        ),
        logger=gen_logger('tax_data'),
        source_connector='GAC',
        organization_name=organization_name,
    )
    tax_data.CO2_TAX.to_csv('~/dev/temp/CO2_tax.csv', index=False)
    for df in tax_data:
        print(df)
