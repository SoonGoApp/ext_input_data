""" Module to import data from GAC budget section"""
import logging
import os
import re
from enum import Enum, unique

import pandas as pd

from data_models import (
    VehicleReportsModel, VehiclesModel, BusinessUnitsModel, CollaboratorsModel,
    ExpensesModel, VehicleOrdersModel, FuelCardsModel, MileageReportsModel,
    VehicleEquipmentsModel
)
from utils.logging import gen_logger
from utils.type import str_is_nan, convert_string, convert_names
from utils.dataset import Dataset
from utils.enums import (
    CostCategory, FuelTypes, mapper_factory, SynchronizationTypes
)


@unique
class GacBudgetTables(Enum):
    budget_forecast_ht = 'BUDGET_FORECAST_HT'
    budget_forecast_ttc = 'BUDGET_FORECAST_TTC'
    expenses = 'EXPENSES'
    monthly_expenses = 'MONTHLY_EXPENSES'
    tco_exc_tax = 'TCO_EXC_TAX'
    tco_inc_tax = 'TCO_INC_TAX'


class GacBudgetData(Dataset):

    NAME = 'BUDGET'
    TYPE = SynchronizationTypes.csv_upload.value

    def __init__(
        self,
        folder: str,
        logger: logging.Logger,
        organization_name: str,
        source_connector: str,
    ):
        super().__init__(
            folder=folder,
            logger=logger,
            source_connector=source_connector,
            name=self.NAME,
            type=self.TYPE,
            organization_name=organization_name,
        )
        self.load_table(
            file_path=os.path.join(
                folder,
                'budget_previsionel_ht.csv',
            ),
            col_lst=[
                VehiclesModel.plate_number,
                VehicleReportsModel.daily_budget,
                VehicleReportsModel.total_days,
                VehicleReportsModel.total_budget,
                VehicleReportsModel.days_hired,
                VehicleReportsModel.committed_budget,
                BusinessUnitsModel.entity_1,
                BusinessUnitsModel.entity_2,
                BusinessUnitsModel.entity_3,
                CollaboratorsModel.employee_last_name,
                CollaboratorsModel.employee_first_name,
                ExpensesModel.supplier,
                VehiclesModel.make,
                VehiclesModel.model,
                VehicleOrdersModel.order_reference,
                VehiclesModel.vehicle_internal_category,
                VehiclesModel.fiscal_type,
            ],
            record_dates=[],
            source_table=GacBudgetTables.budget_forecast_ht.value,
        )
        self.load_table(
            file_path=os.path.join(
                folder,
                'budget_previsionel_ttc.csv',
            ),
            col_lst=[
                VehiclesModel.plate_number,
                VehicleReportsModel.daily_budget,
                VehicleReportsModel.total_days,
                VehicleReportsModel.total_budget,
                VehicleReportsModel.days_hired,
                VehicleReportsModel.committed_budget,
                BusinessUnitsModel.entity_1,
                BusinessUnitsModel.entity_2,
                BusinessUnitsModel.entity_3,
                CollaboratorsModel.employee_last_name,
                CollaboratorsModel.employee_first_name,
                ExpensesModel.supplier,
                VehiclesModel.make,
                VehiclesModel.model,
                VehicleOrdersModel.order_reference,
                VehiclesModel.vehicle_internal_category,
                VehiclesModel.fiscal_type,
            ],
            record_dates=[],
            source_table=GacBudgetTables.budget_forecast_ttc.value,
        )
        self.get_expenses_table()
        self.agg_and_meld(
            eligible_files=[
                os.path.join(self.folder, file)
                for file in os.listdir(self.folder)
                if re.match(r'^dépenses_rapport_\d{4}\.csv$', file)
            ],
            id_cols=[
                ExpensesModel.category_1,
                ExpensesModel.category_2,
                ExpensesModel.category_3,
            ],
            value_col=VehicleReportsModel.monthly_spend,
            var_col=VehicleReportsModel.month,
            record_dates=[],
            source_table=GacBudgetTables.monthly_expenses.value,
        )
        self.load_table(
            file_path=os.path.join(folder, 'tco_ht.csv'),
            col_lst=[
                VehiclesModel.plate_number,
                VehicleReportsModel.expense_count.return_variant(
                    raw_name='*Dps'
                ),
                ExpensesModel.amount_tax_exc.return_variant(
                    raw_name='*Dps Constatées',
                ),
                VehicleReportsModel.avg_daily_expense_tax_exc,
                VehicleReportsModel.avg_monthly_expense_tax_exc,
                VehicleReportsModel.missing_expenses_tax_exc,
                VehicleReportsModel.future_expenses_tax_exc,
                VehicleReportsModel.tco_tax_exc,
                BusinessUnitsModel.entity_1,
                BusinessUnitsModel.entity_2,
                BusinessUnitsModel.entity_3,
                CollaboratorsModel.employee_first_name,
                CollaboratorsModel.employee_last_name,
                ExpensesModel.supplier,
                VehiclesModel.make,
                VehiclesModel.model,
                VehicleOrdersModel.order_reference,
            ],
            record_dates=[],
            source_table=GacBudgetTables.tco_exc_tax.value,
        )
        self.load_table(
            file_path=os.path.join(folder, 'tco_ttc.csv'),
            col_lst=[
                VehiclesModel.plate_number,
                VehicleReportsModel.expense_count.return_variant(
                    raw_name='*Dps',
                ),
                ExpensesModel.amount_tax_inc.return_variant(
                    raw_name='*Dps Constatées',
                ),
                VehicleReportsModel.avg_daily_expense_tax_inc,
                VehicleReportsModel.avg_monthly_expense_tax_inc,
                VehicleReportsModel.missing_expenses_tax_inc,
                VehicleReportsModel.future_expenses_tax_inc,
                VehicleReportsModel.tco_tax_inc,
                BusinessUnitsModel.entity_1,
                BusinessUnitsModel.entity_2,
                BusinessUnitsModel.entity_3,
                CollaboratorsModel.employee_first_name,
                CollaboratorsModel.employee_last_name,
                ExpensesModel.supplier,
                VehiclesModel.make,
                VehiclesModel.model,
                VehicleOrdersModel.order_reference,
            ],
            record_dates=[],
            source_table=GacBudgetTables.tco_inc_tax.value,
        )

    def get_expenses_table(self):
        """ Get expenses table

        :returns: categorized expense table as a pandas Dataframe
        """
        expense_table = self.load_table(
            file_path=os.path.join(self.folder, 'dépenses.csv'),
            skip_cols=[
                'Centre de Coût',
                'TTC - TVA déductible',
                'Collaborateur exporté',
                'Montant HT ',
                'Montant TTC ',
                "Contrat - Prix d'achat remisé (plafonné) HT",
                'Produit.1',
                'Montant TTC.1',
                'Montant HT.1',
                'Information',
            ],
            col_lst=[
                ExpensesModel.expense_reference,
                ExpensesModel.supplier,
                ExpensesModel.billing_date,
                ExpensesModel.purchase_date,
                ExpensesModel.amount_tax_exc,
                ExpensesModel.amount_tax_inc,
                ExpensesModel.amount_final,
                ExpensesModel.category_1,
                ExpensesModel.category_2.return_variant(
                    post_processing=lambda x: x.str.strip()
                ),
                ExpensesModel.category_3.return_variant(
                    post_processing=lambda x: x.str.strip()
                ),
                ExpensesModel.product.return_variant(
                    post_processing=lambda x: x.str.strip()
                ),
                ExpensesModel.spent_tag,
                VehiclesModel.plate_number,
                VehiclesModel.model.return_variant(raw_name='Véhicule'),
                BusinessUnitsModel.cost_center,
                BusinessUnitsModel.entity_1,
                BusinessUnitsModel.entity_2,
                BusinessUnitsModel.entity_3,
                CollaboratorsModel.work_location,
                CollaboratorsModel.employee_full_name.return_variant(
                    post_processing=convert_names(self.organization_name)
                ),
                ExpensesModel.source,
                CollaboratorsModel.organization_employee_id,
                FuelCardsModel.fuel_card_supplier,
                FuelCardsModel.fuel_card_ref,
                FuelCardsModel.ticket_number,
                FuelCardsModel.fuel_card_product,
                ExpensesModel.expense_location,
                ExpensesModel.quantity,
                ExpensesModel.unit_price,
                ExpensesModel.discount_rate,
                ExpensesModel.discount_value,
                MileageReportsModel.mileage,
                MileageReportsModel.mileage_date,
                ExpensesModel.billing_ref,
                ExpensesModel.billing_account,
                ExpensesModel.billing_start_date.return_variant(
                    raw_name='Début de période',
                ),
                ExpensesModel.billing_end_date.return_variant(
                    raw_name='Fin de période',
                ),
                ExpensesModel.currency.return_variant(
                    raw_name='Devise',
                ),
                ExpensesModel.vat_amount,
                ExpensesModel.vat_rate,
                ExpensesModel.deductible_vat_rate,
                ExpensesModel.deductible_vat.return_variant(
                    raw_name='TVA déductible',
                ),
                VehiclesModel.registration_type,
                VehiclesModel.fiscal_type.return_variant(
                    raw_name='Véhicule - Genre fiscal',
                ),
                VehiclesModel.recording_datetime,
                VehicleEquipmentsModel.equipment_ref,
                VehicleReportsModel.export_date,
                VehicleReportsModel.export_status,
                VehicleReportsModel.validation_date,
                VehicleReportsModel.export_cost_centers,
                BusinessUnitsModel.export_entity,
                ExpensesModel.amount_tax_exc_loc,
                ExpensesModel.amount_tax_inc_loc,
                ExpensesModel.expense_description,
            ],
            record_dates=[ExpensesModel.billing_date.name],
            source_table=GacBudgetTables.expenses.value,
        )
        original_expense_count = len(expense_table)
        categorized_df = self.get_expense_category(expense_table)
        assert original_expense_count == len(categorized_df)
        self.EXPENSES = categorized_df
        return categorized_df

    @classmethod
    def get_expense_category(cls, expenses_df: pd.DataFrame) -> pd.DataFrame:
        """ Get SoonGo category

        :param df: pd.DataFrame with expense data

        """
        expenses_df[ExpensesModel.expense_category.name] = ''
        categorized_df_lst = []
        category_mappings = CategoryProductMappings()

        for category in expenses_df[ExpensesModel.category_2.name].unique():

            if pd.notna(category):
                category_df = expenses_df[
                    expenses_df[ExpensesModel.category_2.name] == category
                ]
                category_df[ExpensesModel.expense_category.name] = getattr(
                    category_mappings,
                    category.lower().replace(' ', '_')
                )(sub_df=category_df)
            else:
                category_df = expenses_df[
                    str_is_nan(expenses_df[ExpensesModel.category_2.name])
                ]
                category_df[ExpensesModel.expense_category.name] = (
                    category_mappings.nan(sub_df=category_df)
                )
            categorized_df_lst.append(category_df)

        categorized_df = pd.concat(categorized_df_lst, axis=0)
        categorized_df = categorized_df.sort_index()
        categorized_df[ExpensesModel.expense_category.name] = convert_string(
            categorized_df[ExpensesModel.expense_category.name]
        )
        cls.check_expense_category(
            original_df=expenses_df,
            categorized_df=categorized_df,
        )
        return categorized_df

    @staticmethod
    def check_expense_category(
        original_df: pd.DataFrame,
        categorized_df: pd.DataFrame,
    ):
        """ Check categorized df matches original

        :raises AssertionError: if shape don't match
        :raises ValueError: if values don't match
        """
        if categorized_df.shape != original_df.shape:
            raise ValueError(
                f'There are {len(categorized_df)} rows and '
                f'{categorized_df.shape[1]} columns after categorization '
                f'vs {len(original_df)} rows and {original_df.shape[1]} '
                f'columns initially. {original_df.columns} vs '
                f'{categorized_df.columns}'
            )

        for col in original_df.columns:
            if col != ExpensesModel.expense_category.name:
                if pd.api.types.is_string_dtype(original_df[col].dtype):
                    if (
                        categorized_df[col].fillna('') !=
                        original_df[col].fillna('')
                    ).any():
                        raise ValueError(
                            f'Difference in categorized DataFrames on {col}'
                        )
                elif (
                    categorized_df[col].fillna(0) != original_df[col].fillna(0)
                ).any():
                    raise ValueError(
                        f'Difference in categorized DataFrames on {col}'
                    )


class CategoryProductMappings:
    REP_CAR_MAX_FEE = 10

    @classmethod
    def carburant(cls, sub_df: pd.DataFrame) -> pd.Series:
        ex_series = mapper_factory(FuelTypes)(
            sub_df[ExpensesModel.product.name]
        )
        cls.check_missed_cases(df=sub_df, series=ex_series)
        return ex_series

    @classmethod
    def carte_carburant(cls, sub_df: pd.DataFrame) -> pd.DataFrame:
        ex_series = sub_df[ExpensesModel.category_3.name].map(
            {
                'Péage': CostCategory.tolls_real.value,
                'Parking': CostCategory.parking_real.value,
                'Lubrifiant': CostCategory.real_maintenance.value,
                'Incidents': CostCategory.real_repairs.value,
            }
        )

        # Washing - distinguish card vs real costs
        wash_cond = sub_df[ExpensesModel.category_3.name] == 'Lavage'
        card_cond = sub_df[ExpensesModel.product.name].str.contains(
            'carte',
            case=False,
        )
        ex_series.loc[wash_cond & card_cond] = CostCategory.washing_card.value
        ex_series.loc[wash_cond & ~card_cond] = CostCategory.washing_real.value

        # Other fuel cards. Distinguish fuel, from card, Adblue and tolls
        other_cond = ~(
            sub_df[ExpensesModel.product.name].str.contains(
                r'(?:adblue)|(?:carte)|(?:liber t)',
                case=False,
            )
        ) | str_is_nan(sub_df[ExpensesModel.product.name])
        ex_series.loc[
            (
                (sub_df[ExpensesModel.category_3.name] == 'Autres carte carb.')
                &
                other_cond
            )
        ] = CostCategory.default_gaz.value
        ex_series.loc[
            (
                (sub_df[ExpensesModel.category_3.name] == 'Autres carte carb.')
                &
                (sub_df[ExpensesModel.product.name].str.contains(
                    'adblue', case=False,
                ))
            )
        ] = CostCategory.adblue.value
        ex_series.loc[
            (
                (sub_df[ExpensesModel.category_3.name] == 'Autres carte carb.')
                &
                (sub_df[ExpensesModel.product.name].str.contains(
                    'carte', case=False,
                ))
            )
        ] = CostCategory.real_fuel_card.value
        ex_series.loc[
            (
                (sub_df[ExpensesModel.category_3.name] == 'Autres carte carb.')
                &
                (sub_df[ExpensesModel.product.name].str.contains(
                    'liber t', case=False,
                ))
            )
        ] = CostCategory.tolls_card.value

        # Subscriptions - distinguish toll cards from parking and actys
        ex_series.loc[
            (
                (sub_df[ExpensesModel.category_3.name] == 'Abonnements') &
                (sub_df[ExpensesModel.product.name].str.contains(
                    'télébadge', case=False,
                ))
            )
        ] = CostCategory.tolls_card.value
        ex_series.loc[
            (
                (sub_df[ExpensesModel.category_3.name] == 'Abonnements') &
                (sub_df[ExpensesModel.product.name].str.contains(
                    'frais parking', case=False,
                ))
            )
            # Values are not recurring - real costs
        ] = CostCategory.parking_real.value
        ex_series.loc[
            (
                (sub_df[ExpensesModel.category_3.name] == 'Abonnements') &
                (sub_df[ExpensesModel.product.name].str.contains(
                    'ABONNEMENT ACTYS', case=False,
                ))
            ),
            # Additional subscription for Total
        ] = CostCategory.real_fuel_card.value
        ex_series.loc[
            (
                (sub_df[ExpensesModel.category_3.name] == 'Abonnements') &
                (sub_df[ExpensesModel.product.name].str.contains(
                    'Frais de service EV', case=False,
                ))
            ),
            # Additional subscription for Total
        ] = CostCategory.real_fuel_card.value  # EV fuel card costs
        ex_series.loc[
            (
                (sub_df[ExpensesModel.category_3.name] == 'Abonnements') &
                str_is_nan(sub_df[ExpensesModel.product.name])
            ),
        ] = CostCategory.real_fuel_card.value

        cls.check_missed_cases(df=sub_df, series=ex_series)
        return ex_series

    @classmethod
    def contrôle_réglementaire(cls, sub_df: pd.DataFrame) -> pd.DataFrame:
        # Maintenance normalement incluses dans le loyer - Optimisation!
        ex_series = sub_df[ExpensesModel.category_3.name].map(
            {
                'Contrôle technique': CostCategory.real_maintenance.value,
                'Contrôle de pollution': CostCategory.real_maintenance.value,
            }
        )
        cls.check_missed_cases(df=sub_df, series=ex_series)
        return ex_series

    @classmethod
    def frais_de_gestion(cls, sub_df: pd.DataFrame) -> pd.DataFrame:
        deductible = CostCategory.insurance_deductible_cost.value
        ex_series = sub_df[ExpensesModel.category_3.name].map(
            {
                'Hon. Gestion Loueur': CostCategory.rent_management_fees.value,
                'Hon. Gestion Sinistres': deductible,
            }
        )

        # Peages et parking
        ex_series.loc[
            (
                (
                    sub_df[ExpensesModel.category_3.name] ==
                    'Frais de gestion Péage et Parking'
                ) &
                sub_df[ExpensesModel.product.name].str.contains('Frais Péage')
            )
        ] = CostCategory.tolls_real.value  # Not recurring cost, hence real

        ex_series.loc[
            (
                (
                    sub_df[ExpensesModel.category_3.name] ==
                    'Frais de gestion Péage et Parking'
                ) &
                sub_df[ExpensesModel.product.name].str.contains(
                    'Réservation Parking'
                )
            )
        ] = CostCategory.parking_real.value

        ex_series.loc[
            (
                (
                    sub_df[ExpensesModel.category_3.name] ==
                    'Frais de gestion Péage et Parking'
                ) &
                str_is_nan(sub_df[ExpensesModel.product.name])
            )
        ] = CostCategory.tolls_card.value  # recurring costs. Toll by default.

        ex_series = ex_series.where(
            pd.notna(ex_series),
            sub_df[ExpensesModel.product.name].map(
                {
                    'Gestion carburant': CostCategory.real_fuel_card.value,
                    'Provision carburant': CostCategory.default_gaz.value,
                }
            )
        )

        cls.check_missed_cases(df=sub_df, series=ex_series)
        return ex_series

    @classmethod
    def frais_divers(cls, sub_df: pd.DataFrame) -> pd.DataFrame:
        # TODO: To confirm with Eric Bouis / Quartus
        ex_series = sub_df[ExpensesModel.product.name].map({
            'Taxe WLTP': CostCategory.company_car_tax.value,
        })

        # TODO: Real tires when there is a tire rent may be a mistake (rare)
        # although winter tires are often outside of contract
        # tires labour costs must be attributed based on whether winter or
        # summer - in the mean time go to other.
        ex_series.loc[
            sub_df[ExpensesModel.product.name].str.contains(
                r'(?=.*\W(?:neige|hiver)\W.*)(?:.*\Wpneus?\W.*)',
                flags=re.IGNORECASE,
            )
        ] = CostCategory.real_tires_winter.value

        ex_series.loc[
            sub_df[ExpensesModel.product.name].str.contains(
                r'(?=.*\W(?:forf.?a?i?t?|monta?g?e?.?)\W.*)(?:.*\Wpneus?\W.*)',
                flags=re.IGNORECASE,
            )
        ] = CostCategory.real_tires_other.value

        ex_series.loc[
            pd.isna(ex_series) &
            sub_df[ExpensesModel.product.name].str.contains(
                r'.*\Wpneus?\W.*',
                flags=re.IGNORECASE,
            )
        ] = CostCategory.real_tires_summer.value

        ex_series.loc[
            sub_df[ExpensesModel.product.name].str.lower().str.contains(
                'carburant'
            )
        ] = CostCategory.default_gaz.value

        # TODO: tout risque peut être hors bris de glace à vérifier
        ex_series = ex_series.where(
            ~sub_df[ExpensesModel.product.name].str.lower().str.contains(
                'pare-brise'
            ),
            CostCategory.real_glass.value,
        )
        ex_series = ex_series.where(
            ~sub_df[ExpensesModel.product.name].str.lower().str.contains(
                'bris de glace'
            ),
            CostCategory.real_glass.value,
        )
        ex_series = ex_series.where(
            ~sub_df[ExpensesModel.product.name].str.lower().str.contains(
                'assurance'
            ),
            CostCategory.insurance_vehicle.value,
        )
        # No solution cross clients - voire avec Quartus si utilisé comme
        # véhicule de remplacement ou non.
        # considérer mettre ça dans un KPI séparé.
        # Règle: si le fournisseurs est un loueur longue durée type ALD
        # Alors véhicule de remplacement, si c'est un Hertz/Avis alors
        # dans ce cas pas vraiment de solution à voir avec le client selon
        # ses usages. Si pas précisé pareil.
        # TODO: vehicule temporaire autres pour ces cas non distinguable
        # Rather distinguish length: > 1 months then relay.
        # If < 1 month, and a vehicle is already assigned to the user AND
        # TODO: Have a mother category short term rental and daughter
        # categories specifying replacement or travel where possible.
        # Add to car/employee TCO using (i) the car plate number if that car
        # plate number is associated with a LLD (hence is the replaced car) or
        # (ii) otherwise relate it through employee id (iii) if no employee id
        # or long term car id then pool and divide it across all employees/cars
        ex_series = ex_series.where(
            ~sub_df[ExpensesModel.product.name].str.lower().str.contains(
                'courte durée'
            ),
            CostCategory.real_short_term_rental.value,
        )
        ex_series = ex_series.where(  # TODO: categorize some of the others
            pd.notna(ex_series),
            CostCategory.real_others.value,
        )

        cls.check_missed_cases(df=sub_df, series=ex_series)
        return ex_series

    @classmethod
    def hors_contrat(cls, sub_df: pd.DataFrame) -> pd.DataFrame:
        ex_series = sub_df[ExpensesModel.category_3.name].map(
            {
                'Réparation': CostCategory.real_repairs.value,
                'Frais de restitution': CostCategory.real_restitution.value,
                'Révision': CostCategory.real_maintenance.value,
            },
            # Again optimization here, révision is not included in rent
        )

        cls.check_missed_cases(df=sub_df, series=ex_series)
        return ex_series

    @classmethod
    def loyers(cls, sub_df: pd.DataFrame) -> pd.DataFrame:
        rent_maintenance = CostCategory.rent_maintenance.value
        ex_series = sub_df[ExpensesModel.category_3.name].map({
            'Loyer Financier': CostCategory.financial_rent.value,
            'Loyer Maintenance/Assistance': rent_maintenance,
            'Loyer Pneumatique': CostCategory.rent_tires.value,
            'Frais de mise en service': CostCategory.rent_others.value,
        })

        # Loyer vehicule de remplacement is flat fee < 10; actual otherwise
        rep_fee = CostCategory.rent_replacement_vehicle_flat_fee.value
        rep_actual = CostCategory.rent_replacement_vehicle_actual.value
        rep_cat_name = 'Loyer Véhicule de remplacement'

        ex_series = ex_series.where(
            pd.notna(ex_series) |
            (sub_df[ExpensesModel.category_3.name] != rep_cat_name) |
            (
                sub_df[ExpensesModel.amount_tax_inc.name].abs() >
                cls.REP_CAR_MAX_FEE
            ),
            rep_fee,
        )
        ex_series = ex_series.where(
            pd.notna(ex_series) |
            (sub_df[ExpensesModel.category_3.name] != rep_cat_name) |
            (
                sub_df[ExpensesModel.amount_tax_inc.name].abs() <=
                cls.REP_CAR_MAX_FEE
            ),
            rep_actual,
        )

        # Handle other rents; distinguish management cost, incidents,
        # restitution costs, fuel and replacement vehicle.
        ex_series = ex_series.where(
            (
                pd.notna(ex_series) |
                (sub_df[ExpensesModel.category_3.name] != 'Autres loyers') |
                (sub_df[ExpensesModel.product.name] != 'Pack Tranquillité')
            ),
            rep_fee,
        )

        # Sinistre dans deductible
        ex_series = ex_series.where(
            (
                pd.notna(ex_series) |
                (sub_df[ExpensesModel.category_3.name] != 'Autres loyers') |
                ~sub_df[ExpensesModel.product.name].str.contains(
                    'sinistre',
                    case=False,
                )
            ),
            CostCategory.insurance_deductible_cost.value
        )
        ex_series = ex_series.where(
            (
                pd.notna(ex_series) |
                (sub_df[ExpensesModel.category_3.name] != 'Autres loyers') |
                ~sub_df[ExpensesModel.product.name].str.contains(
                    'restitution',
                    case=False,
                )
            ),
            CostCategory.real_restitution.value
        )
        ex_series = ex_series.where(
            (
                pd.notna(ex_series) |
                (sub_df[ExpensesModel.category_3.name] != 'Autres loyers') |
                ~sub_df[ExpensesModel.product.name].str.lower().str.contains(
                    'provision carburant'
                )
            ),
            CostCategory.default_gaz.value
        )

        ex_series = ex_series.where(
            (
                pd.notna(ex_series) |
                (sub_df[ExpensesModel.category_3.name] != 'Autres loyers') |
                ~sub_df[ExpensesModel.product.name].str.lower().str.contains(
                    'loyer lmd'
                )
            ),
            CostCategory.real_medium_term_rental.value
        )
        ex_series = ex_series.where(
            (
                pd.notna(ex_series) |
                (sub_df[ExpensesModel.category_3.name] != 'Autres loyers')
            ),
            CostCategory.rent_others.value
        )

        # Remaining is full rent with no product specified
        ex_series = ex_series.fillna(CostCategory.financial_rent.value)

        return ex_series

    def pneumatiques(cls, sub_df: pd.DataFrame) -> pd.DataFrame:
        # TODO: we will want to distinguish subcategories within tires
        # Notably for winter vs summer, the first not being included in rent
        ex_series = sub_df[ExpensesModel.category_3.name].map({
            'Pneumatiques été': CostCategory.real_tires_summer.value,
            'Pneumatiques hiver': CostCategory.real_tires_winter.value,
            'Pneumatiques quatre saisons': CostCategory.real_tires_other.value,
        })
        ex_series.loc[
            pd.isna(ex_series) &
            (sub_df[ExpensesModel.category_3.name] == 'Pneumatiques autre') &
            sub_df[ExpensesModel.product.name].str.contains(
                r'\sforf\.?\spneus?\smontage',
                case=False,
                regex=True,
            )
        ] = CostCategory.real_tires_other.value
        ex_series.loc[
            pd.isna(ex_series) &
            (sub_df[ExpensesModel.category_3.name] == 'Pneumatiques autre') &
            sub_df[ExpensesModel.product.name].str.contains(
                'chaussette',
                case=False,
            )
        ] = CostCategory.real_tires_winter.value

        # TODO: Question à Matthieu Blaise: Est-ce qu'un remplacement ete/hiver
        # Peut être dans le forfait ou est toujours exclus? Si toujours exclus
        # Alors il faut systématiquement le classifier en hiver.
        ex_series.loc[
            pd.isna(ex_series) &
            (sub_df[ExpensesModel.category_3.name] == 'Pneumatiques autre') &
            (
                sub_df[ExpensesModel.product.name].str.upper() ==
                'FORF. PERMUT ETE/HIVER'
            )
        ] = CostCategory.real_tires_winter.value

        ex_series.loc[
            pd.isna(ex_series) &
            (sub_df[ExpensesModel.category_3.name] == 'Pneumatiques autre') &
            sub_df[ExpensesModel.product.name].str.contains(
                r'\s*ete\s+',
                case=False,
            )
        ] = CostCategory.real_tires_summer.value

        # Remaining cases are others
        ex_series.loc[
            pd.isna(ex_series) &
            (sub_df[ExpensesModel.category_3.name] == 'Pneumatiques autre')
        ] = CostCategory.real_tires_other.value
        ex_series.loc[
            pd.isna(ex_series) |
            pd.isna(sub_df[ExpensesModel.category_3.name])
        ] = CostCategory.real_tires_other.value

        cls.check_missed_cases(df=sub_df, series=ex_series)
        return ex_series

    def sinistre(cls, sub_df: pd.DataFrame) -> pd.DataFrame:
        deductible = CostCategory.insurance_deductible_cost.value
        ex_series = sub_df[ExpensesModel.product.name].map(
            {
                "Assurance Tous Risques": CostCategory.insurance_vehicle.value,
                'Dégradation': deductible,
                'DEGRADATIONS VEHICULE': deductible,
                'franchise': deductible,
                'impact parebrise': CostCategory.real_glass.value,
                'Sinistre refac. franchise': deductible,
                'bris de glace': CostCategory.real_glass.value,
            },
        )
        ex_series = ex_series.where(
            pd.notna(ex_series),
            sub_df[ExpensesModel.category_3.name].str.strip().map(
                {
                    'Responsabilité 0%': deductible,
                    'Responsabilité 100%': deductible,
                    'Responsabilité 50%': deductible,
                    'Auto assurance': CostCategory.self_insurance.value,
                },
            ),
        )
        cls.check_missed_cases(df=sub_df, series=ex_series)
        return ex_series

    def taxes(cls, sub_df: pd.DataFrame) -> pd.DataFrame:
        ex_series = sub_df[ExpensesModel.category_3.name].map({
            'PV de stationnement': CostCategory.fines.value,
            'PV Excès de vitesse': CostCategory.fines.value,
            'Taxe ancienneté véhicule': CostCategory.company_car_tax.value,
            'Taxe sur les émission de CO2': CostCategory.company_car_tax.value,
            'TVS': CostCategory.company_car_tax.value,
            'Autres PV': CostCategory.fines.value,
        })
        ex_series = ex_series.mask(
            (
                sub_df[ExpensesModel.category_3.name] ==
                "Bonus ou Malus écologique"
            )
            & (sub_df[ExpensesModel.amount_tax_exc.name] < 0),
            CostCategory.environmental_bonus.value,
        )
        ex_series = ex_series.mask(
            (
                sub_df[ExpensesModel.category_3.name] ==
                "Bonus ou Malus écologique"
            )
            & (sub_df[ExpensesModel.amount_tax_exc.name] >= 0),
            CostCategory.environmental_malus.value,
        )
        cls.check_missed_cases(df=sub_df, series=ex_series)
        return ex_series

    def nan(cls, sub_df: pd.DataFrame) -> pd.DataFrame:
        ex_series = sub_df[ExpensesModel.product.name].map({
            'pneumatiques': CostCategory.real_tires_other.value,
        })
        cls.check_missed_cases(df=sub_df, series=ex_series)
        return ex_series

    @staticmethod
    def check_missed_cases(
        df: pd.DataFrame,
        series: pd.Series,
    ) -> pd.DataFrame:
        """ Checks that the series cover all the cases in the DataFrame"""
        if pd.isna(series).any():
            missing_df = df.loc[
                pd.isna(series),
                [
                    CollaboratorsModel.organization_employee_id.name,
                    VehiclesModel.plate_number.name,
                    ExpensesModel.category_2.name,
                    ExpensesModel.category_3.name,
                    ExpensesModel.product.name,
                    ExpensesModel.amount_tax_inc.name,
                ]
            ]

            raise ValueError(
                f'Current rules do not cover all cases: '
                f'{missing_df}'
            )


if __name__ == "__main__":
    logger = gen_logger("GACBudget")
    gac_export_data = GacBudgetData(
        folder=os.path.join(
            '/home/matthieuglotz/Documents/Data/Quartus/GAC',
            GacBudgetData.NAME,
        ),
        logger=logger,
        source_connector="GAC",
        organization_name="Quartus",
    )
    for dataframe in gac_export_data:
        print(dataframe)
