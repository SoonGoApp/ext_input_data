""" A module to import data from GAC fleet section"""
import logging
import os
from enum import Enum, unique

from data_models import (
    VehiclesModel, CollaboratorsModel, BusinessUnitsModel, MileageReportsModel,
    VehicleReportsModel, VehicleContractsModel
)
from utils.logging import gen_logger
from utils.dataset import Dataset
from utils.enums import SynchronizationTypes


@unique
class GacFleetTables(Enum):
    CO2_footprint = 'CO2_FOOTPRINT'
    fleet_per_supplier = 'FLEET_PER_SUPPLIER'
    fleet_per_make = 'FLEET_PER_MAKE'


class GacFleetData(Dataset):

    NAME = 'FLEET'
    TYPE = SynchronizationTypes.csv_upload.value

    def __init__(
        self,
        folder: str,
        logger: logging.Logger,
        source_connector: str,
        organization_name: str,
    ):
        super().__init__(
            folder=folder,
            logger=logger,
            source_connector=source_connector,
            name=self.NAME,
            type=self.TYPE,
            organization_name=organization_name,
        )
        self.load_table(
            file_path=os.path.join(folder, 'empreinte_carbone.csv'),
            col_lst=[
                VehiclesModel.plate_number,
                CollaboratorsModel.employee_first_name,
                CollaboratorsModel.employee_last_name,
                BusinessUnitsModel.entity_1,
                BusinessUnitsModel.entity_2,
                BusinessUnitsModel.entity_3,
                MileageReportsModel.kilometers_driven,
                VehiclesModel.initial_mileage,
                MileageReportsModel.mileage.return_variant(
                    raw_name='Dernier relevé km',
                ),
                VehiclesModel.theoretical_CO2_per_km.return_variant(
                    raw_name='Émissions de CO2',
                ),
                VehicleReportsModel.CO2_emissions,
                VehicleContractsModel.lease_mileage,
                VehicleReportsModel.expected_CO2_emissions,
                VehiclesModel.make,
                VehiclesModel.model,
                VehiclesModel.vehicle_internal_category,
                VehiclesModel.full_model.return_variant(
                    raw_name='Véhicule'
                ),
                VehiclesModel.fiscal_type,
            ],
            record_dates=[],
            source_table=GacFleetTables.CO2_footprint.value,
        )
        self.load_table(
            file_path=os.path.join(folder, 'parc_par_fournisseur.csv'),
            col_lst=[
                VehiclesModel.car_supplier,
                VehicleReportsModel.vehicle_count,
                VehicleContractsModel.total_rent_ttc.return_variant(
                    raw_name='Loyer Mens.'
                ),
                VehicleReportsModel.total_rent_per_car,
                VehicleContractsModel.lease_months.return_variant(
                    raw_name='Mois engagés',
                ),
                VehicleContractsModel.lease_mileage.return_variant(
                    raw_name='Km engagés'
                ),
                VehicleReportsModel.tco_tax_inc.return_variant(
                    raw_name='Coût engagé'
                ),
                VehicleReportsModel.cost_per_km,
            ],
            record_dates=[],
            source_table=GacFleetTables.fleet_per_supplier.value,
        )
        self.load_table(
            file_path=os.path.join(folder, 'parc_par_marque.csv'),
            col_lst=[
                VehiclesModel.make.return_variant(raw_name='Fournisseur'),
                VehicleReportsModel.vehicle_count,
                VehicleContractsModel.total_rent_ttc.return_variant(
                    raw_name='Loyer Mens.'
                ),
                VehicleReportsModel.total_rent_per_car,
                VehicleContractsModel.lease_months.return_variant(
                    raw_name='Mois engagés',
                ),
                VehicleContractsModel.lease_mileage.return_variant(
                    raw_name='Km engagés'
                ),
                VehicleReportsModel.tco_tax_inc.return_variant(
                    raw_name='Coût engagé',
                ),
                VehicleReportsModel.cost_per_km,
            ],
            record_dates=[],
            source_table=GacFleetTables.fleet_per_make.value,
        )


if __name__ == "__main__":
    logger = gen_logger("GacFleet")
    gac_export_data = GacFleetData(
        folder=os.path.join(
            '/home/matthieuglotz/Documents/Data/Quartus/GAC',
            GacFleetData.NAME,
        ),
        logger=logger,
        source_connector="GAC",
        organization_name="Quartus",
    )
    for dataframe in gac_export_data:
        print(dataframe)
