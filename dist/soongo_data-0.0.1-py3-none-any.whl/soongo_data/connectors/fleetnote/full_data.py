""" FleetNote Data

Class loading, normalizing and organizing all FleetNote Datasets for a given
organization
"""
import re
import os
import typing
from enum import Enum, unique

import numpy as np
import pandas as pd

from data_models import (
    VehicleAssociationsModel, VehiclesModel, ExpensesModel,
    MileageReportsModel, CollaboratorsModel, BusinessUnitsModel,
    SoonGoRecordsModel
)
from utils.dataset import Dataset, add_connector
from utils.logging import gen_logger
from utils.type import (
    convert_string, series_is_nan, convert_date, convert_numeric,
    get_dtype_null
)
from utils.enums import CostCategory, FuelTypes, SynchronizationTypes


@unique
class FleetNoteTables(Enum):
    expenses = 'EXPENSES'
    mileage = 'MILEAGE'


@add_connector
class FleetNoteData(Dataset):
    SOURCE_CONNECTOR = 'FLEETNOTE'
    NAME = 'FLEETNOTE'
    TYPE = SynchronizationTypes.csv_upload.value
    PRODUCT_CODE_MAPPING = {
        "75": CostCategory.real_relay_vehicle_cost.value,
        '075': CostCategory.real_relay_vehicle_cost.value,  # Refacturation Véhicule Relais
        '110': CostCategory.financial_rent.value,  # Amortissement
        '115': CostCategory.rent_others.value,  # Carte grise/Vignette
        '120': CostCategory.financial_rent.value,  # Carte grise/Vignette
        "135": CostCategory.insurance_deductible_cost.value,
        "136": CostCategory.real_assistance.value,
        "140": CostCategory.real_short_term_rental.value,
        '200': CostCategory.rent_maintenance.value,  # Maintenance
        '250': CostCategory.rent_maintenance.value,  # Loyer pneumatiques
        "306": CostCategory.real_repairs.value,  # Perte financiere epave
        '308': CostCategory.rent_financial_loss.value,  # Mandat perte financière
        "407": CostCategory.real_others.value,
        '0499': CostCategory.real_others.value,  # Accessoires
        '499': CostCategory.real_others.value,  # Accessoires
        '0501': CostCategory.washing_real.value,  # Lavage
        '501': CostCategory.washing_real.value,  # Lavage
        '0503': CostCategory.washing_real.value,  # Lavage
        "513": CostCategory.financial_rent_adjustment.value,
        "510": CostCategory.financial_rent_adjustment.value,
        '0540': CostCategory.washing_real.value,
        '540': CostCategory.washing_real.value,
        '0541': CostCategory.washing_real.value,
        '541': CostCategory.washing_real.value,
        '0542': CostCategory.washing_real.value,
        '542': CostCategory.washing_real.value,
        '0543': CostCategory.washing_real.value,
        '543': CostCategory.washing_real.value,
        '0544': CostCategory.washing_real.value,
        '544': CostCategory.washing_real.value,
        '0545': CostCategory.washing_real.value,
        '545': CostCategory.washing_real.value,
        '548': CostCategory.washing_card.value,
        '0548': CostCategory.washing_card.value,
        '0550': CostCategory.washing_card.value,
        '550': CostCategory.washing_card.value,
        '0561': CostCategory.washing_real.value,
        '561': CostCategory.washing_real.value,
        '0562': CostCategory.washing_real.value,
        '562': CostCategory.washing_real.value,
        '0563': CostCategory.washing_real.value,
        '563': CostCategory.washing_real.value,
        '0565': CostCategory.washing_real.value,
        '565': CostCategory.washing_real.value,
        '0571': CostCategory.washing_real.value,
        '571': CostCategory.washing_real.value,
        '0572': CostCategory.washing_real.value,
        '572': CostCategory.washing_real.value,
        '0573': CostCategory.washing_real.value,
        '573': CostCategory.washing_real.value,
        '0574': CostCategory.washing_real.value,
        '0604': CostCategory.real_others.value,
        '604': CostCategory.real_others.value,
        "609": CostCategory.real_repairs.value, 
        "697": CostCategory.real_others.value,
        '0710': CostCategory.tolls_real.value,  # Péage
        '710': CostCategory.tolls_real.value,  # Péage
        '711': CostCategory.tolls_real.value,  # Péage
        '0711': CostCategory.tolls_real.value,  # Péage
        '0730': CostCategory.tolls_real.value,  # Péage
        '730': CostCategory.tolls_real.value,  # Péage
        '0731': CostCategory.tolls_real.value,  # Péage
        '731': CostCategory.tolls_real.value,  # Péage
        '0739': CostCategory.parking_real.value,
        '739': CostCategory.parking_real.value,
        '740': CostCategory.parking_real.value,
        '0741': CostCategory.tolls_card.value,
        '741': CostCategory.tolls_card.value,
        '0746': CostCategory.tolls_card.value,  # Liber-T Badge
        '746': CostCategory.tolls_card.value,  # Liber-T Badge
        "813": CostCategory.real_glass.value,
        "816": CostCategory.real_repairs.value,
        "817": CostCategory.real_repairs.value,
        "819": CostCategory.real_repairs.value,
        "825": CostCategory.real_tires_other.value,
        "827": CostCategory.real_repairs.value,
        "833": CostCategory.real_others.value,
        "847": CostCategory.insurance_deductible_cost.value,
        "859": CostCategory.real_relay_vehicle_cost.value,
        "863": CostCategory.real_others.value,
        "866": CostCategory.real_restitution.value,
        "867": CostCategory.termination_fees.value,  # Indemnités retour anticip
        "877": CostCategory.real_repairs.value,
        "879": CostCategory.environmental_malus.value,
        "880": CostCategory.environmental_bonus.value,
        "881": CostCategory.real_others.value,
        "0961": CostCategory.real_others.value,
        "2201": CostCategory.parking_real.value,
        '8906': CostCategory.electricity.value,  # Frais de service EV
        '8910': CostCategory.tolls_real.value,  # Frais Péage
        "8918": CostCategory.tolls_real.value,
        "8940": CostCategory.real_others.value,
        '8961': CostCategory.real_fuel_card.value,  # Action carte à puce (spécifique GR)
        '9020': CostCategory.parking_real.value,  # Frais Parking
        "9021": CostCategory.parking_real.value,
        'CAR': CostCategory.default_gaz.value,
        'CAT': CostCategory.default_gaz.value,
        'SCA': CostCategory.default_gaz.value,
        'FPC1': CostCategory.real_fuel_card.value,  # Flexipro Performance
        'FPC7': CostCategory.real_fuel_card.value,  # Flexipro Performance
        'FHO': CostCategory.real_others.value,  # Frais Hors Ouvert. CD
        'X700': CostCategory.real_fuel_card.value,  # Actys ET X7 EV
        'MDC': CostCategory.default_gaz.value,  # Carburant véhicule de remplacement
        'TIS4': CostCategory.tolls_card.value,  # Liber-t ASF
        "TIS7": CostCategory.tolls_card.value,
        'PXPY': CostCategory.real_fuel_card.value,  # FLEXIPRO Performance
        'AMBO': CostCategory.real_fuel_card.value,  # Pack ACTYS Fr CM Base San
        'SUA': CostCategory.real_others.value,  # Supplément aéroport
        "F00017": CostCategory.parking_real.value,
        "0285": CostCategory.gnc.value,
        "285": CostCategory.gnc.value,
        'LPNE': CostCategory.rent_tires.value,
        "LAMD": CostCategory.real_others.value,
        "LMAIASS": CostCategory.rent_maintenance.value,
        "LVER": CostCategory.rent_replacement_vehicle_flat_fee.value,  # Véhicule de remplacement
        "LLOY": CostCategory.financial_rent.value,
        "LSER": CostCategory.rent_maintenance.value,
        "FRA_AMDG": CostCategory.real_others.value,  # Frais de gestion amende
        "FRE": CostCategory.real_restitution.value,
        "REGSERVADMIN": CostCategory.rent_management_fees.value,  # "Frais de gestion de contrat"
        "REGVTYRCH": CostCategory.rent_tires.value,
        "REGRELIEF": CostCategory.rent_relay_vehicle_flat_fee.value,
        "REGMTCE": CostCategory.rent_maintenance.value,
        "PES71002": CostCategory.financial_rent.value,
        "TYR": CostCategory.real_tires_other.value,
        "FINEADMIN": CostCategory.real_others.value,  # amende
        "FGSMR": CostCategory.real_tires_other.value,
        "PES71001": CostCategory.financial_rent.value,
        "LFC": CostCategory.financial_rent_adjustment.value,
        "ADVTYRCH": CostCategory.rent_tires.value,
        "ADVMTCE": CostCategory.rent_maintenance.value,
        "PAS71002": CostCategory.financial_rent.value,
        "REP": CostCategory.rent_maintenance.value,
        "FRA_AMD": CostCategory.real_others.value,
        "FRAIS_CD": CostCategory.real_short_term_rental.value,
        "FCD": CostCategory.insurance_deductible_cost.value,
        "VRU": CostCategory.real_replacement_vehicle_cost.value,
        "RCERTDIFFCH": CostCategory.real_others.value,
        "RI1": CostCategory.real_restitution.value,
        "01R1": CostCategory.fuel_card_end_of_year.value,
        "FDI": CostCategory.real_others.value,
        "VRP": CostCategory.real_replacement_vehicle_cost.value,
        "EM": CostCategory.financial_rent_adjustment.value,  # Indemnités : KM supplémentaires
        "DCLES": CostCategory.real_others.value,
        "LD100": CostCategory.rent_maintenance.value,
        "LD003": CostCategory.rent_management_fees.value,
        "LD103": CostCategory.rent_relay_vehicle_flat_fee.value,
        "LD001": CostCategory.financial_rent.value,
        "814_750A": CostCategory.insurance_restitution.value,
        "814_900": CostCategory.insurance_restitution.value,
        "LD102": CostCategory.rent_tires.value,
        "RI2": CostCategory.real_restitution.value,  # Restitution bris de glace
        "PAS71001": CostCategory.financial_rent_adjustment.value,
        "RI4": CostCategory.real_restitution.value,
        "LD0011": CostCategory.financial_rent_adjustment.value,
        "815_900": CostCategory.insurance_restitution.value,
        "219_1": CostCategory.environmental_bonus.value,
        "F00027": CostCategory.financial_rent.value,
        "F00054": CostCategory.real_repairs.value,
        "F00084": CostCategory.real_restitution.value,
        "F00050": CostCategory.rent_maintenance.value,
        "F00079": CostCategory.rent_tires.value,
        "F00047": CostCategory.real_maintenance.value,
        "F00080": CostCategory.real_tires_other.value,
        "F00072": CostCategory.real_others.value,  # Fines
        "F00002": CostCategory.real_assistance.value,
        "REMB_COND": CostCategory.real_repairs.value,  # Remb insurance
        "MFR": CostCategory.insurance_deductible_cost.value,
        "FRREGEOCFEE": CostCategory.real_others.value,
        "IMM": CostCategory.real_others.value,
        "FCC": CostCategory.termination_fees.value,  # Indemnités résiliation
        "REM": CostCategory.real_restitution.value,  # Remise sur frais de restitution
        "MDL": CostCategory.real_medium_term_rental.value,
        "VRS": CostCategory.real_replacement_vehicle_cost.value,
        "UM": CostCategory.financial_rent_adjustment.value,
        "FIN": CostCategory.fines.value,
        "KMINO": CostCategory.financial_rent_adjustment.value,
        "FINEMAADMIN": CostCategory.real_others.value,  # Frais de gestion amendes
        "RFDC": CostCategory.financial_rent_adjustment.value,
        "MDP": CostCategory.real_others.value,  # frais de gestion LMD
        "FRA_CQA": CostCategory.real_others.value,  # Vignettes
        "AUT": CostCategory.real_others.value,
        "FRA_CPI": CostCategory.real_others.value,
        "GES_CPI": CostCategory.real_others.value,
        "RI3": CostCategory.real_restitution.value,
        "L1LO": CostCategory.financial_rent.value,
        "LPTR": CostCategory.rent_replacement_vehicle_flat_fee.value,
        "LP_ENT": CostCategory.rent_maintenance.value,
        "LP_HON": CostCategory.rent_management_fees.value,
        "LP_FIN": CostCategory.financial_rent.value,
        "LP_GES": CostCategory.rent_management_fees.value,
        "BDLOGTRASF": CostCategory.real_others.value,
        "LTB11": CostCategory.real_tires_other.value,
        "0000001585": CostCategory.financial_rent_adjustment.value,
        "0000001599": CostCategory.real_others.value,
        "ADM": CostCategory.real_others.value,
        "FRA_DLR": CostCategory.real_others.value,
        "DLR": CostCategory.real_others.value,
        "FRAN": CostCategory.real_restitution.value,
        "FRREGFEE": CostCategory.real_others.value,
        "FRREGCIDUP": CostCategory.real_others.value,
        "MDD": CostCategory.real_restitution.value,
        "LTC1X": CostCategory.real_tires_other.value,
        "LTA11": CostCategory.real_tires_other.value,
        "WARECHGM": CostCategory.real_maintenance.value,  # SMR hors contrat?
        "F00008": CostCategory.insurance_vehicle.value,
        "TRA_RETRO": CostCategory.real_others.value,
        "F00019": CostCategory.real_others.value,
        "F00069": CostCategory.real_others.value,
        "ET-FIN": CostCategory.termination_fees.value,
        "0000002356": CostCategory.real_others.value,
        "F00086": CostCategory.real_glass.value,
        "F00044": CostCategory.real_glass.value,
        "GESCORECLA": CostCategory.real_others.value,
        "WTP": CostCategory.weight_tax.value,
        "VKU": CostCategory.real_replacement_vehicle_cost.value,
        "F00085": CostCategory.real_restitution.value,
        "F00089": CostCategory.insurance_deductible_cost.value,
        "F00088": CostCategory.real_repairs.value,  # Epave
        "F00087": CostCategory.real_repairs.value,  # Frais de gestion sinistres
        "LTA13": CostCategory.real_tires_other.value,
        "LTB13": CostCategory.real_tires_other.value,
        "804": CostCategory.real_replacement_vehicle_cost.value,
        "0740": CostCategory.parking_real.value,
        "F00101": CostCategory.tax_other.value,
        "F00096": CostCategory.real_others.value,
        "F00022": CostCategory.real_others.value,
    }
    ID_COLS = [
        ExpensesModel.billing_ref.name,
        ExpensesModel.billing_date.name,
        VehiclesModel.plate_number.name,
        ExpensesModel.product_ref.name,
        CollaboratorsModel.organization_employee_id.name,
        'stringified_amount',
    ]

    def __init__(
        self,
        folder: str,
        organization_name: str,
        log_file: typing.Optional[str] = None,
    ) -> None:
        """ Instantiates FleetNoteData object containing all the FleetNote tables

        :param folder: str path to the root folder where all the data is
            stored.
        :param log_file: file where to write logs

        :raises ValueError: if folder is not a valid path or does not
        contain all required subfolders
        """
        super().__init__(
            folder=folder,
            logger=gen_logger(
                name=self.__class__.__name__,
                file_path=log_file,
            ),
            source_connector=self.SOURCE_CONNECTOR,
            name=self.NAME,
            type=self.TYPE,
            organization_name=organization_name,
        )
        self.import_expenses()
        self.import_mileages()

    def import_consumption(self: typing.Self, year: int) -> pd.DataFrame:
        expense_df = self.load_table(
            file_path=os.path.join(
                self.folder,
                f'CONSO_ACORUS_{year}.csv'
            ),
            col_lst=[
                VehiclesModel.plate_number.return_variant(
                    raw_name='Immatriculation',
                ),
                VehiclesModel.fiscal_type.return_variant(
                    raw_name='Norme fiscale',
                ),
                MileageReportsModel.mileage.return_variant(
                    raw_name='Kilométrage',
                ),
                CollaboratorsModel.organization_employee_id.return_variant(
                    raw_name='Matricule RH collaborateur affecté au véhicule à la date de prestation',
                    post_processing=process_organization_id,
                ),
                CollaboratorsModel.employee_last_name.return_variant(
                    raw_name='Nom collaborateur affecté au véhicule à la date de prestation',
                ),
                CollaboratorsModel.employee_first_name.return_variant(
                    raw_name='Prénom collaborateur affecté au véhicule à la date de prestation',
                ),
                BusinessUnitsModel.entity_1.return_variant(
                    raw_name='Niv-1 org. opérationnelle (code)'
                ),
                BusinessUnitsModel.entity_2.return_variant(
                    raw_name='Niv-2 org. opérationnelle (code)'
                ),
                BusinessUnitsModel.entity_3.return_variant(
                    raw_name='Organisation analytique du collaborateur (code)'
                ),
                ExpensesModel.billing_start_date.return_variant(
                    raw_name='Date de début de prestation',
                    post_processing=parse_conso_date,
                ),
                ExpensesModel.billing_end_date.return_variant(
                    raw_name='Date de fin de prestation',
                    post_processing=parse_conso_date,
                ),
                ExpensesModel.expense_location,
                ExpensesModel.expense_department_code,
                ExpensesModel.expense_country,
                ExpensesModel.product_ref.return_variant(
                    raw_name='Code produit fournisseur',
                    post_processing=convert_string,
                ),
                ExpensesModel.product.return_variant(
                    raw_name='Libellé produit fournisseur',
                ),
                ExpensesModel.category_2.return_variant(
                    raw_name='Libellé famille générique',
                ),
                ExpensesModel.supplier.return_variant(
                    raw_name='Libellé fournisseur facturant',
                ),
                SoonGoRecordsModel.document_date,
                BusinessUnitsModel.billed_entity.return_variant(
                    raw_name='Société facturée pièce',
                ),
                ExpensesModel.quantity.return_variant(
                    raw_name='Quantité',
                ),
                ExpensesModel.unit_price.return_variant(
                    raw_name='Prix HT unitaire',
                ),
                ExpensesModel.vat_rate.return_variant(
                    raw_name='Taux TVA',
                    post_processing=parse_vat_rate,
                ),
                ExpensesModel.amount_tax_exc.return_variant(
                    raw_name='Montant HT',
                ),
                ExpensesModel.vat_amount.return_variant(
                    raw_name='Montant TVA',
                ),
                ExpensesModel.amount_tax_inc.return_variant(
                    raw_name='Montant TTC',
                ),
                ExpensesModel.billing_ref.return_variant(
                    raw_name='Numéro Source'
                )
            ],
            skip_cols=[
                'Identifiant véhicule',
                'Identifiant collaborateur affecté au véhicule à la date de prestation',
                'Société juridique du collaborateur (code)',
                'Société juridique du collaborateur',
                'Niv-1 org. opérationnelle',
                'Niv-2 org. opérationnelle',
                'Niv-3 org. opérationnelle (code)',
                'Niv-3 org. opérationnelle',
                'Niv-4 org. opérationnelle (code)',
                'Niv-4 org. opérationnelle',
                'Niv-5 org. opérationnelle (code)',
                'Niv-5 org. opérationnelle',
                'Niv-6 org. opérationnelle (code)',
                'Niv-6 org. opérationnelle',
                'Organisation analytique du collaborateur',
                'Jour',
                'Jour férié',
                'Libellé fournisseur prestant',
                'Source',
                'Société facturée pièce (code)',
            ],
            record_dates=[
                ExpensesModel.billing_start_date.name,
                ExpensesModel.billing_end_date.name,
            ],
            source_table=FleetNoteTables.expenses.value,
        )

        expense_df[ExpensesModel.billing_date.name] = pd.to_datetime(
            expense_df[ExpensesModel.billing_end_date.name].dt.date
        )
        expense_df[MileageReportsModel.mileage_date.name] = (
            expense_df[ExpensesModel.billing_end_date.name]
        )
        expense_df['stringified_amount'] = (
            expense_df[ExpensesModel.amount_tax_exc.name].round(2).astype(str)
        )
        value_cols = [
            ExpensesModel.quantity.name,
            MileageReportsModel.mileage.name,
            MileageReportsModel.mileage_date.name,
            ExpensesModel.expense_location.name,
            ExpensesModel.expense_department_code.name,
            ExpensesModel.expense_country.name,
        ]
        expense_df = expense_df[
            self.ID_COLS + value_cols
        ].drop_duplicates()

        # Correct duplicates
        expense_df['dup_count'] = expense_df.groupby(
            self.ID_COLS
        )['stringified_amount'].transform('count')
        for col_name in value_cols:
            expense_df['value_count'] = expense_df.groupby(
                self.ID_COLS
            )[col_name].transform(lambda x: x.nunique(dropna=False))
            expense_df[col_name] = expense_df[col_name].mask(
                expense_df['value_count'] > 1,
                get_dtype_null(expense_df[col_name].dtype)
            )
        expense_df = expense_df[
            self.ID_COLS + value_cols
        ].drop_duplicates()

        assert len(expense_df[self.ID_COLS].drop_duplicates()) == len(expense_df)

        return expense_df

    def import_expenses(self):
        """ Import expense data, combining bill and consumption info"""
        df_lst = []
        for year in range(2021, 2025):
            consumption_df = self.import_consumption(year)
            expense_df = self.load_table(
                file_path=os.path.join(
                    self.folder,
                    f'FACTV4_ACORUS_{year}.csv'
                ),
                col_lst=[
                    ExpensesModel.supplier.return_variant(
                        raw_name='Libellé fournisseur',
                    ),
                    BusinessUnitsModel.billed_entity.return_variant(
                        raw_name='Libellé société facturée par le fournisseur',
                    ),
                    SoonGoRecordsModel.document_date,
                    ExpensesModel.amount_tax_exc.return_variant(
                        raw_name='Montant HT'
                    ),
                    ExpensesModel.vat_amount.return_variant(
                        raw_name='Montant TVA'
                    ),
                    ExpensesModel.amount_tax_inc.return_variant(
                        raw_name='Montant TTC'
                    ),
                    ExpensesModel.vat_rate.return_variant(
                        raw_name='TVA',
                        post_processing=parse_vat_rate,
                    ),
                    ExpensesModel.deductible_vat.return_variant(
                        raw_name='Montant TVA déductible',
                    ),
                    ExpensesModel.currency.return_variant(
                        raw_name='Devise',
                    ),
                    ExpensesModel.billing_start_date.return_variant(
                        raw_name='Date début période',
                        post_processing=parse_bill_date,
                    ),
                    ExpensesModel.billing_end_date.return_variant(
                        raw_name='Date fin période',
                        post_processing=parse_bill_date,
                    ),
                    ExpensesModel.product_ref.return_variant(
                        raw_name='Code produit fournisseur'
                    ),
                    ExpensesModel.product.return_variant(
                        raw_name='Libellé produit fournisseur'
                    ),
                    ExpensesModel.category_2.return_variant(
                        raw_name='Libellé famille générique'
                    ),
                    BusinessUnitsModel.entity_1.return_variant(
                        raw_name='Code niv-1 org. opérationnelle'
                    ),
                    BusinessUnitsModel.entity_2.return_variant(
                        raw_name='Code niv-2 org. opérationnelle'
                    ),
                    BusinessUnitsModel.entity_3.return_variant(
                        raw_name='Code analytique'
                    ),
                    VehiclesModel.plate_number.return_variant(
                        raw_name='Immatriculation',
                    ),
                    VehiclesModel.fiscal_type.return_variant(
                        raw_name='Norme fiscale'
                    ),
                    VehiclesModel.vehicle_status.return_variant(
                        raw_name='Statut véhicule'
                    ),
                    CollaboratorsModel.organization_employee_id.return_variant(
                        raw_name='Matricule RH',
                    ),
                    CollaboratorsModel.employee_last_name.return_variant(
                        raw_name='Nom collaborateur',
                    ),
                    CollaboratorsModel.employee_first_name.return_variant(
                        raw_name='Prénom collaborateur',
                    ),
                    ExpensesModel.billing_ref.return_variant(
                        raw_name='Numéro pièce',
                    )
                ],
                skip_cols=[
                    'Code fournisseur',
                    'Numéro client chez fournisseur',
                    'Nature pièce',
                    'Code TVA',
                    'Total facture HT',
                    'Total facture TVA',
                    'Total facture TTC',
                    'Code famille générique',
                    'Code client',
                    'Libellé client',
                    'Code société juridique',
                    'Libellé société juridique',
                    'Libellé analytique',
                    'Libellé niv-1 org. opérationnelle',
                    'Libellé niv-2 org. opérationnelle',
                    'Niv-3 org. opérationnelle (code)',
                    'Niv-3 org. opérationnelle',
                    'Niv-4 org. opérationnelle (code)',
                    'Niv-4 org. opérationnelle',
                    'Niv-5 org. opérationnelle (code)',
                    'Niv-5 org. opérationnelle',
                    'Niv-6 org. opérationnelle (code)',
                    'Niv-6 org. opérationnelle',
                    'Identifiant véhicule',
                    'Identifiant technique collaborateur',
                    'Identifiant collaborateur',
                ],
                record_dates=[
                    ExpensesModel.billing_start_date.name,
                    ExpensesModel.billing_end_date.name,
                ],
                source_table=FleetNoteTables.expenses.value,
            )
            expense_df['stringified_amount'] = (
                expense_df[ExpensesModel.amount_tax_exc.name].round(2).astype(str)
            )
            expense_df[ExpensesModel.billing_date.name] = (
                expense_df[ExpensesModel.billing_end_date.name]
            ).fillna(SoonGoRecordsModel.document_date.name)

            false_name = (
                (expense_df[CollaboratorsModel.employee_last_name.name] == 'NON ATTRIBUE')
                |
                (expense_df[CollaboratorsModel.organization_employee_id.name] == 'AGENCE')
            )
            for name_col in [
                CollaboratorsModel.employee_last_name.name,
                CollaboratorsModel.employee_first_name.name,
                CollaboratorsModel.organization_employee_id.name,
                CollaboratorsModel.employee_full_name.name,
            ]:
                expense_df[name_col] = expense_df[name_col].mask(false_name, '')

            expense_df = expense_df.merge(
                consumption_df,
                how='left',
                validate='m:1',
                on=self.ID_COLS,
            )
            expense_df.drop('stringified_amount', axis=1, inplace=True)
            df_lst.append(expense_df)

        expense_df = pd.concat(df_lst, axis=0, ignore_index=True)

        # Some erroneous billing_start_date values in the data, years before
        # the actual; replace with billing_end_date.
        expense_df[ExpensesModel.billing_start_date.name] = (
            expense_df[ExpensesModel.billing_start_date.name].mask(
                expense_df[ExpensesModel.billing_start_date.name] < (
                    expense_df[ExpensesModel.billing_end_date.name]
                    - pd.DateOffset(years=1)
                ),
                expense_df[ExpensesModel.billing_end_date.name]
            )
        )
        expense_df = self.categorize(expense_df)
        expense_df[VehiclesModel.car_supplier.name] = (
            expense_df[ExpensesModel.supplier.name].where(
                expense_df[ExpensesModel.expense_category.name] == CostCategory.financial_rent.value
            )
        )

        setattr(
            self,
            FleetNoteTables.expenses.value,
            expense_df
        )
        return expense_df

    def import_mileages(self) -> pd.DataFrame:

        mileage_df = self.agg_and_meld(
            eligible_files=[
                os.path.join(self.folder, file_name)
                for file_name in os.listdir(self.folder)
                if re.match(
                    r'(?:KM|Kilometrage) Total_ACORUS.* \d{4}\.csv',
                    file_name,
                )
            ],
            id_cols=[
                VehiclesModel.plate_number.return_variant(
                    raw_name='Immatriculation',
                    post_processing=convert_string,  # Not all formal immats
                ),
                VehiclesModel.vehicle_status.return_variant(
                    raw_name='Statut véhicule',
                ),
                VehiclesModel.entry_into_fleet_date.return_variant(
                    raw_name='Date entrée en parc',
                ),
                VehiclesModel.exit_from_fleet_date.return_variant(
                    raw_name='Date sortie de parc',
                ),
                CollaboratorsModel.employee_email.return_variant(
                    raw_name='Login collaborateur',
                ),
                CollaboratorsModel.organization_employee_id.return_variant(
                    raw_name='Matricule RH'
                ),
                CollaboratorsModel.employee_last_name.return_variant(
                    raw_name='Nom collaborateur'
                ),
                CollaboratorsModel.employee_first_name.return_variant(
                    raw_name='Prénom collaborateur'
                ),
                CollaboratorsModel.employee_category_name.return_variant(
                    raw_name='Catégorie conducteur'
                ),
                VehicleAssociationsModel.association_start_date.return_variant(
                    raw_name='Date début affectation',
                    post_processing=parse_conso_date,
                ),
                VehicleAssociationsModel.association_end_date.return_variant(
                    raw_name='Date fin affectation',
                    post_processing=parse_conso_date,
                ),
                BusinessUnitsModel.entity_1.return_variant(
                    raw_name='Niv-1 organisation opérationnelle'
                ),
                BusinessUnitsModel.entity_2.return_variant(
                    raw_name='Niv-2 organisation opérationnelle'
                ),
                BusinessUnitsModel.entity_3.return_variant(
                    raw_name='Libellé analytique',
                ),
                VehiclesModel.make.return_variant(
                    raw_name='Marque',
                ),
                VehiclesModel.model.return_variant(
                    raw_name='Modèle',
                ),
                VehiclesModel.full_model.return_variant(
                    raw_name='Version',
                ),
                VehiclesModel.fiscal_type.return_variant(
                    raw_name='Type'
                ),
                VehiclesModel.energy.return_variant(
                    raw_name='Énergie'
                ),
                VehiclesModel.theoretical_CO2_per_km.return_variant(
                    raw_name='CO2',
                ),
                MileageReportsModel.mileage.return_variant(
                    raw_name='Dernier km connu'
                ),
                MileageReportsModel.mileage_date.return_variant(
                    raw_name='Date dernier km connu'
                ),
            ],
            skip_cols=[
                'Identifiant véhicule',
                'Identifiant collaborateur',
                'Niv. 0 libellé société juridique',
                'Niv. 1 libellé société juridique',
                'Niv-3 organisation opérationnelle',
                'Niv-4 organisation opérationnelle',
                'Niv-5 organisation opérationnelle',
                'Niv-6 organisation opérationnelle',
                'Nombre de relevés sur 24 mois',
                'Unité de mesure',
                'Cumul M N-1',
                'Cumul M N',
                'Janvier N-1',
                'Février N-1',
                'Mars N-1',
                'Avril N-1',
                'Mai N-1',
                'Juin N-1',
                'Juillet N-1',
                'Août N-1',
                'Septembre N-1',
                'Octobre N-1',
                'Novembre N-1',
                'Décembre N-1',
                'Cumul N-1',
                'Janvier N',
                'Février N',
                'Mars N',
                'Avril N',
                'Mai N',
                'Juin N',
                'Juillet N',
                'Août N',
                'Septembre N',
                'Octobre N',
                'Novembre N',
                'Décembre N',
                'Cumul N',
                'Decembre N-1',
                'Nombre de consommations sur 24 mois',
            ],
            value_col='',
            var_col='',
            meld=False,
            record_dates=[MileageReportsModel.mileage_date.name],
            source_table=FleetNoteTables.mileage.value,
        )
        mileage_df[VehiclesModel.theoretical_CO2_per_km.name] = (
            mileage_df[VehiclesModel.theoretical_CO2_per_km.name].mask(
                (mileage_df[VehiclesModel.energy.name] != 'ELECTRIC') &
                (mileage_df[VehiclesModel.theoretical_CO2_per_km.name] <= 0.001),
                np.nan,
            )
        )
        false_name = (
            (mileage_df[CollaboratorsModel.employee_last_name.name] == 'NON ATTRIBUE')
            |
            (mileage_df[CollaboratorsModel.organization_employee_id.name] == 'AGENCE')
        )
        for name_col in [
            CollaboratorsModel.employee_last_name.name,
            CollaboratorsModel.employee_first_name.name,
            CollaboratorsModel.organization_employee_id.name,
            CollaboratorsModel.employee_full_name.name,
        ]:
            mileage_df[name_col] = mileage_df[name_col].mask(false_name, '')

        setattr(
            self,
            FleetNoteTables.mileage.value,
            mileage_df,
        )
        return mileage_df

    def categorize(self, df: pd.DataFrame) -> pd.DataFrame:
        """ Inserts SoonGo category in the DataFrame.

        :param df: df to categorize

        :raises ValueError: if df contains product_ref not handled by the
            current mapping logic
        """
        # Check product_ref indeed unique identifier of category
        dup_df = df[
            [ExpensesModel.product_ref.name, ExpensesModel.product.name]
        ].drop_duplicates()
        if not dup_df[ExpensesModel.product_ref.name].unique:
            dup_df['count'] = dup_df.groupby(
                ExpensesModel.product_ref.name
            ).transform('count')
            dup_df = dup_df.loc[
                dup_df['count'] > 1,
                [ExpensesModel.product_ref.name, ExpensesModel.product.name],
            ].to_dict(orient='records')

            raise ValueError(
                'The product_ref column does not uniquely identify products,'
                f' for example: {dup_df}'
            )

        df[ExpensesModel.expense_category.name] = (
            df[ExpensesModel.product_ref.name].map(self.PRODUCT_CODE_MAPPING)
        )
        df[ExpensesModel.expense_category.name] = (
            df[ExpensesModel.expense_category.name].fillna(
                df[ExpensesModel.product.name].map(FuelTypes.mapping())
            )
        )

        # Value dependent
        # LBEGE
        df[ExpensesModel.expense_category.name] = (
            df[ExpensesModel.expense_category.name].mask(
                (df[ExpensesModel.product_ref.name] == "LBEGE") &
                (df[ExpensesModel.amount_tax_exc.name] > 0),
                CostCategory.environmental_malus.value
            )
        )
        df[ExpensesModel.expense_category.name] = (
            df[ExpensesModel.expense_category.name].mask(
                (df[ExpensesModel.product_ref.name] == "LBEGE") &
                (df[ExpensesModel.amount_tax_exc.name] < 0),
                CostCategory.environmental_bonus.value
            )
        )

        missed_products = df.loc[
            ~series_is_nan(df[ExpensesModel.product_ref.name])
            & series_is_nan(df[ExpensesModel.expense_category.name]),
            [
                ExpensesModel.product_ref.name,
                ExpensesModel.product.name,
                ExpensesModel.category_2.name,
            ]
        ].drop_duplicates().to_dict(orient='records')

        if missed_products:
            raise ValueError(
                f'The categorizing logic does not handle the following '
                f'products: {missed_products}'
            )

        return df


def process_organization_id(id_series: pd.Series) -> pd.Series:
    id_series = id_series.replace('AGENCE', '')
    return convert_string(id_series)


def parse_conso_date(date_series: pd.Series) -> pd.Series:
    return convert_date(date_series, date_format=r'%d/%m/%Y %H:%M')


def parse_bill_date(date_series: pd.Series) -> pd.Series:
    return convert_date(
        convert_string(date_series).str.replace('/0021', '/2021'),
        date_format=r'%d/%m/%Y',
    )


def parse_vat_rate(var_series: pd.Series) -> pd.Series:
    return convert_numeric(
        convert_string(var_series).str.replace('%', '')
    )


class DateConverter:
    month_dict = {
        'Janvier': '01',
        'Février': '02',
        'Mars': '03',
        'Avril': '04',
        'Mai': '05',
        'Juin': '06',
        'Juillet': '07',
        'Août': '08',
        'Septembre': '09',
        'Octobre': '10',
        'Novembre': '11',
        'Décembre': '12',
    }

    def __init__(self, year: int):
        self.year = year

    def __call__(self, date_series: pd.Series) -> pd.Series:

        date_series = convert_string(date_series)

        for month_name, month_value in self.month_dict.items():
            date_series = date_series.str.replace(
                month_name,
                month_value,
            )

        date_series = date_series.str.replace(
            'N',
            str(self.year)
        )
        date_series = date_series.str.replace(
            'N-1',
            str(self.year-1)
        )

        # Convert the stringified year-month date series to datetime
        date_series = pd.to_datetime(date_series, format='%m %Y')

        # Get the end of the month
        date_series = date_series + pd.offsets.MonthEnd(0)
        return date_series


if __name__ == '__main__':
    logger = gen_logger('FleetNote')
    organization_name = 'Acorus'
    fleetnote_data = FleetNoteData(
        folder=f'/home/matthieuglotz/Documents/Data/{organization_name}/FLEETNOTE',
        organization_name=organization_name,
    )
    fleetnote_data.EXPENSES.to_csv('~/dev/temp/acorus_expenses.csv')

    for df in fleetnote_data:
        print(df)
