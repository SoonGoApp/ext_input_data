""" Athlon Data

Class loading, normalizing and organizing all datasets exported manually by
Domino, mostly for HR purposes
"""
import os
import typing
from enum import Enum, unique

import pandas as pd

from data_models import (
    CollaboratorsModel, BusinessUnitsModel, MileageReportsModel,
    VehiclesModel, VehicleContractsModel, ExpensesModel
)
from utils.dataset import Dataset, add_connector
from utils.logging import gen_logger
from utils.enums import mapper_factory, EnergyTypes, CostCategory, SynchronizationTypes
from utils.type import convert_names


@unique
class AthlonTables(Enum):
    vehicles = 'VEHICLES'
    contracts = 'CONTRACTS'
    rent_expenses = 'RENT_EXPENSES'
    other_expenses = 'OTHER_EXPENSES'


@add_connector
class AthlonData(Dataset):
    SOURCE_CONNECTOR = 'ATHLON'
    NAME = 'ATHLON'
    TYPE = SynchronizationTypes.csv_upload.value
    PRODUCT_CODE_MAPPING = {
        'LD001/3': CostCategory.financial_rent.value,  # Montant Loyer Financier
        'LD0011': CostCategory.financial_rent_adjustment.value,  # Apport initial
        'LD100': CostCategory.rent_maintenance.value,  # Entretien
        'LD105': CostCategory.rent_financial_loss.value,  # Perte Financière
        'FRAIS_G_TECH': CostCategory.real_others.value,  # FRAIS GESTION TECHNIQUE
        '100.6': CostCategory.real_repairs.value,  # Kit distribution / Courroie /galets
        '697': CostCategory.real_others.value,  # FRAIS DE GESTION BONUS ECOLOGIQUE
    }

    def __init__(
        self,
        folder: str,
        organization_name: str,
        log_file: typing.Optional[str] = None,
    ) -> None:
        """ Instantiates a Dataset from the exports received from Athlon

        :param folder: str path to the root folder where all the data is
            stored.
        :param log_file: file where to write logs

        :raises ValueError: if folder is not a valid path or does not
        contain all required subfolders
        """
        logger = gen_logger(
            name=self.__class__.__name__,
            file_path=log_file,
        )
        super().__init__(
            folder=folder,
            logger=logger,
            source_connector=self.SOURCE_CONNECTOR,
            name=self.NAME,
            type=self.TYPE,
            organization_name=organization_name,
        )
        if not os.path.isdir(os.path.expanduser(folder)):
            logger.error(
                'Provided root folder %s is not a valid directory',
                folder,
            )
        self.import_vehicles()
        self.import_contracts()
        self.import_rent_expenses()
        self.import_other_expenses()

    def import_other_expenses(self):
        other_df = self.load_table(
            file_path=os.path.join(
                self.folder,
                'other_expenses.xlsx',
            ),
            col_lst=[
                BusinessUnitsModel.company_name.return_variant(
                    raw_name='Groupe',
                ),
                VehiclesModel.plate_number.return_variant(
                    raw_name='Immatriculation',
                ),
                VehiclesModel.full_model.return_variant(
                    raw_name='Modèle',
                ),
                ExpensesModel.billing_date.return_variant(
                    raw_name='Date Facture',
                ),
                ExpensesModel.billing_start_date.return_variant(
                    raw_name='Date Début Facture',
                ),
                ExpensesModel.billing_end_date.return_variant(
                    raw_name='Date Fin Facture',
                ),
                ExpensesModel.billing_ref.return_variant(
                    raw_name='N° Facture',
                ),
                VehicleContractsModel.contract_reference.return_variant(
                    raw_name='N° Contrat',
                ),
                ExpensesModel.product_ref.return_variant(
                    raw_name='Code Produit',
                ),
                ExpensesModel.product.return_variant(
                    raw_name='Libellé Produit',
                ),
                ExpensesModel.quantity,
                ExpensesModel.unit_price.return_variant(
                    raw_name='HTU',
                ),
                ExpensesModel.amount_tax_exc.return_variant(
                    raw_name='Montant DV facturé  HT'
                ),
                ExpensesModel.vat_amount.return_variant(
                    raw_name='TVA'
                ),
                ExpensesModel.vat_rate.return_variant(
                    raw_name='Taux de TVA'
                ),
                ExpensesModel.amount_tax_inc.return_variant(
                    raw_name='Montant DV facturé  TTC'
                ),
                ExpensesModel.currency.return_variant(
                    raw_name='Devise',
                ),
                VehiclesModel.fiscal_type.return_variant(
                    raw_name='Genre',
                ),
                CollaboratorsModel.employee_full_name.return_variant(
                    raw_name='Nom du conducteur',
                    post_processing=convert_names(self.organization_name),
                ),
                BusinessUnitsModel.entity_1.return_variant(
                    raw_name='Centre de Coût 1'
                ),
                BusinessUnitsModel.entity_2.return_variant(
                    raw_name='Centre de Coût 2'
                ),
                BusinessUnitsModel.entity_3.return_variant(
                    raw_name='Centre de Coût 3'
                ),
            ],
            record_dates=[
                ExpensesModel.billing_date.name,
                ExpensesModel.billing_start_date.name,
                ExpensesModel.billing_end_date.name,
            ],
            source_table=AthlonTables.other_expenses.value,
            skip_cols=[
                'Code Groupe',
                'Raison Sociale',
                'Code Client',
                'Facture/Avoir',
                'Type Facture',
            ]
        )
        self.map_product_codes(other_df)
        setattr(
            self,
            AthlonTables.other_expenses.value,
            other_df,
        )
        return other_df

    def import_rent_expenses(self):
        rent_df = self.load_table(
            file_path=os.path.join(
                self.folder,
                'rents.xlsx',
            ),
            col_lst=[
                BusinessUnitsModel.company_name.return_variant(
                    raw_name='Groupe',
                ),
                VehiclesModel.plate_number.return_variant(
                    raw_name='Immatriculation',
                ),
                VehiclesModel.full_model.return_variant(
                    raw_name='Modèle',
                ),
                ExpensesModel.billing_date.return_variant(
                    raw_name='Date Facture',
                ),
                ExpensesModel.billing_start_date.return_variant(
                    raw_name='Date Début Facture',
                ),
                ExpensesModel.billing_end_date.return_variant(
                    raw_name='Date Fin Facture',
                ),
                ExpensesModel.billing_ref.return_variant(
                    raw_name='N° Facture',
                ),
                VehicleContractsModel.contract_reference.return_variant(
                    raw_name='N° Contrat',
                ),
                ExpensesModel.product_ref.return_variant(
                    raw_name='Code Produit',
                ),
                ExpensesModel.product.return_variant(
                    raw_name='Libellé Produit',
                ),
                ExpensesModel.quantity,
                ExpensesModel.unit_price.return_variant(
                    raw_name='HTU',
                ),
                ExpensesModel.amount_tax_exc.return_variant(
                    raw_name='Montant LD facturé  HT'
                ),
                ExpensesModel.vat_amount.return_variant(
                    raw_name='TVA'
                ),
                ExpensesModel.vat_rate.return_variant(
                    raw_name='Taux de TVA'
                ),
                ExpensesModel.amount_tax_inc.return_variant(
                    raw_name='Montant LD facturé  TTC'
                ),
                ExpensesModel.currency.return_variant(
                    raw_name='Devise',
                ),
                VehiclesModel.fiscal_type.return_variant(
                    raw_name='Genre',
                ),
                CollaboratorsModel.employee_full_name.return_variant(
                    raw_name='Nom du conducteur',
                    post_processing=convert_names(self.organization_name),
                ),
                BusinessUnitsModel.entity_1.return_variant(
                    raw_name='Centre de Coût 1'
                ),
                BusinessUnitsModel.entity_2.return_variant(
                    raw_name='Centre de Coût 2'
                ),
                BusinessUnitsModel.entity_3.return_variant(
                    raw_name='Centre de Coût 3'
                ),
            ],
            record_dates=[
                ExpensesModel.billing_date.name,
                ExpensesModel.billing_start_date.name,
                ExpensesModel.billing_end_date.name,
            ],
            source_table=AthlonTables.rent_expenses.value,
            skip_cols=[
                'Code Groupe',
                'Raison Sociale',
                'Code Client',
                'Facture/Avoir',
                'Type Facture',
            ]
        )
        self.map_product_codes(rent_df)
        setattr(
            self,
            AthlonTables.rent_expenses.value,
            rent_df,
        )
        return rent_df

    def import_contracts(self):
        """ Import contracts table"""
        contracts_df = self.load_table(
            file_path=os.path.join(
                self.folder,
                'contracts.xlsx',
            ),
            col_lst=[
                BusinessUnitsModel.company_name.return_variant(
                    raw_name='Groupe',
                ),
                VehicleContractsModel.contract_reference.return_variant(
                    raw_name='N° Contrat',
                ),
                VehiclesModel.entry_into_service_date.return_variant(
                    raw_name='Date de 1ère mise en circulation'
                ),
                VehiclesModel.plate_number.return_variant(
                    raw_name='Immatriculation',
                ),
                VehiclesModel.serial_number.return_variant(
                    raw_name='N° Série',
                ),
                VehiclesModel.make,
                VehiclesModel.model,
                VehiclesModel.rebate_price_ttc.return_variant(
                    raw_name='Prix Remisé'
                ),  # TODO: check whether TTC
                VehiclesModel.fiscal_power.return_variant(
                    raw_name='CV',
                ),
                VehiclesModel.fiscal_type.return_variant(
                    raw_name='Genre',
                ),
                BusinessUnitsModel.entity_1.return_variant(
                    raw_name='Centre de Coût 1'
                ),
                BusinessUnitsModel.entity_2.return_variant(
                    raw_name='Centre de Coût 2'
                ),
                BusinessUnitsModel.entity_3.return_variant(
                    raw_name='Centre de Coût 3'
                ),
                CollaboratorsModel.employee_full_name.return_variant(
                    raw_name='Nom du conducteur',
                    post_processing=convert_names(self.organization_name),
                ),
                VehicleContractsModel.lease_months.return_variant(
                    raw_name='Durée contractuelle',
                ),
                VehicleContractsModel.lease_mileage.return_variant(
                    raw_name='Kms contractuels',
                ),
                VehicleContractsModel.lease_start_date.return_variant(
                    raw_name='Début de contrat',
                ),
                VehicleContractsModel.lease_end_date.return_variant(
                    raw_name='Fin de contrat théorique',
                ),
                MileageReportsModel.mileage.return_variant(
                    raw_name='Km dernier relevé',
                ),
                MileageReportsModel.mileage_date.return_variant(
                    raw_name='Date de dernier relevé km',
                ),
                VehicleContractsModel.financial_rent_ht.return_variant(
                    raw_name='Loyer de base mensuel',
                ),
                VehicleContractsModel.maintenance_rent_ht.return_variant(
                    raw_name='Loyer Entretien mensuel',
                ),
                VehicleContractsModel.summer_tires_rent_ht.return_variant(
                    raw_name='Loyer Pneus mensuel',
                ),
                VehicleContractsModel.all_weather_tires_rent_ht.return_variant(
                    raw_name='Loyer pneus mixtes',
                ),
                VehicleContractsModel.winter_tires_rent_ht.return_variant(
                    raw_name='Loyer pneus hiver',
                ),
                VehicleContractsModel.relay_car_rent_ht.return_variant(
                    raw_name='Loyer véhicule relais',
                ),
                VehicleContractsModel.fuel_card_management_fee_rent_ht.return_variant(
                    raw_name='Loyer Carburant Mensuel',
                ),
                VehicleContractsModel.financial_loss_rent_ht.return_variant(
                    raw_name='Loyer perte financière',
                ),
                VehicleContractsModel.civil_liability_rent_ht.return_variant(
                    raw_name='Loyer assurance RC',
                ),
                VehicleContractsModel.damage_insurance_rent_ht.return_variant(
                    raw_name='Loyer assurance dommages (Topaze)',
                ),
                VehicleContractsModel.other_rent_ht.return_variant(
                    raw_name='Loyer Prestations Supplémentaires',
                ),
                VehicleContractsModel.telematics_rent_ht.return_variant(
                    raw_name='Loyer prestation télépéage',
                ),
                VehicleContractsModel.accident_management_fee_rent_ht.return_variant(
                    raw_name='Loyer gestion de sinistres',
                ),
                VehicleContractsModel.total_rent_ht.return_variant(
                    raw_name='Loyer Total HT',
                ),
                ExpensesModel.vat_amount.return_variant(
                    raw_name='TVA',
                ),
                VehicleContractsModel.total_rent_ttc.return_variant(
                    raw_name='Loyer Total TTC',
                ),
            ],
            record_dates=[
                VehiclesModel.entry_into_service_date.name,
                MileageReportsModel.mileage_date.name,
            ],
            source_table=AthlonTables.contracts.value,
            skip_cols=[
                'Code Groupe',
                'Raison Sociale',
                'Code Client',
                'Nbre Pneus au contrat (utilisés / souscrits)',
                'Dont Nbre pneus été (utilisés / souscrits)',
                'Dont Nbre Pneus hiver (utilisés / souscrits)',
                'Dont Nbre Pneus Mixtes (utilisés / souscrits)',
                'N° de cde renouvellement',
                'Variation + / - 5% Kms contrat et kms estimés',
                'Projection Km fin de contrat',
                'Nbre Carte carburant',
                'Mois restants',
                "Km théorique aujourd'hui'",
                'Projection Km fin de contrat',
                'Renouvellement en cours',
                'Loyers restant dus',
                'Type de contrat',
            ]
        )
        contracts_df[VehicleContractsModel.tires_rent_ht.name] = (
            contracts_df[VehicleContractsModel.all_weather_tires_rent_ht.name]
            +
            contracts_df[VehicleContractsModel.winter_tires_rent_ht.name]
            +
            contracts_df[VehicleContractsModel.summer_tires_rent_ht.name]
        )

        setattr(
            self,
            AthlonTables.contracts.value,
            contracts_df,
        )
        return contracts_df

    def import_vehicles(self) -> pd.DataFrame:
        """ Import vehicles table"""

        vehicle_df = self.load_table(
            file_path=os.path.join(
                self.folder,
                'vehicles.xlsx',
            ),
            col_lst=[
                BusinessUnitsModel.company_name.return_variant(
                    raw_name='Groupe',
                ),
                VehicleContractsModel.contract_reference.return_variant(
                    raw_name='N° Contrat',
                ),
                VehiclesModel.plate_number.return_variant(
                    raw_name='Immatriculation',
                ),
                VehiclesModel.serial_number.return_variant(
                    raw_name='N° Série',
                ),
                VehiclesModel.make,
                VehiclesModel.model,
                VehiclesModel.full_model.return_variant(
                    raw_name='Version',
                ),
                VehiclesModel.fiscal_type.return_variant(
                    raw_name='Genre',
                ),
                VehiclesModel.theoretical_CO2_per_km.return_variant(
                    raw_name='Taux CO2',
                ),
                VehiclesModel.energy.return_variant(
                    raw_name='Energie',
                    post_processing=None,
                ),
                VehicleContractsModel.financial_rent_ht.return_variant(
                    raw_name='Loyer Financier Mensuel',
                ),
                VehicleContractsModel.maintenance_rent_ht.return_variant(
                    raw_name='Loyer Entretien mensuel',
                ),
                VehicleContractsModel.tires_rent_ht.return_variant(
                    raw_name='Loyer Pneus mensuel',
                ),
                VehicleContractsModel.relay_car_rent_ht.return_variant(
                    raw_name='Loyer véhicule relais',
                ),
                VehicleContractsModel.fuel_card_management_fee_rent_ht.return_variant(
                    raw_name='Loyer Carburant Mensuel',
                ),
                VehicleContractsModel.financial_loss_rent_ht.return_variant(
                    raw_name='Montant perte financière',
                ),
                VehicleContractsModel.civil_liability_rent_ht.return_variant(
                    raw_name='Loyer assurance RC',
                ),
                VehicleContractsModel.damage_insurance_rent_ht.return_variant(
                    raw_name='Loyer assurance dommages (Topaze)',
                ),
                VehicleContractsModel.total_rent_ht.return_variant(
                    raw_name='Loyer Total HT',
                ),
                ExpensesModel.vat_amount.return_variant(
                    raw_name='TVA',
                ),
                VehicleContractsModel.total_rent_ttc.return_variant(
                    raw_name='Loyer Total TTC',
                ),
                VehicleContractsModel.lease_start_date.return_variant(
                    raw_name='Début de contrat',
                ),
                VehicleContractsModel.lease_end_date.return_variant(
                    raw_name='Fin de contrat théorique',
                ),
                VehicleContractsModel.lease_months.return_variant(
                    raw_name='Durée contractuelle',
                ),
                VehicleContractsModel.lease_mileage.return_variant(
                    raw_name='Kms contractuels',
                ),
                MileageReportsModel.mileage.return_variant(
                    raw_name='Km dernier relevé',
                ),
                MileageReportsModel.mileage_date.return_variant(
                    raw_name='Date de dernier relevé km',
                ),
            ],
            record_dates=[
                VehicleContractsModel.lease_start_date.name,
                MileageReportsModel.mileage_date.name,
            ],
            source_table=AthlonTables.vehicles.value,
            skip_cols=[
                'Code Groupe',
                'Raison Sociale',
                'Code Client',
                'Nom du conducteur',
                'Nbre Pneus au contrat (utilisés / souscrits)',
                'Dont Nbre pneus été (utilisés / souscrits)',
                'Dont Nbre Pneus hiver (utilisés / souscrits)',
                'Dont Nbre Pneus Mixtes (utilisés / souscrits)',
                'N° de cde renouvellement',
                'Variation + / - 5% Kms contrat et kms estimés',
                'Projection Km fin de contrat',
                'Nbre Carte carburant',
                'Mois restants',
            ]
        )

        # Handle unspecified Hybrid
        hybrid_model = '1.5 COOPER SE ALL4 BUSI DESIGN HYBRID A'
        vehicle_df[VehiclesModel.energy.name] = mapper_factory(EnergyTypes)(
            vehicle_df[VehiclesModel.energy.name].mask(
                vehicle_df[VehiclesModel.full_model.name] == hybrid_model,
                EnergyTypes.gaz_hybrid_recharge.value,
            )
        )
        vehicle_df[VehicleContractsModel.insurance_rent_ht.name] = (
            vehicle_df[VehicleContractsModel.civil_liability_rent_ht.name] +
            vehicle_df[VehicleContractsModel.damage_insurance_rent_ht.name]
        )
        setattr(
            self,
            AthlonTables.vehicles.value,
            vehicle_df,
        )

        return vehicle_df

    @classmethod
    def map_product_codes(cls, expense_df: pd.DataFrame) -> pd.DataFrame:
        """ Map product codes and other expense information in a DataFrame to
        SoonGo Expense categories

        :param expense_df: DataFrame of rent or other expenses

        :returns: SoonGo Categories pandas series
        """
        expense_df[ExpensesModel.expense_category.name] = (
            expense_df[ExpensesModel.product_ref.name].map(
                cls.PRODUCT_CODE_MAPPING
            )
        )
        expense_df[ExpensesModel.expense_category.name] = (
            expense_df[ExpensesModel.expense_category.name].mask(
                (expense_df[ExpensesModel.product_ref.name] == '219_1') &
                (expense_df[ExpensesModel.amount_tax_exc.name] > 0),
                CostCategory.environmental_bonus.value,
            )
        )
        expense_df[ExpensesModel.expense_category.name] = (
            expense_df[ExpensesModel.expense_category.name].mask(
                (expense_df[ExpensesModel.product_ref.name] == '219_1') &
                (expense_df[ExpensesModel.amount_tax_exc.name] <= 0),
                CostCategory.environmental_malus.value,
            )
        )

        missing_categories = pd.isna(
            expense_df[ExpensesModel.expense_category.name]
        )
        if missing_categories.any():
            missing_df = expense_df.loc[
                missing_categories,
                [
                    VehiclesModel.plate_number.name,
                    ExpensesModel.product_ref.name,
                    ExpensesModel.product.name,
                    ExpensesModel.amount_tax_exc.name,
                ]
            ]

            raise ValueError(
                f'Current rules do not cover all cases: '
                f'{missing_df}'
            )

        return expense_df


if __name__ == '__main__':
    athlon_data = AthlonData(
        folder='/home/matthieuglotz/Documents/Data/Domino/ATHLON',
        organization_name='Domino',
    )
    for df in athlon_data:
        print(df)
