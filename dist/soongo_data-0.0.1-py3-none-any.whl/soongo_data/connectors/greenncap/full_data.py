""" GreenNCap Data

Class loading, normalizing and organizing all Concur Datasets for a given
organization
"""
import os
import typing
from enum import Enum, unique

import pandas as pd

from data_models import VehiclesModel, VehicleReportsModel
from utils.logging import gen_logger
from utils.dataset import Dataset, add_connector
from utils.enums import SynchronizationTypes


@unique
class GreenNCapTables(Enum):
    carbon_per_model = 'CARBON_PER_MODEL'


@add_connector
class GreenNCapData(Dataset):
    SOURCE_CONNECTOR = 'GREENNCAP'
    NAME = 'GREENNCAP'
    TYPE = SynchronizationTypes.csv_upload.value

    def __init__(
        self,
        folder: str,
        organization_name: str,
        log_file: typing.Optional[str] = None,
    ) -> None:
        """ Instantiates GreenNCapData object containing carbon data from
        GreenNCap

        :param folder: str path to the root folder where all the data is
            stored.
        :param log_file: file where to write logs

        :raises ValueError: if folder is not a valid path or does not
        contain all required subfolders
        """
        super().__init__(
            folder=folder,
            logger=gen_logger(
                name=self.__class__.__name__,
                file_path=log_file,
            ),
            source_connector=self.SOURCE_CONNECTOR,
            name=self.NAME,
            type=self.TYPE,
            organization_name=organization_name,
        )
        if not os.path.isdir(os.path.expanduser(folder)):
            raise ValueError(
                f'Provided root folder {folder} is not a valid directory'
            )
        self.load_table(
            file_path=os.path.join(folder, 'carbon per model.ods'),
            col_lst=[
                VehiclesModel.model.return_variant(
                    raw_name='model',
                ),
                VehiclesModel.energy.return_variant(
                    raw_name='energy',
                    # The provided energy names already are correct
                    post_processing=lambda x: x,
                ),
                VehicleReportsModel.vehicle_count.return_variant(
                    raw_name='count',
                ),
                VehiclesModel.CO2_production.return_variant(
                    post_processing=convert_tons_to_kg,
                ),
                VehiclesModel.CO2_recycling.return_variant(
                    post_processing=convert_tons_to_kg,
                ),
                VehiclesModel.theoretical_fuel_consumption,
                VehiclesModel.theoretical_CO2_per_km,
                VehiclesModel.measured_fuel_consumption,
                VehiclesModel.measured_CO2_per_km,
            ],
            record_dates=[],
            source_table=GreenNCapTables.carbon_per_model.value,
        )


def convert_tons_to_kg(series: pd.Series) -> pd.Series:
    return series * 1000


if __name__ == '__main__':
    greenncap_data = GreenNCapData(
        folder='/home/matthieuglotz/Documents/Data/Quartus/GREENNCAP',
        organization_name='Acorus',
    )
    for df in greenncap_data:
        print(df)
