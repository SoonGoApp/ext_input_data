""" Domino Data

Class loading, normalizing and organizing all datasets exported manually by
Domino, mostly for HR purposes
"""
import os
import typing
from enum import Enum, unique

import pandas as pd

from data_models import (
    CollaboratorsModel, BusinessUnitsModel, MileageReportsModel,
    AccidentsModel, TaxesModel, VehiclesModel
)
from utils.dataset import Dataset, add_connector
from utils.logging import gen_logger
from utils.type import convert_plate
from utils.enums import SynchronizationTypes


@unique
class DominoTables(Enum):
    collaborators_entry_exit = 'ENTRY_EXIT'
    collaborators_bu = 'BUSINESS_UNITS'
    mileage = 'MILEAGE'
    accidents = 'ACCIDENTS'
    taxes = 'TAXES'


@add_connector
class DominoData(Dataset):
    SOURCE_CONNECTOR = 'DOMINO'
    NAME = 'DOMINO'
    TYPE = SynchronizationTypes.csv_upload.value

    def __init__(
        self,
        folder: str,
        organization_name: str,
        log_file: typing.Optional[str] = None,
    ) -> None:
        """ Instantiates a Dataset from the exports received from Domino

        :param folder: str path to the root folder where all the data is
            stored.
        :param log_file: file where to write logs

        :raises ValueError: if folder is not a valid path or does not
        contain all required subfolders
        """
        logger = gen_logger(
            name=self.__class__.__name__,
            file_path=log_file,
        )
        super().__init__(
            folder=folder,
            logger=logger,
            source_connector=self.SOURCE_CONNECTOR,
            name=self.NAME,
            type=self.TYPE,
            organization_name=organization_name,
        )
        if not os.path.isdir(os.path.expanduser(folder)):
            logger.error(
                'Provided root folder %s is not a valid directory',
                folder,
            )
        self.import_collaborators_entry_exit()
        self.import_collaborators_bu()
        self.import_mileage()
        self.load_table(
            file_path=os.path.join(
                folder,
                'SINISTRALITE DOMINO RH 2023.xlsx',
            ),
            col_lst=[
                AccidentsModel.accident_ref.return_variant(
                    raw_name='N° Sinistre',
                ),
                AccidentsModel.accident_date.return_variant(
                    raw_name='Date sinistre',
                ),
                AccidentsModel.accident_location.return_variant(
                    raw_name='Adresse lieu sinistre 1',
                ),
                AccidentsModel.accident_status.return_variant(
                    raw_name='Statut ',
                ),
                AccidentsModel.responsibility.return_variant(
                    raw_name='Taux responsabilité (%)',
                ),
                AccidentsModel.accident_type.return_variant(
                    raw_name='Type accident',
                ),
                AccidentsModel.accident_description,
                VehiclesModel.plate_number.return_variant(
                    raw_name='Immat.véhicule sinistre',
                ),
                AccidentsModel.organization_cost.return_variant(
                    raw_name='Total coût client',
                ),
                AccidentsModel.total_accident_cost.return_variant(
                    raw_name='Total coût du sinistre (cie)',
                ),
                AccidentsModel.insurer.return_variant(
                    raw_name='Nom compagnie sinistre',
                ),
                AccidentsModel.third_party_name,
                AccidentsModel.deductible_level,
                AccidentsModel.insurance_policy_ref,
                AccidentsModel.accident_context.return_variant(
                    raw_name='Libellé nature sinistre',
                ),
            ],
            record_dates=[AccidentsModel.accident_date.name],
            source_table=DominoTables.accidents.value,
        )
        self.load_taxes()

    def load_taxes(
        self,
    ) -> pd.DataFrame:
        taxes_df = self.load_table(
            file_path=os.path.join(
                self.folder,
                'TVTS.xlsx',
            ),
            col_lst=[
                VehiclesModel.plate_number.return_variant(
                    raw_name='Plaque',
                    post_processing=convert_plate,
                ),
                TaxesModel.tax_vehicle_age.return_variant(
                    raw_name='Taxe Ancien',
                ),
                TaxesModel.tax_CO2_emission.return_variant(
                    raw_name='Taxe CO2',
                ),
            ],
            skip_cols=['TVTS'],  # Total of the previous two taxes
            record_dates=[],
            source_table=DominoTables.taxes.value,
        )
        taxes_df['year'] = 2023
        setattr(
            self,
            DominoTables.taxes.value,
            taxes_df,
        )
        return taxes_df

    def import_collaborators_bu(self) -> pd.DataFrame:
        collaborators_df = self.load_table(
            file_path=os.path.join(
                self.folder,
                'Collaborateurs 2024 - V18.04.24.xlsx',
            ),
            col_lst=[
                CollaboratorsModel.organization_employee_id.return_variant(
                    raw_name="Matricule "
                ),
                BusinessUnitsModel.cost_center.return_variant(
                    raw_name="Contrat Société ",
                ),
                BusinessUnitsModel.entity_1.return_variant(
                    raw_name='Société',
                ),
                BusinessUnitsModel.entity_2.return_variant(
                    raw_name='Etablissement',
                ),
                BusinessUnitsModel.entity_3.return_variant(
                    raw_name='AFFECTATION',
                ),
                CollaboratorsModel.employee_address.return_variant(
                    raw_name='Adresse Perm',
                ),
                CollaboratorsModel.work_location.return_variant(
                    raw_name='Adresse DOMINO HR'
                ),
                CollaboratorsModel.employee_role.return_variant(
                    raw_name='Poste'
                ),
            ],
            record_dates=[],
            source_table=DominoTables.collaborators_bu.value,
        )

        setattr(
            self,
            DominoTables.collaborators_bu.value,
            collaborators_df,
        )
        return collaborators_df

    def import_collaborators_entry_exit(self) -> pd.DataFrame:
        collaborators_df = self.load_table(
            file_path=os.path.join(
                self.folder,
                'Collaborateurs 2023 - V18.04.24.xlsx',
            ),
            col_lst=[
                CollaboratorsModel.organization_employee_id.return_variant(
                    raw_name="Matricule "
                ),
                CollaboratorsModel.employee_entry_date,
                CollaboratorsModel.employee_exit_date,
                BusinessUnitsModel.cost_center.return_variant(
                    raw_name='Agence / Analytique',
                ),
                CollaboratorsModel.employee_address.return_variant(
                    raw_name='Adresse perm',
                ),
                CollaboratorsModel.work_location.return_variant(
                    raw_name='Adresse Domino HR',
                ),
            ],
            record_dates=[
                CollaboratorsModel.employee_entry_date.name,
                CollaboratorsModel.employee_exit_date.name,
            ],
            source_table=DominoTables.collaborators_entry_exit.value,
        )
        employee_id_col = CollaboratorsModel.organization_employee_id
        collaborators_df[employee_id_col.name] = (
            collaborators_df[employee_id_col.name].astype(
                employee_id_col.dtype
            )
        )
        orga_cat = CollaboratorsModel.employee_internal_category
        collaborators_df[orga_cat.name] = pd.NA
        collaborators_df[orga_cat.name] = (
            collaborators_df[orga_cat.name].astype(orga_cat.dtype)
        )

        setattr(
            self,
            DominoTables.collaborators_entry_exit.value,
            collaborators_df,
        )
        return collaborators_df

    def import_mileage(self) -> pd.DataFrame:
        """ Import mileage data and set the result as an attribute."""
        mileage_df = self.load_table(
            file_path=os.path.join(
                self.folder,
                'Relevé de compteur_29042024_135550.xlsx',
            ),
            col_lst=[
                VehiclesModel.plate_number.return_variant(
                    raw_name='Véhicule > Immatriculation',
                    post_processing=convert_plate,
                ),
                VehiclesModel.make.return_variant(
                    raw_name='Véhicule > Modèle > Marque > Libellé',
                ),
                VehiclesModel.model.return_variant(
                    raw_name='Véhicule > Modèle > Libellé',
                ),
                MileageReportsModel.mileage_date,
                MileageReportsModel.mileage.return_variant(
                    dtype='float64',
                    raw_name='Compteur',
                ),
            ],
            record_dates=[MileageReportsModel.mileage_date.name],
            source_table=DominoTables.mileage.value,
        )
        mileage_df[MileageReportsModel.mileage.name] = (
            mileage_df[MileageReportsModel.mileage.name].round(0)
        )
        mileage_df[MileageReportsModel.mileage.name] = (
            mileage_df[MileageReportsModel.mileage.name].astype(
                MileageReportsModel.mileage.dtype
            )
        )
        setattr(
            self,
            DominoTables.mileage.value,
            mileage_df,
        )
        return mileage_df


if __name__ == '__main__':
    domino_data = DominoData(
        folder='/home/matthieuglotz/Documents/Data/Domino/DOMINO',
        organization_name='Domino',
    )
    for df in domino_data:
        print(df)
