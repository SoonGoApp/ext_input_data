""" Holson Data

Class loading, normalizing and organizing all Holson Datasets for a given
organization
"""
import os
import typing
from enum import Enum, unique

from data_models import (
    AccidentsModel, VehiclesModel, CollaboratorsModel, BusinessUnitsModel,
    VehicleContractsModel
)
from utils.logging import gen_logger
from utils.dataset import Dataset, add_connector
from utils.type import convert_names
from utils.enums import SynchronizationTypes


@unique
class HolsonTables(Enum):
    accidents = 'ACCIDENTS'


@add_connector
class HolsonData(Dataset):
    SOURCE_CONNECTOR = 'HOLSON'
    NAME = 'HOLSON'
    TYPE = SynchronizationTypes.csv_upload.value

    def __init__(
        self,
        folder: str,
        organization_name: str,
        log_file: typing.Optional[str] = None,
    ) -> None:
        """ Instantiates HolsonData object containing fleet data from Holson

        :param folder: str path to the root folder where all the data is
            stored.
        :param log_file: file where to write logs
        """
        logger = gen_logger(
            name=self.__class__.__name__,
            file_path=log_file,
        )
        super().__init__(
            folder=folder,
            logger=logger,
            source_connector=self.SOURCE_CONNECTOR,
            name=self.NAME,
            type=self.TYPE,
            organization_name=organization_name,
        )
        if not os.path.isdir(os.path.expanduser(folder)):
            self.logger.error(
                'Provided root folder %s is not a valid directory',
                folder,
            )
        self.load_accidents()

    def load_accidents(self):
        accident_df = self.load_table(
            file_path=os.path.join(
                self.folder,
                '2024 02 01 Liste des sinistres QUARTUS.xlsx',
            ),
            col_lst=[
                AccidentsModel.insurance_policy_ref.return_variant(
                    raw_name='PoliceClient',
                ),
                BusinessUnitsModel.organization_id.return_variant(
                    raw_name='codeClient'
                ),
                BusinessUnitsModel.organization_name.return_variant(
                    raw_name='RaisonSociale',
                ),
                VehiclesModel.plate_number,
                AccidentsModel.insurance_policy_version,
                CollaboratorsModel.employee_full_name.return_variant(
                    raw_name='NomConducteur',
                    post_processing=convert_names(self.organization_name),
                ),
                VehiclesModel.full_model.return_variant(
                    raw_name='Modele',
                ),
                VehiclesModel.fiscal_type.return_variant(
                    raw_name='Genre',
                ),
                VehicleContractsModel.contract_type.return_variant(
                  raw_name='Contrat',
                ),
                AccidentsModel.insurer.return_variant(
                    raw_name='Assureur',
                ),
                AccidentsModel.accident_date.return_variant(
                    raw_name='DateSinistre',
                ),
                AccidentsModel.accident_time,
                AccidentsModel.accident_weekday,
                AccidentsModel.accident_ref.return_variant(
                    raw_name='RefSinistre',
                ),
                AccidentsModel.accident_context.return_variant(
                    raw_name='TypeSinistre',
                ),
                AccidentsModel.accident_comment,
                AccidentsModel.is_damages,
                AccidentsModel.is_total_damage,
                AccidentsModel.responsibility.return_variant(
                    raw_name='TauxResponsabilite',
                ),
                AccidentsModel.third_party.return_variant(
                    raw_name='FlagTiers',
                ),
                AccidentsModel.bodily_injury,
                AccidentsModel.third_party_cost,
                AccidentsModel.expert_costs,
                AccidentsModel.damage_costs,
                AccidentsModel.financial_loss,
                AccidentsModel.insurance_deductible_cost.return_variant(
                    raw_name='Franchise',
                ),
                AccidentsModel.insurer_cost.return_variant(
                    raw_name='CoutAssureur'
                ),
                AccidentsModel.accident_status.return_variant(
                    raw_name='Statut',
                ),
                AccidentsModel.repair_provider,
                AccidentsModel.city_provider,
                AccidentsModel.post_code_provider,
                AccidentsModel.is_prefered_provider,
            ],
            skip_cols=['Structure'],
            record_dates=[
                AccidentsModel.accident_date.name,
            ],
            source_table=HolsonTables.accidents.value,
        )
        accident_df[AccidentsModel.total_accident_cost.name] = (
                accident_df[AccidentsModel.third_party_cost.name].fillna(0) +
                accident_df[AccidentsModel.expert_costs.name].fillna(0) +
                accident_df[AccidentsModel.damage_costs.name].fillna(0) +
                accident_df[AccidentsModel.financial_loss.name].fillna(0) +
                accident_df[AccidentsModel.insurance_deductible_cost.name] +
                accident_df[AccidentsModel.insurer_cost.name].fillna(0)
        )

        setattr(
            self,
            HolsonTables.accidents.value,
            accident_df,
        )


if __name__ == '__main__':
    notilus_data = HolsonData(
        folder='/home/matthieuglotz/Documents/Data/Quartus/HOLSON',
        organization_name='Quartus'
    )
    for df in notilus_data:
        print(df)
