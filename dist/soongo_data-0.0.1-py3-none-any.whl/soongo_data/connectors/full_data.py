""" Connectors full data"""
import os
import yaml
from typing import Optional, Union
from functools import cached_property
from uuid import uuid4

import pandas as pd

from utils.dataset import Dataset, connector_dict


# Gotta import every connector for the connector_dict to populate
# TODO: think about a system where this wouldn't be necessary
from connectors.alphabet.full_data import AlphabetData  # NOQA
from connectors.athlon.full_data import AthlonData  # NOQA
from connectors.concur.full_data import ConcurData  # NOQA
from connectors.domino.full_data import DominoData  # NOQA
from connectors.edenred.full_data import EdenredData  # NOQA
from connectors.fleetnote.full_data import FleetNoteData  # NOQA
from connectors.flease.full_data import FleaseData  # NOQA
from connectors.gac.full_data import GacData  # NOQA
from connectors.greenncap.full_data import GreenNCapData  # NOQA
from connectors.havas.full_data import HavasData  # NOQA
from connectors.holson.full_data import HolsonData  # NOQA
from connectors.notilus.full_data import NotilusData  # NOQA
from connectors.quartus.full_data import QuartusData  # NOQA
from connectors.masternaut.full_data import MasternautData  # NOQA


class ConnectorData:
    """ Class collecting data from all different connectors"""

    def __init__(
        self,
        root_folder: str = '/home/matthieuglotz/Documents/Data/',
        organization_name: str = 'Quartus',
        log_file: Optional[str] = None,
        config_file: Optional[str] = None
    ) -> None:
        """ Instantiate Connectors class with all Connectors data

        :param root_folder: path to the folder containing all connectors data
        :param log_file: path to a log file
        """
        self.log_file = log_file
        self.organization_name = organization_name
        if config_file is None:
            config_file = os.path.join(
                os.path.dirname(os.path.realpath(__file__)),
                'connector_config.yaml',
            )
        with open(config_file) as config_path:
            self.connector_param_dict = yaml.safe_load(
                config_path
            )[organization_name]
        self.root_folder = os.path.expanduser(
            os.path.join(root_folder, organization_name)
        )
        if not os.path.isdir(root_folder):
            raise ValueError(
                f'The provided root folder {root_folder} does not exist'
            )

        # Lazy memoization: first set attributes names as None, fetch actual
        # object only if required by a get call.
        for connector in self.connector_param_dict:
            setattr(
                self,
                connector,
                None
            )

    def get(
        self,
        connector_name: str,
        dataset_name: Optional[str] = None,
        table_name: Optional[str] = None,
    ) -> Union[Dataset, pd.DataFrame]:
        """ Get requested Dataset or table

        :param connector_name: name of the connector the data needs to be
        fetched from.
        :param dataset_name: name of the dataset the data needs to be fetched
        from.
        :param table_name: name of the table the data needs to be fetched from.

        :raises ValueError: if any of the passed connector, dataset, or table
        name does not exist.

        :returns: Connector, Dataset, or table, depending on whether only
        a connector name, connector and dataset name, or connector, dataset,
        and table_name were passed.
        """
        if connector_name not in self.connector_param_dict:
            raise ValueError(
                f'Passed {connector_name} value is not a valid connector name'
            )

        connector = getattr(
            self,
            connector_name,
        )
        # Lazy memoization: do not load connector data at init, only if
        # fetching data for that connector
        if connector is None:
            connector = connector_dict[connector_name](
                folder=os.path.join(self.root_folder, connector_name),
                log_file=self.log_file,
                organization_name=self.organization_name,
                **self.connector_param_dict[connector_name],
            )
            setattr(
                self,
                connector_name,
                connector,
            )

        if dataset_name is None and table_name is None:
            return connector

        if isinstance(connector, Dataset):
            if table_name is None:
                return connector

            try:
                return getattr(
                    connector,
                    table_name,
                )
            except AttributeError:
                raise ValueError(
                    f'Passed table_name {table_name} does not exist in '
                    f'connector {connector_name}'
                )

        if dataset_name is None:
            raise ValueError(
                'Cannot pass no dataset_name - queried connector '
                f'{connector_name} contains multiple datasets'
            )

        try:
            dataset = getattr(connector, dataset_name)
        except AttributeError:
            raise ValueError(
                f'Passed dataset name {dataset_name} does not exist in '
                f'connector {connector_name}'
            )
        assert isinstance(dataset, Dataset)
        if table_name is None:
            return dataset

        try:
            return getattr(dataset, table_name)
        except AttributeError:
            raise ValueError(
                f'Passed table name {table_name} does not exist in '
                f'dataset {dataset_name} of connector {connector_name}'
            )

    def __iter__(self):
        for source in self.connector_param_dict:
            yield self.get(source)

    @cached_property
    def synchronisation_id_dict(self):
        return {
            connector_name: str(uuid4())
            for connector_name in self.connector_param_dict.keys()
        }


if __name__ == '__main__':
    connector_data = ConnectorData(
        root_folder='/home/matthieuglotz/Documents/Data/',
        organization_name='Domino',
    )
    for source in connector_data:
        for element in source:
            if isinstance(element, Dataset):
                for df in element:
                    print(df)

            else:
                print(element)
