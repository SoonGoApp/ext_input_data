""" Table script utility functions"""
from abc import abstractmethod, ABC
import os
import logging
import re
import typing
import yaml
from typing import Callable, Union, Optional, Set, List, Tuple, Self, Dict, Any
from enum import Enum
from dataclasses import dataclass, asdict
from uuid import UUID

import pandas as pd
from sqlalchemy.ext.declarative import DeclarativeMeta
from sqlalchemy.orm.session import Session

from data_models.base import DataColumn
from data_models import (
    CollaboratorsModel, BusinessUnitsModel, SoonGoRecordsModel, VehiclesModel
)
from connectors.full_data import ConnectorData
from utils.type import (
    str_is_nan, series_is_nan, clean_accent, convert_string, gen_name_set,
    get_dtype_null
)
from utils.dataset import Dataset, check_no_dup_values
from utils.uploads import (
    fetch_collaborator_ids, fetch_vehicle_ids, upsert_business_unit,
    upsert_car_trim, upsert_region, upsert_synchronisation
)


@dataclass
class InputColumn(DataColumn):

    format: Optional[re.Pattern] = None
    foreign_relationship: Tuple[str, str] = tuple()
    unique: bool = False
    nullable: bool = True
    enum: Optional[Enum] = None
    default: Any = None
    is_id: bool = False  # Whether the column should be taken into account in deduplication during insertion

    @staticmethod
    def from_data_column(
        column: DataColumn,
        **input_col_kwargs,
    ) -> Self:
        """ Generate an InputColumn object from a Data Column

        :param column: a DataColumn instance
        **input_col_kwargs: a foreign_relationship, unique, or nullable value
        """
        return InputColumn(
            **asdict(column),
            **input_col_kwargs,
        )

    def __hash__(self):
        return hash(self.name)

    def __eq__(self, other):
        if isinstance(other, InputColumn):
            return self.name == other.name
        else:
            return False


class InputTable(ABC):

    def __init__(
        self,
        name: str,
        sql_mapping: DeclarativeMeta,
        columns: List[InputColumn],
        date_col_name: typing.Optional[str] = None,
    ) -> None:
        self.name = name
        self.columns = columns
        self.sql_mapping = sql_mapping
        self.date_col_name = date_col_name

    @abstractmethod
    def get(
        self: typing.Self,
        connector_data: ConnectorData,
        logger: logging.Logger,
        fetch_params_dict: typing.Optional[dict] = None,
    ) -> pd.DataFrame:
        raise NotImplementedError('Abstract get method must be implemented')

    def to_sql(
        self: typing.Self,
        data_df: pd.DataFrame,
        organization_id: UUID,
        session: Session,
        logger: logging.Logger,
    ) -> pd.DataFrame:
        """ Inserts the passed data_df to the input_table db table mapping

        :param data_df: a dataframe containing the data to be uploaded to SQL
        :param organization_id: a db valid organization uuid
        :param session: a SQLAlchemy session
        :param logger: logging.Logger
        """
        if not organization_id:
            raise ValueError(
                'The argument organization_id cannot be null'
            )
        data_df[SoonGoRecordsModel.organization_id.name] = organization_id

        if VehiclesModel.plate_number.name in data_df:

            if VehiclesModel.vehicle_id.name not in data_df:
                data_df = fetch_vehicle_ids(
                    vehicle_df=data_df,
                    organization_id=organization_id,
                    engine=session.get_bind(),
                )
            data_df.drop(VehiclesModel.plate_number.name, axis=1, inplace=True)

        if CollaboratorsModel.employee_id.name in data_df:

            if CollaboratorsModel.collaborator_id.name not in data_df:
                data_df = fetch_collaborator_ids(
                    vehicle_df=data_df,
                    organization_id=organization_id,
                    engine=session.get_bind(),
                )
            data_df.drop(
                CollaboratorsModel.employee_id.name,
                axis=1,
                inplace=True,
            )
        inserts = data_df.to_dict(orient='records')

        logger.info(
            'Inserting %d rows in the %s table',
            len(data_df),
            self.sql_mapping.__tablename__,
        )
        for insert_dict in inserts:

            insert_dict[SoonGoRecordsModel.synchronisation_id.name] = upsert_synchronisation(
                session=session,
                synchronisation_id=insert_dict[SoonGoRecordsModel.synchronisation_id.name],
                connector_name=insert_dict[SoonGoRecordsModel.source_connector.name],
                synchronisation_type=insert_dict[SoonGoRecordsModel.synchronisation_type.name],
                organization_id=organization_id
            )
            insert_dict.pop(SoonGoRecordsModel.source_connector.name)
            insert_dict.pop(SoonGoRecordsModel.synchronisation_type.name)

            if BusinessUnitsModel.business_unit.name in insert_dict:
                insert_dict['business_unit_id'] = upsert_business_unit(
                    session=session,
                    business_units=insert_dict['business_unit'].split(' > '),
                    synchronisation_id=insert_dict[SoonGoRecordsModel.synchronisation_id.name],
                    connector_name=insert_dict[SoonGoRecordsModel.source_connector.name],
                    synchronisation_type=insert_dict[SoonGoRecordsModel.synchronisation_type.name],
                    organization_id=organization_id
                )
                insert_dict.pop('business_unit')

            if BusinessUnitsModel.geography.name in insert_dict:
                insert_dict['region_id'] = upsert_region(
                    session=session,
                    regions=insert_dict['geography'].split(' > '),
                    synchronisation_id=insert_dict[SoonGoRecordsModel.synchronisation_id.name],
                    connector_name=insert_dict[SoonGoRecordsModel.source_connector.name],
                    synchronisation_type=insert_dict[SoonGoRecordsModel.synchronisation_type.name],
                    organization_id=organization_id
                )
                insert_dict.pop('geography')

            model_vars = {
                VehiclesModel.make.name,
                VehiclesModel.model.name,
                VehiclesModel.full_model.name,
            }
            if model_vars.intersection(insert_dict.keys()):
                constructor_id, brand_id, model_id, trim_id = upsert_car_trim(
                    session=session,
                    constructor_name=insert_dict.get('constructor_name'),
                    brand_name=insert_dict.get(
                        VehiclesModel.make.name,
                    ),
                    model_name=insert_dict.get(
                        VehiclesModel.model.name,
                    ),
                    trim_name=insert_dict.get(
                        VehiclesModel.full_model.name,
                    ),
                    synchronisation_id=insert_dict[SoonGoRecordsModel.synchronisation_id.name],
                    connector_name=insert_dict[SoonGoRecordsModel.source_connector.name],
                    synchronisation_type=insert_dict[SoonGoRecordsModel.synchronisation_type.name],
                    organization_id=organization_id,
                )

                for model_var in model_vars:
                    insert_dict.pop(model_var)
                insert_dict['constructor_id'] = constructor_id
                insert_dict['brand_id'] = brand_id
                insert_dict['model_id'] = model_id
                insert_dict['trim_id'] = trim_id

            new_row = self.sql_mapping(
                **insert_dict
            )
            session.add(new_row)
            session.commit()

        logger.info(
            'Insertion complete.',
        )

    def check_columns(
        self,
        data_df: pd.DataFrame,
        logger: logging.Logger,
        **source_tables,
    ):
        """ Check the DataFrame columns based on the InputColumn instances

        :param data_df: the dataframe of data to check
        :param logger: logger
        **source_tables: table_name as argument name and dataframe as argument
        value for all source tables

        :raises ValueError: if any column is missing, does not match
            expected type, nullability, format, unicity, or foreign constraint
        """
        if len(self.columns) != len(data_df.columns):
            missing_columns = set(self.columns).difference(data_df.columns)
            extra_columns = set(data_df.columns).difference(self.columns)
            raise ValueError(
                f'There are {len(missing_columns)} in the dataframe: '
                f'{missing_columns} and {len(extra_columns)} unexpected '
                f'columns: {extra_columns}'
            )

        check_no_dup_values(data_df.columns)

        for column in self.columns:

            if column.name not in data_df:
                raise ValueError(
                    f"Column '{column.name}' not found in the CSV file."
                )

            # Define null values
            col_series = data_df[column.name]
            if (
                (
                    pd.api.types.is_integer_dtype(col_series.dtype) !=
                    pd.api.types.is_integer_dtype(column.dtype)
                ) |
                (
                    pd.api.types.is_string_dtype(col_series.dtype) !=
                    pd.api.types.is_string_dtype(column.dtype)
                ) |
                (
                    pd.api.types.is_float_dtype(col_series.dtype) !=
                    pd.api.types.is_float_dtype(column.dtype)
                ) |
                (
                    pd.api.types.is_bool_dtype(col_series.dtype) !=
                    pd.api.types.is_bool_dtype(column.dtype)
                ) |
                (
                    pd.api.types.is_datetime64_any_dtype(col_series.dtype) !=
                    pd.api.types.is_datetime64_any_dtype(column.dtype)
                )
            ):
                raise ValueError(
                    f"Column '{column.name}' has the wrong data type. "
                    f'Expected: {column.dtype}, '
                    f'Got: {col_series.dtype}.'
                )

            null_values = series_is_nan(col_series)
            if column.nullable:
                if null_values.all():
                    logger.error(
                        'Column %s is entirely composed of null values',
                        column.name,
                    )
            elif null_values.any():
                raise ValueError(
                    f"Column {column.name} contains {null_values.sum()} null"
                    f' values whilst column is not nullable'
                )

            if column.format:
                format_not_ok = col_series.loc[
                    ~str_is_nan(col_series.astype(str))
                    & ~col_series.astype(str).str.match(column.format)
                ]
                if len(format_not_ok):
                    raise ValueError(
                        f"Column '{column.name}' contains "
                        f'{len(format_not_ok)} values that do not match '
                        f'the format: {column.format} '
                        f'for example: {format_not_ok.head(5)}'
                    )

            if column.unique and not col_series.loc[
                ~null_values
            ].is_unique:
                raise ValueError(
                    f"Column '{column.name}' contains duplicate values.: "
                    f'{col_series.loc[col_series.duplicated()].unique()}'
                )

            if column.foreign_relationship:
                self.check_foreign_relationship(
                    column_series=col_series,
                    column_definition=column,
                    source_tables=source_tables,
                )

            if column.enum:
                self.check_allowed_values(
                    allowed_values={member.value for member in column.enum},
                    col_to_check=col_series,
                )

        logger.info('Table %s matches all its requirements.', self.name)

    @classmethod
    def check_foreign_relationship(
        cls,
        column_series: pd.Series,
        column_definition: InputColumn,
        source_tables: Dict[str, pd.DataFrame],
    ):
        """ Check foreign relationship between the source tables and
        the current table.

        :param column_series: data column values as a pandas Series
        :param column_definition: DataColumn object
        :param source_tables: dictionary of table names to df

        :raise KeyError: if foreign table name not in source tables
        :raise ValueError: if unmatched values in column_series
        """
        if column_definition.foreign_relationship is None:
            return
        table_name, column_name = column_definition.foreign_relationship
        if table_name not in source_tables:
            raise KeyError(
                f'Table "{table_name}" was not provided in source tables:'
                f' {source_tables.keys()}'
            )
        source_values = set(source_tables[table_name][column_name].unique())
        cls.check_allowed_values(
            allowed_values=source_values,
            col_to_check=column_series,
        )

    @staticmethod
    def check_allowed_values(
        allowed_values: set,
        col_to_check: pd.Series,
    ) -> None:
        """ Check allowed values in a pandas Series

        :param allowed_values: set of values allowed in the Series
        :param col_to_check: Series whose value to check

        :raises ValueError: if the Series contains non null values not in
            allowed values
        """
        # TODO: clean fillnas, ignore null values for now
        unmatched_values = set(
            col_to_check.loc[~series_is_nan(col_to_check)].unique()
        ).difference(allowed_values)
        if unmatched_values:
            raise ValueError(
                f'There are {len(unmatched_values)} unmatched value in column'
                f' "{col_to_check.name}": {unmatched_values}'
            )

    def return_column_names(self) -> List[str]:
        return [col.name for col in self.columns]

    def fetch_table_data(
        self: typing.Self,
        connector_data: ConnectorData,
        logger: logging.Logger,
        fetch_params_dict: typing.Optional[dict] = None,
    ) -> pd.DataFrame:
        """ Fetch the data necessary for the table, according to each organization
        configuration.

        :param connector_data: ConnectorData object with all the organization data
        :param logger: logger
        :param organization_name: name of the organization
        :param table: InputTable being built

        :returns: combined df with all required data
        """
        if not fetch_params_dict:
            fetch_params_dict = fetch_organization_params(
                connector_data.organization_name,
            )[self.name]['fetch_table_params']
        try:
            return combine_connector_data(
                connector_data=connector_data,
                logger=logger,
                **fetch_params_dict,
            )
        except NoMatchedTable:
            logger.error(
                f'No {self.name} data, returning an empty DataFrame'
            )
            return pd.DataFrame(
                {
                    column.name: pd.Series(dtype=column.dtype)
                    for column in self.columns
                }
            )

    def fill_missing_cols(self: typing.Self, df: pd.DataFrame) -> pd.DataFrame:
        """ Fill in missing columns in a Dataframe to produce a given table

        :param df: pd.Dataframe to fill in
        :param table: InputTable to match
        """
        for col in self.columns:
            if col.name not in df.columns:
                if col.nullable is False:
                    raise ValueError(
                        f'Column {col.name} is missing from Dataframe whilst'
                        f' it is not nullable'
                    )

                df[col.name] = get_dtype_null(col.dtype)
                df[col.name] = df[col.name].astype(col.dtype)

            if col.default is not None:
                df[col.name] = df[col.name].fillna(
                    col.default,
                )

        return df


class NoMatchedTable(Exception):

    def __init__(self, message: str):
        super().__init__(message)


def get_business_units(
    df: pd.DataFrame,
    logger: logging.Logger,
    organization_name: str,
):
    """ Get Business units.

    :param df: pandas DataFrame containing entity data to be aggregated as a
    business unit
    :param logger: logger
    :param organization_name: organization_èname

    :returns: df with no entity columns left but a bu column, if the entities
    where available
    """
    entity_lst = [
        BusinessUnitsModel.entity_1.name,
        BusinessUnitsModel.entity_2.name,
        BusinessUnitsModel.entity_3.name,
    ]
    available_entity = set(entity_lst).intersection(df.columns)
    if available_entity != set(entity_lst):
        logger.warning(
            'Lacking entities; expected %s but only %s available',
            entity_lst,
            available_entity,
        )
        df[BusinessUnitsModel.business_unit.name] = ''
        return df.drop(
            available_entity,
            axis=1
        )
    concatenated_strings = pd.Series()
    non_missing = (
        ~str_is_nan(df[BusinessUnitsModel.entity_1.name]) &
        ~str_is_nan(df[BusinessUnitsModel.entity_2.name]) &
        ~str_is_nan(df[BusinessUnitsModel.entity_3.name])
    )

    for entity_col in entity_lst:

        if concatenated_strings.empty:
            concatenated_strings = df[entity_col].where(
                non_missing,
                '',
            )

        else:
            concatenated_strings = concatenated_strings.where(
                ~non_missing,
                concatenated_strings + ' > ' + df[entity_col],
            )

    df[BusinessUnitsModel.business_unit.name] = concatenated_strings
    if organization_name == 'Quartus':
        if SoonGoRecordsModel.source_connector.name in df.columns:
            df[BusinessUnitsModel.business_unit.name] = (
                df[BusinessUnitsModel.business_unit.name].where(
                    df[SoonGoRecordsModel.source_connector.name] == "QUARTUS",
                    "",
                )
            )
        else:
            df[BusinessUnitsModel.business_unit.name] = ""
    return df.drop(
        entity_lst,
        axis=1,
    )


def match_soongo_employee_id(
    table_to_match: pd.DataFrame,
    employee_table: pd.DataFrame,
) -> pd.DataFrame:
    """ Add the SoonGo employee id to the table to match.

    :param table_to_match: table to add the SoonGo employee_id to
    :param employee_table: employee_table
    """
    if CollaboratorsModel.employee_id.name not in table_to_match.columns:
        table_to_match[CollaboratorsModel.employee_id.name] = ''

    # First match based on customer employee id
    if (
        CollaboratorsModel.organization_employee_id.name
        in table_to_match.columns
    ):
        subset = employee_table.loc[
            ~series_is_nan(
                employee_table[
                    CollaboratorsModel.organization_employee_id.name
                ]
            ),
            [
                CollaboratorsModel.organization_employee_id.name,
                CollaboratorsModel.employee_id.name,
            ],
        ]
        subset = subset.rename(
            columns={
                CollaboratorsModel.employee_id.name: 'employee_id_temp'
            },
        )
        table_to_match = table_to_match.merge(
            right=subset,
            on=CollaboratorsModel.organization_employee_id.name,
            how='left',
            validate='m:1',
        )
        table_to_match[CollaboratorsModel.employee_id.name] = (
            table_to_match['employee_id_temp']
        )
        table_to_match.drop(columns='employee_id_temp', inplace=True)

    # Then match based on name - match alternative names to ids
    table_to_match = gen_soongo_emp_id(df=table_to_match)
    assert CollaboratorsModel.employee_id.name in table_to_match.columns
    alt_name_df = employee_table[
        [
            CollaboratorsModel.employee_id.name,
            CollaboratorsModel.alternative_names.name]
    ]
    alt_name_df[CollaboratorsModel.alternative_names.name] = (
        alt_name_df[CollaboratorsModel.alternative_names.name].str.split(
            pat=', ',
            expand=False,
        )
    )
    alt_name_df = alt_name_df.explode(
        CollaboratorsModel.alternative_names.name
    )
    alt_name_df.rename(
        columns={CollaboratorsModel.employee_id.name: 'temp_name'},
        inplace=True,
    )
    table_to_match = pd.merge(
        left=table_to_match,
        right=alt_name_df,
        left_on=CollaboratorsModel.employee_id.name,
        right_on=CollaboratorsModel.alternative_names.name,
        how='left',
        validate='m:1',
        indicator=True,
    )

    not_found = (
        (table_to_match._merge != 'both') &
        ~str_is_nan(table_to_match[CollaboratorsModel.employee_id.name])
    )
    if not_found.any():
        raise ValueError(
            'Some names were not found in the data: ' +
            table_to_match.loc[not_found, CollaboratorsModel.alternative_names.name]
        )
    table_to_match[CollaboratorsModel.employee_id.name] = table_to_match['temp_name']
    table_to_match.drop(['temp_name', '_merge'], axis=1, inplace=True)

    table_to_match[CollaboratorsModel.employee_id.name] = (
        table_to_match[CollaboratorsModel.employee_id.name].astype('string')
    )

    return table_to_match


def keep_duplicates(
    duplicated_df: pd.DataFrame,
    unique_cols: List[str],
    selection_col: str,
    logger: logging.Logger,
    selection_func: Union[Callable, str] = 'max',
) -> pd.DataFrame:
    """ Select duplicated values based on a selectin col and selection func

    :param duplicated_df: DataFrame to drop duplicates from
    :param unique_cols: list of column names to identify duplicates with
    :param selection_col: name of the column whose value to use to drop
        duplicates
    :param selection_func: callable to pass selection col to obtain values
        to keep

    :return: dataframe having dropped duplicated based on selection col and
        func
    """
    start_rows = len(duplicated_df)
    start_cols = set(duplicated_df[unique_cols])
    is_na_series = series_is_nan(duplicated_df[selection_col])

    selection_values = duplicated_df.groupby(
        unique_cols
    )[selection_col].transform(selection_func)
    duplicated_df = duplicated_df.loc[
        (duplicated_df[selection_col] == selection_values) | is_na_series,
    ]
    logger.info(
        'Dropped %d duplicated rows using %s; %d duplicates remaining',
        len(duplicated_df) - start_rows,
        selection_col,
        duplicated_df[unique_cols].duplicated().sum(),
    )
    if start_cols != set(duplicated_df[unique_cols]):
        raise ValueError(
            'Some cols were lost during deduplication process: '
            f'{start_cols.difference(duplicated_df)}',
        )
    return duplicated_df


def gen_soongo_emp_id(df: pd.DataFrame) -> pd.DataFrame:
    base_cols = {
        CollaboratorsModel.employee_full_name.name,
        CollaboratorsModel.employee_first_name.name,
        CollaboratorsModel.employee_last_name.name,
    }
    name_cols = base_cols.intersection(df.columns)

    if not name_cols:
        if CollaboratorsModel.employee_id.name not in df.columns:
            df[CollaboratorsModel.employee_id.name] = ''
        return df

    if name_cols == base_cols:
        df[CollaboratorsModel.employee_id.name] = (
            df[CollaboratorsModel.employee_full_name.name].where(
                ~str_is_nan(df[CollaboratorsModel.employee_full_name.name]),
                (
                    df[CollaboratorsModel.employee_first_name.name] +
                    ' ' +
                    df[CollaboratorsModel.employee_last_name.name]
                ),
            )
        )
    elif CollaboratorsModel.employee_full_name.name in name_cols:
        df[CollaboratorsModel.employee_id.name] = (
            df[CollaboratorsModel.employee_full_name.name]
        )

    else:
        df[CollaboratorsModel.employee_id.name] = (
            df[CollaboratorsModel.employee_first_name.name] +
            ' ' +
            df[CollaboratorsModel.employee_last_name.name]
        )

    df[CollaboratorsModel.employee_id.name] = (
        clean_accent(df[CollaboratorsModel.employee_id.name]).str.strip().str.lower()
    )
    df[CollaboratorsModel.employee_id.name] = (
        df[CollaboratorsModel.employee_id.name].apply(gen_name_set)
    )
    df[CollaboratorsModel.employee_id.name] = convert_string(
        df[CollaboratorsModel.employee_id.name]
    )
    return df


def regroup_dataframe(
    raw_df: pd.DataFrame,
    groupby_col: str,
    logger: logging.Logger,
    ignore_cols: List[str] = [],
) -> pd.DataFrame:
    """ Regroup different rows of the DataFrame in a single row.

    :param raw_df: DataFrame to regroup
    :param groupby_col: column name to regroup on
    :param ignore_cols: columns to ignore when deduplicating
    """
    grouped_cols = [col for col in raw_df.columns if col != groupby_col]

    # Forward fill within group
    ffil_cols = raw_df.groupby(groupby_col)[grouped_cols].ffill()
    raw_df[grouped_cols] = raw_df[grouped_cols].where(
        pd.notna(raw_df[grouped_cols]).all(axis=1) |
        pd.isna(raw_df[grouped_cols]).any(axis=1),
        ffil_cols,
    )

    # Backfil within group
    bfil_cols = raw_df.groupby(groupby_col)[grouped_cols].bfill()
    raw_df[grouped_cols] = raw_df[grouped_cols].where(
        pd.notna(raw_df[grouped_cols]).all(axis=1) |
        pd.isna(raw_df[grouped_cols]).any(axis=1),
        bfil_cols,
    )

    # Drop duplicates
    original_rows = len(raw_df)
    duplicated_entries = raw_df[groupby_col].duplicated().sum()

    new_df = raw_df.drop_duplicates(
        subset=[col for col in raw_df if col not in ignore_cols]
    )
    logger.info(
        'Regrouping using col %s resulting in dropping %d rows '
        'from %d duplicated entries',
        groupby_col,
        original_rows - len(new_df),
        duplicated_entries,
    )
    return new_df


def fetch_organization_params(organization_name: str) -> dict:
    """ Fetch organization params for input tables

    :param organization_name: name of the organization
    """
    with open(
        os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            'input_table_config.yaml',
        )
    ) as config_file:
        return yaml.safe_load(config_file)[organization_name]


def combine_connector_data(
    connector_data: ConnectorData,
    logger: logging.Logger,
    exclude_tables: Optional[Set[Tuple[str, str, str]]] = None,
    include_tables: Optional[Set[Tuple[str, str, str]]] = None,
    disjunctive_cols: Optional[List[Set[str]]] = None,
    conjunctive_cols: Optional[List[Set[str]]] = None,
):
    """ Collects all employee names, id, or other employee relevant columns
    across all connectors datasets.

    :param connector_data: an instanciated ConnectorData object
    :param logger: logger
    :param exclude_tables: Set of tables to exclude. Each table is
        identified by a tuple of string with its source connector, source
        dataset, and table name. If not specified, exclude None. If '*' is
        specified  asctable name, all tables from this source/dataset are
        excluded, if '*' is specified as dataset name, all datasets from that
        connector are excluded. exclude_tables supersedes include_tables -
        tables excluded in this arg will be excluded even if specified in
        include_tables.
    :param include_table: Set of tables to include. Each table is
        identified by a tuple of string with its source connector, source
        dataset, and table name. If not specified, include all. If '*' is
        specified  as table name, all tables from this source/dataset are
        included, if '*' is specified as dataset name, all datasets from that
        connector are included. exclude_tables supersedes include_tables -
        tables excluded in this arg will be excluded even if specified in
        include_tables.
    :param disjunctive_cols: List of sets of column names as string. For the
        dataset to be returned, at least one column must be available in each
        set.
    :param conjunctive_cols: List of sets of column names as string. These
        columns are not necessary to return the dataset, but all columns in
        the set must be available for them to be added to the dataset.

    :raises NoMatchedTable: if no Table is matched

    :return: a pandas DataFrame
    """
    df_lst = []
    exclude_tables = (
        {tuple(table_list) for table_list in exclude_tables}
        if exclude_tables else set()
    )
    include_tables = (
        {tuple(table_list) for table_list in include_tables}
        if include_tables else set()
    )

    if not include_tables:
        for source in connector_data:
            for element in source:
                if isinstance(element, pd.DataFrame):
                    if element.empty:
                        continue
                    if get_sources_from_df(element) in exclude_tables:
                        continue
                    subset_df = subset_cols(
                        df=element,
                        disjunctive_cols=disjunctive_cols,
                        conjunctive_cols=conjunctive_cols,
                    )
                    if subset_df is not None:
                        df_lst.append(subset_df)

                else:
                    assert isinstance(element, Dataset)
                    for df in element:
                        assert isinstance(df, pd.DataFrame)
                        if df.empty:
                            continue
                        if get_sources_from_df(df) in exclude_tables:
                            continue
                        subset_df = subset_cols(
                            df=df,
                            disjunctive_cols=disjunctive_cols,
                            conjunctive_cols=conjunctive_cols,
                        )
                        if subset_df is not None:
                            df_lst.append(subset_df)

    else:
        for table_tup in include_tables:
            if table_tup in exclude_tables:
                continue
            connector, dataset, table = table_tup
            element = connector_data.get(
                connector_name=connector,
                dataset_name=dataset if dataset != '*' else None,
                table_name=table if table != '*' else None,
            )
            if isinstance(element, pd.DataFrame):
                subset_df = subset_cols(
                    df=element,
                    disjunctive_cols=disjunctive_cols,
                    conjunctive_cols=conjunctive_cols,
                )
                if subset_df is not None:
                    df_lst.append(subset_df)
            elif isinstance(element, Dataset):
                for df in element:
                    assert isinstance(df, pd.DataFrame)
                    subset_df = subset_cols(
                        df=df,
                        disjunctive_cols=disjunctive_cols,
                        conjunctive_cols=conjunctive_cols,
                    )
                    if subset_df is not None:
                        df_lst.append(subset_df)
            else:
                for dataset in element:
                    assert isinstance(dataset, Dataset)
                    for df in dataset:
                        assert isinstance(df, pd.DataFrame)
                        subset_df = subset_cols(
                            df=df,
                            disjunctive_cols=disjunctive_cols,
                            conjunctive_cols=conjunctive_cols,
                        )
                        if subset_df is not None:
                            df_lst.append(subset_df)

    if df_lst == []:
        raise NoMatchedTable(
            'No dataframe contained any columns of interest across all'
            'connectors.'
        )

    combined_df = pd.concat(df_lst, axis=0, ignore_index=True)
    logger.info(
        'Collected %d entries from %d datasets',
        len(combined_df),
        len(df_lst),
    )
    return combined_df


def subset_cols(
    df: pd.DataFrame,
    disjunctive_cols: Optional[List[Set[str]]] = None,
    conjunctive_cols: Optional[List[Set[str]]] = None,
) -> Optional[pd.DataFrame]:
    """ Subset df to return dataframe with columns of interest if any

    :param df: pandas Dataframe possibly containing employees information
    :param disjunctive_cols: List of sets of column names as string. For the
    dataset to be returned, at least one column must be available in each set.
    :param conjunctive_cols: List of sets of column names as string. These
    columns are not necessary to return the dataset, but all columns in the set
    must be available for them to be added to the dataset.

    :return: dataframe with employee relevant cols, or None if None
    """
    # Handle args. If no column criterion specified then then take all
    if disjunctive_cols is None and conjunctive_cols is None:
        conjunctive_cols = [
            {col} for col in df.columns
        ]
        disjunctive_cols = []
    elif disjunctive_cols is None:
        disjunctive_cols = []  # Cannot set [] by default because it is mutable
    elif conjunctive_cols is None:
        conjunctive_cols = []
    required_cols = set()

    # Handle disjunctive cols - return None if at least one col available in
    # each disjunctive set.
    for disjunctive_set in disjunctive_cols:
        col_set = set(disjunctive_set).intersection(df.columns)
        if not col_set:
            return
        required_cols = required_cols.union(disjunctive_set)

    # Handle conjunctive cols - adds them if all col in the set available
    cols_to_add = set()
    for conjunctive_set in conjunctive_cols:
        if set(conjunctive_set).issubset(df.columns):
            cols_to_add = cols_to_add.union(conjunctive_set)
    cols_to_add = required_cols.union(cols_to_add)

    if cols_to_add:  # If not (no disjunctive cols and no match in conjunctive)
        return df[list(cols_to_add.intersection(df.columns))]


def get_sources_from_df(df: pd.DataFrame) -> Tuple[str, str, str]:
    """ Return the source connector, dataset, and table of a dataframe."""
    if not {
        SoonGoRecordsModel.source_connector.name,
        SoonGoRecordsModel.source_dataset.name,
        SoonGoRecordsModel.source_dataset.name,
    }.issubset(df.columns):
        raise ValueError(
            f'The df does not have the required source columns to evaluate'
            f'its sources: {df.columns}'
        )

    source_connector = df[SoonGoRecordsModel.source_connector.name].unique()
    if len(source_connector) != 1:
        raise ValueError(
            f'No single source_connector value: {source_connector}'
        )
    source_connector = source_connector[0]

    source_dataset = df[SoonGoRecordsModel.source_dataset.name].unique()
    if len(source_dataset) != 1:
        raise ValueError(
            f'No single source_dataset value: {source_dataset}'
        )
    source_dataset = source_dataset[0]

    source_table = df[SoonGoRecordsModel.source_table.name].unique()
    if len(source_table) != 1:
        raise ValueError(
            f'No single source_table value: {source_table}'
        )
    source_table = source_table[0]

    return source_connector, source_dataset, source_table


def add_synchronization_id(
    df: pd.DataFrame,
    connector_data: ConnectorData,
) -> pd.DataFrame:
    """ Add the synchronization id and type using the synchronisation_id_dict
    property of ConnectorData. Synchronization_type is by default csv_upload

    :param df: df to add synchronization id and type to
    :param connector_data: connector_data the df was generated from
    :param synchronization_type: type of the synchronisation, by default CSV_UPLOAD

    :raises ValueError: if the df does not contain a column connector_name

    :returns: df with two added columns
    """
    if SoonGoRecordsModel.source_connector.name not in df.columns:
        raise ValueError(
            'A connector_name column is necessary to map synchronization_id'
        )

    missing_connectors = set(
        df[SoonGoRecordsModel.source_connector.name].unique()
    ).difference(
        connector_data.synchronisation_id_dict.keys()
    )
    if missing_connectors:
        raise ValueError(
            f'Provided connector dict keys {connector_data.synchronisation_id_dict.keys()}'
            f'do not cover the following connector_names: {missing_connectors}'
        )

    df[SoonGoRecordsModel.synchronisation_id.name] = (
        df[SoonGoRecordsModel.source_connector.name].map(
            connector_data.synchronisation_id_dict,
        )
    )
    assert not str_is_nan(df[SoonGoRecordsModel.synchronisation_id.name]).any()

    return df
