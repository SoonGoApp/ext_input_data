""" Script to calculate the incident table to load in database."""
import logging
import os
import typing

import pandas as pd

from connectors.full_data import ConnectorData
from data_models import (
    TrainPlaneTravelModel, CollaboratorsModel, SoonGoRecordsModel
)
from input_tables.employees_table import EmployeesInputTable
from input_tables.expense_utils import infer_amounts_and_tax
from input_tables.table_utils import (
    InputColumn, InputTable, match_soongo_employee_id, add_synchronization_id
)
from utils.logging import gen_logger
from utils.enums import TravelTypes, CabinClassTypes, TicketTypes
from sql_mappings import TrainsPlanesTable


class TravelInputTable(InputTable):

    def __init__(self: typing.Self):
        super().__init__(
            name='train_planes',
            sql_mapping=TrainsPlanesTable,
            date_col_name='billing_date',
            columns=[
                InputColumn.from_data_column(
                    column=TrainPlaneTravelModel.expense_id,
                ),
                InputColumn.from_data_column(
                    column=TrainPlaneTravelModel.leg_id,
                    unique=True,
                    is_id=True,
                ),
                InputColumn.from_data_column(
                    column=TrainPlaneTravelModel.travel_type,
                    nullable=False,
                ),
                InputColumn.from_data_column(
                    column=TrainPlaneTravelModel.booking_date,
                    nullable=False,
                    is_id=True,
                ),
                InputColumn.from_data_column(
                    column=TrainPlaneTravelModel.billing_date,
                ),
                InputColumn.from_data_column(
                    column=CollaboratorsModel.employee_id,
                    foreign_relationship=(
                        EmployeesInputTable().name,
                        CollaboratorsModel.employee_id.name,
                    ),
                    is_id=True,
                ),
                InputColumn.from_data_column(
                    column=TrainPlaneTravelModel.amount_tax_exc,
                    is_id=True,
                ),
                InputColumn.from_data_column(
                    column=TrainPlaneTravelModel.deductible_vat,
                ),
                InputColumn.from_data_column(
                    column=TrainPlaneTravelModel.net_amount,
                ),
                InputColumn.from_data_column(
                    column=TrainPlaneTravelModel.airport_tax,
                ),
                InputColumn.from_data_column(
                    column=TrainPlaneTravelModel.ticket_type,
                    default=TicketTypes.unknown.value,
                ),
                InputColumn.from_data_column(
                    column=TrainPlaneTravelModel.leg_number,
                ),
                InputColumn.from_data_column(
                    column=TrainPlaneTravelModel.start_location_code,
                ),
                InputColumn.from_data_column(
                    column=TrainPlaneTravelModel.start_city,
                    nullable=False,
                ),
                InputColumn.from_data_column(
                    column=TrainPlaneTravelModel.start_country_name,
                    nullable=False,
                ),
                InputColumn.from_data_column(
                    column=TrainPlaneTravelModel.arrival_location_code,
                ),
                InputColumn.from_data_column(
                    column=TrainPlaneTravelModel.arrival_city,
                    nullable=False,
                ),
                InputColumn.from_data_column(
                    column=TrainPlaneTravelModel.arrival_country_name,
                    nullable=False,
                ),
                InputColumn.from_data_column(
                    column=TrainPlaneTravelModel.routing,
                ),
                InputColumn.from_data_column(
                    column=TrainPlaneTravelModel.transporter_name,
                ),
                InputColumn.from_data_column(
                    column=TrainPlaneTravelModel.supplier_alliance,
                ),
                InputColumn.from_data_column(
                    column=TrainPlaneTravelModel.cabin_class,
                    default=CabinClassTypes.unknown.value,
                ),
                InputColumn.from_data_column(
                    column=TrainPlaneTravelModel.start_datetime,
                    format=r'\d{4}-\d{2}-\d{2}(?: \d{2}:\d{2}:\d{2})?',
                ),
                InputColumn.from_data_column(
                    column=TrainPlaneTravelModel.end_datetime,
                    format=r'\d{4}-\d{2}-\d{2}(?: \d{2}:\d{2}:\d{2})?',
                ),
                InputColumn.from_data_column(
                    column=TrainPlaneTravelModel.layover_time,
                    format=r'(?:\d+j )?\d{2}:\d{2}'
                ),
                InputColumn.from_data_column(
                    column=TrainPlaneTravelModel.distance,
                ),
                InputColumn.from_data_column(
                    column=TrainPlaneTravelModel.CO2_footprint,
                ),
                InputColumn.from_data_column(
                    column=SoonGoRecordsModel.source_connector,
                    nullable=False,
                ),
                InputColumn.from_data_column(
                    column=SoonGoRecordsModel.synchronisation_type,
                    nullable=False,
                ),
                InputColumn.from_data_column(
                    column=SoonGoRecordsModel.synchronisation_id,
                    nullable=False,
                ),
            ],
        )

    def get(
        self: typing.Self,
        connector_data: ConnectorData,
        logger: logging.Logger,
        fetch_params_dict: typing.Optional[dict] = None,
    ) -> pd.DataFrame:
        """ Get vehicle table for Go Measure inputting

        :param gac_data: GacData with all data imported from gac

        :return: pandas dataframe with all columns from the vehicle table
        """
        # Get train plane data
        train_planes_df = self.fetch_table_data(
            connector_data=connector_data,
            logger=logger,
            fetch_params_dict=fetch_params_dict,
        )
        train_planes_df = add_synchronization_id(
            train_planes_df,
            connector_data,
        )
        if train_planes_df.empty:
            return train_planes_df

        if TrainPlaneTravelModel.travel_type.name in train_planes_df.columns:
            train_planes_df = train_planes_df.loc[
                train_planes_df[TrainPlaneTravelModel.travel_type.name].isin(
                    [
                        TravelTypes.air.value,
                        TravelTypes.rail.value,
                    ]
                ),
            ]

        train_planes_df = infer_amounts_and_tax(
            df=train_planes_df,
            logger=logger,
            connector_data=connector_data,
            date_var=TrainPlaneTravelModel.billing_date.name,
        )

        # Add soongo_employee_id and business unit
        train_planes_df = match_soongo_employee_id(
            table_to_match=train_planes_df,
            employee_table=EmployeesInputTable().get(
                connector_data=connector_data,
                logger=logger,
            )
        )
        train_planes_df = self.fill_missing_cols(
            df=train_planes_df,
        )
        return train_planes_df[self.return_column_names()]


if __name__ == "__main__":
    logger = gen_logger('train_plane_table')
    organization_name = 'Acorus'
    root_folder = '/home/matthieuglotz/Documents/Data/'
    organization_folder = os.path.join(
        root_folder,
        organization_name,
    )
    connector_data = ConnectorData(
        root_folder=root_folder,
        organization_name=organization_name,
    )

    travel_table = TravelInputTable()
    travel_df = travel_table.get(
        connector_data=connector_data,
        logger=logger,
    )
    travel_table.check_columns(
        data_df=travel_df,
        employees=EmployeesInputTable().get(
            connector_data=connector_data,
            logger=logger,
        ),
        logger=logger,
    )
    travel_df.to_csv(
        os.path.join(
            organization_folder,
            'webapp_tables',
            f'{travel_table.name}_table.csv',
        ),
        index=False,
        sep=';',
    )
