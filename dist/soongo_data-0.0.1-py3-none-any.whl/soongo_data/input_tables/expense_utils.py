""" Expense table utility functions"""
import logging
from typing import Set

import pandas as pd

from connectors.full_data import ConnectorData
from data_models import (
    ExpensesModel, ClaimsModel, VehiclesModel, VehicleAssociationsModel,
    CollaboratorsModel, SoonGoRecordsModel
)
from utils.type import str_is_nan
from utils.enums import (
    FiscalType, AssignmentType, RentCategory, ExpenseType, FuelTypes,
    InsurancePremiums
)
from input_tables.vehicles_table import VehiclesInputTable
from input_tables.vehicle_associations import VehicleAssociationsInputTable


def infer_amounts_and_tax(
    df: pd.DataFrame,
    logger: logging.Logger,
    connector_data: ConnectorData,
    vat_assumption: float = 0.2,
    date_var: str = SoonGoRecordsModel.record_date.name,
) -> pd.DataFrame:
    """ Infer amount tax inc, tax, excluded, net, and VAT from available
    information in df.

    :param df: DataFrame with amount information must have at least one of
    amount_tax_exc or amount_tax_inc
    """
    amount_cols = {
        ExpensesModel.amount_tax_inc.name,
        ExpensesModel.amount_tax_exc.name,
    }
    available_cols = amount_cols.intersection(df.columns)
    if not available_cols:
        raise ValueError('May not infer if no amount data available')

    # Fill in tax_inc and tax_exc
    if ExpensesModel.vat_amount.name in df.columns:
        if ExpensesModel.amount_tax_inc.name not in available_cols:
            df[ExpensesModel.amount_tax_inc.name] = (
                df[ExpensesModel.amount_tax_exc.name] +
                df[ExpensesModel.vat_amount.name]
            ).round(2)
        if ExpensesModel.amount_tax_exc.name not in available_cols:
            df[ExpensesModel.amount_tax_exc.name] = (
                df[ExpensesModel.amount_tax_inc.name] -
                df[ExpensesModel.vat_amount.name]
            ).round(2)

    if ExpensesModel.vat_amount.name not in df.columns:
        if ExpensesModel.expense_category.name in df.columns:
            is_insurance = (
                df[ExpensesModel.expense_category.name].isin(
                    [
                        insurance_cat.value for insurance_cat
                        in InsurancePremiums
                    ]
                )
            )
        else:
            is_insurance = pd.Series(False, index=df.index)

        if ExpensesModel.amount_tax_inc.name not in available_cols:
            df[ExpensesModel.amount_tax_inc.name] = (
                (1 + vat_assumption) * df[ExpensesModel.amount_tax_exc.name]
            ).round(2)
            df[ExpensesModel.amount_tax_inc.name] = (
                df[ExpensesModel.amount_tax_inc.name].mask(
                    is_insurance,
                    df[ExpensesModel.amount_tax_exc.name],
                )
            )
        if ExpensesModel.amount_tax_exc.name not in available_cols:
            df[ExpensesModel.amount_tax_exc.name] = (
                df[ExpensesModel.amount_tax_inc.name] / (1 + vat_assumption)
            ).round(2)
            df[ExpensesModel.amount_tax_exc.name] = (
                df[ExpensesModel.amount_tax_inc.name].mask(
                    is_insurance,
                    df[ExpensesModel.amount_tax_inc.name],
                )
            )

    # Fill in values for amount_tax_exc, amount_tax_inc and vat_amount
    df[ExpensesModel.amount_tax_inc.name] = (
        df[ExpensesModel.amount_tax_inc.name].fillna(
            value=(
                (1 + vat_assumption) * df[ExpensesModel.amount_tax_exc.name]
            ).round(2),
        )
    )
    df[ExpensesModel.amount_tax_exc.name] = (
        df[ExpensesModel.amount_tax_exc.name].fillna(
            value=(
                df[ExpensesModel.amount_tax_inc.name] / (1 + vat_assumption)
            ).round(2),
        )
    )
    df[ExpensesModel.vat_amount.name] = (
        df[ExpensesModel.amount_tax_inc.name] -
        df[ExpensesModel.amount_tax_exc.name]
    ).round(2)

    # Fill in deductible_vat
    calculated_deduc_vat = compute_deductible_vat(
            df=df,
            connector_data=connector_data,
            logger=logger,
            date_var=date_var,
        )

    if ExpensesModel.deductible_vat.name not in df.columns:
        df[ExpensesModel.deductible_vat.name] = calculated_deduc_vat
    else:
        df[ExpensesModel.deductible_vat.name] = (
            df[ExpensesModel.deductible_vat.name].where(
                pd.notna(df[ExpensesModel.deductible_vat.name]),
                calculated_deduc_vat,
            )
        )

    # Fill in net amount
    if ExpensesModel.net_amount.name not in df.columns:
        df[ExpensesModel.net_amount.name] = (
            df[ExpensesModel.amount_tax_inc.name] -
            df[ExpensesModel.deductible_vat.name]
        ).round(2)
    else:
        df[ExpensesModel.net_amount.name].fillna(
            value=(
                df[ExpensesModel.amount_tax_inc.name] -
                df[ExpensesModel.deductible_vat.name]
            ).round(2),
            inplace=True,
        )
    return df


def compute_deductible_vat(
    df: pd.DataFrame,
    connector_data: ConnectorData,
    logger: logging.Logger,
    date_var: str = SoonGoRecordsModel.record_date.name,
) -> pd.Series:
    """ Computes deductible vat for each row, based on vehicle fiscal type and
    assignment as well as SoonGoCategory, if available.

    :param df: Pandas Dataframe for which the deductible vat must be computed
    :param connector_data: Connector Data for this organization
    :param logger: logger

    :returns: pd Series of float deductible vat values. DataFrame df also
        modified in place.
    """
    if ExpensesModel.vat_amount.name not in df.columns:
        raise ValueError(
            'vat_amount is required to compute deductible_vat. '
            'See infer_amounts_and_tax.'
        )
    if not (
        (VehiclesModel.fiscal_type.name in df.columns) and
        (VehicleAssociationsModel.assignment_type.name in df.columns)
    ):
        if CollaboratorsModel.employee_id.name in df.columns:
            fetch_plate_from_collab(
                df=df,
                connector_data=connector_data,
                date_var=date_var,
            )
        # If employee_id available then plate_number added by previous lines
        if VehiclesModel.plate_number.name in df.columns:
            df = fetch_vehicle_data(
                df=df,
                cols_to_fetch={
                    VehiclesModel.fiscal_type.name,
                    VehicleAssociationsModel.assignment_type.name,
                },
                connector_data=connector_data,
                logger=logger,
            )
            is_vu = (
                df[VehiclesModel.fiscal_type.name] !=
                FiscalType.personal_car.value
            ) & pd.notna(df[VehiclesModel.fiscal_type.name])
            is_service = (
                df[VehicleAssociationsModel.assignment_type.name] ==
                AssignmentType.service_vehicle.value
            ) & pd.notna(df[VehicleAssociationsModel.assignment_type.name])
            is_exempt = is_vu | is_service

        else:
            logger.warning(
                'No plate_number or employee_id information. '
                'Assuming not exempt'
            )
            is_exempt = pd.Series([False] * len(df))

    if ExpensesModel.expense_category.name in df.columns:
        not_rent = ~df[ExpensesModel.expense_category.name].isin(
            [rent_cat.value for rent_cat in RentCategory]
        )
        full_deductibility = (
            is_exempt | not_rent
        )
        deduc_vat = df[ExpensesModel.vat_amount.name].where(
            full_deductibility,
            0.0,
        )

        not_fuel = (
            ~df[ExpensesModel.expense_category.name].isin(
                (fuel_type.value for fuel_type in FuelTypes)
            )
        )
        deduc_vat = deduc_vat.where(
            full_deductibility | not_fuel,
            (0.8 * df[ExpensesModel.vat_amount.name]).round(2),
        )

    elif ClaimsModel.expense_type.name in df.columns:
        not_fuel = (
            df[ClaimsModel.expense_type.name] !=
            ExpenseType.fuel.value
        )
        deduc_vat = df[ExpensesModel.vat_amount.name].where(
            is_exempt | not_fuel,
            (0.8 * df[ExpensesModel.vat_amount.name]).round(2),
        )

    else:
        logger.warning(
            'No category provided. Assuming not fuel nor rent'
        )
        deduc_vat = df[ExpensesModel.vat_amount.name]

    return deduc_vat.values


def fetch_vehicle_data(
    df: pd.DataFrame,
    cols_to_fetch: Set[str],
    connector_data: ConnectorData,
    logger: logging.Logger,
) -> pd.DataFrame:
    """ Fetch columns of interest from the vehicle table

    :param df: Pandas DataFrame to enrich. Must have either plate_number or
    employee_id
    :param cols_to_fetch: list of columns to fetch. Must be among vehicle_table
    columns.
    :param connector_data: Connector Data with all data for the organisation

    :return: enriched df with additional columns
    """
    missing_cols = cols_to_fetch.difference(df.columns)
    if not missing_cols:
        logger.error(
            'Asked to fetch %s but already available',
            cols_to_fetch,
        )

    if VehiclesModel.plate_number.name not in df.columns:
        raise ValueError(
            'Plate number must be provided'
        )

    vehicle_df = VehiclesInputTable().get(
        connector_data=connector_data,
        logger=logger,
    )
    df = df.merge(
        vehicle_df[[VehiclesModel.plate_number.name] + list(missing_cols)],
        on=VehiclesModel.plate_number.name,
        how='left',
        validate='m:1',
        indicator=True,
    )
    assert (
        df.loc[
            ~str_is_nan(df[VehiclesModel.plate_number.name]),
            '_merge',
        ] == 'both'
    ).all()
    df.drop(columns='_merge', inplace=True)
    return df


def fetch_plate_from_collab(
    df: pd.DataFrame,
    connector_data: ConnectorData,
    logger: logging.Logger,
    date_var: str = SoonGoRecordsModel.record_date.name,
) -> pd.DataFrame:
    """ Fetch company vehicle plate_number from a Series of collaborator_id

    :param df: Pandas DataFrame to enrich. Must have either plate_number or
        employee_id
    :param id_var: column name uniquely identifying rows to help deduplicate
        entries.
    :param date_var: column
    :param connector_data: Connector Data with all data for the organisation

    :return: df with additional plate_number column
    """
    if CollaboratorsModel.employee_id.name not in df.columns:
        raise ValueError(
            'Plate number must be provided'
        )
    if df.index.unique:
        df['temp_row_id'] = df.index
    else:
        df['temp_row_id'] = df.reset_index().index

    association_df = VehicleAssociationsInputTable().get(
        connector_data=connector_data,
        logger=logger,
    )

    df = df.merge(
        association_df[
            [
                VehiclesModel.plate_number.name,
                CollaboratorsModel.employee_id.name,
                VehicleAssociationsModel.association_start_date.name,
                VehicleAssociationsModel.association_end_date.name,
            ]
        ],
        on=CollaboratorsModel.employee_id.name,
        how='left',
        indicator=('_1', '_2'),
    )
    if 'plate_number_1' in df.columns:
        df[VehiclesModel.plate_number.name] = (
            df['plate_number_1'].fillna(df['plate_number_2'])
        )
        df.drop(['plate_number_1', 'plate_number_2'], axis=1, inplace=True)

    df = df.loc[
        (df[date_var] >= df[VehicleAssociationsModel.association_start_date.name])
        &
        (
            (df[date_var] <= df[VehicleAssociationsModel.association_end_date.name])
            |
            pd.isna(df[VehicleAssociationsModel.association_end_date.name])
        )
    ]
    df['min_start_date'] = df.groupby('temp_row_id')[
        VehicleAssociationsModel.association_start_date.name
    ].transform('min')
    df['temp_end_date'] = (
        df[VehicleAssociationsModel.association_end_date.name].fillna(
            df[date_var].max(),  # Filler which cannot be exceeded
        )
    )
    df['max_start_date'] = df.groupby('temp_row_id')[
        'temp_end_date'
    ].transform('max')
    df = df.loc[
        (
            (df[VehicleAssociationsModel.association_start_date.name] == df['min_start_date'])
            &
            (df['max_start_date'] == df['max_start_date'])
        ) |
        # If association_start_date is na, then no association (mandatory col)
        pd.isna(df[VehicleAssociationsModel.association_start_date.name])
    ]
    assert df['temp_row_id'].unique
    df = df.drop('temp_row_id', axis=1)
    return df
