""" Script to calculate the hotels table to load in database."""
import logging
import os
import typing

import pandas as pd

from connectors.full_data import ConnectorData
from data_models import (
    HotelsModel, CollaboratorsModel, SoonGoRecordsModel
)
from input_tables.employees_table import EmployeesInputTable
from input_tables.expense_utils import infer_amounts_and_tax
from input_tables.table_utils import (
    InputColumn, InputTable, match_soongo_employee_id, add_synchronization_id
)
from utils.logging import gen_logger
from utils.enums import TravelTypes
from sql_mappings import HotelsTable


class HotelsInputTable(InputTable):
    def __init__(self):
        super().__init__(
            name='hotels',
            sql_mapping=HotelsTable,
            date_col_name='billing_date',
            columns=[
                InputColumn.from_data_column(
                    column=HotelsModel.expense_id,
                    unique=True,
                    is_id=True,
                ),
                InputColumn.from_data_column(
                    column=HotelsModel.booking_date,
                    format=r'\d{4}-\d{2}-\d{2}',
                    nullable=False,
                    is_id=True,
                ),
                InputColumn.from_data_column(
                    column=HotelsModel.billing_date,
                    format=r'\d{4}-\d{2}-\d{2}',
                ),
                InputColumn.from_data_column(
                    column=CollaboratorsModel().employee_id,
                    foreign_relationship=(
                        EmployeesInputTable().name,
                        CollaboratorsModel.employee_id.name,
                    ),
                    is_id=True,
                ),
                InputColumn.from_data_column(
                    column=HotelsModel.supplier,
                ),
                InputColumn.from_data_column(
                    column=HotelsModel.room_type,
                ),
                InputColumn.from_data_column(
                    column=HotelsModel.start_city,
                    nullable=False,
                ),
                InputColumn.from_data_column(
                    column=HotelsModel.start_country_name,
                    nullable=False,
                ),
                InputColumn.from_data_column(
                    column=HotelsModel.room_count,
                ),
                InputColumn.from_data_column(
                    column=HotelsModel.night_count,
                    nullable=False,
                ),
                InputColumn.from_data_column(
                    column=HotelsModel.room_night_count,
                ),
                InputColumn.from_data_column(
                    column=HotelsModel.price_per_room_night,
                ),
                InputColumn.from_data_column(
                    column=HotelsModel.amount_tax_exc,
                    is_id=True,
                ),
                InputColumn.from_data_column(
                    column=HotelsModel.deductible_vat,
                ),
                InputColumn.from_data_column(
                    column=HotelsModel.net_amount,
                ),
                InputColumn.from_data_column(
                    column=HotelsModel.amount_fees,
                ),
                InputColumn.from_data_column(
                    column=HotelsModel.was_negotiated,
                ),
                InputColumn.from_data_column(
                    column=HotelsModel.approver,
                ),
                InputColumn.from_data_column(
                    column=SoonGoRecordsModel.source_connector,
                    nullable=False,
                ),
                InputColumn.from_data_column(
                    column=SoonGoRecordsModel.synchronisation_type,
                    nullable=False,
                ),
                InputColumn.from_data_column(
                    column=SoonGoRecordsModel.synchronisation_id,
                    nullable=False,
                ),
            ],
        )

    def get(
        self: typing.Self,
        connector_data: ConnectorData,
        logger: logging.Logger,
        fetch_params_dict: typing.Optional[dict] = None,
    ) -> pd.DataFrame:
        """ Get vehicle table for Go Measure inputting

        :param gac_data: GacData with all data imported from gac

        :return: pandas dataframe with all columns from the vehicle table
        """
        # Get hotel data
        hotel_df = self.fetch_table_data(
            connector_data=connector_data,
            logger=logger,
            fetch_params_dict=fetch_params_dict,
        )
        hotel_df = add_synchronization_id(hotel_df, connector_data)
        if hotel_df.empty:
            return hotel_df

        if HotelsModel.travel_type.name in hotel_df.columns:
            hotel_df = hotel_df.loc[
                (
                    hotel_df[HotelsModel.travel_type.name] ==
                    TravelTypes.hotels.value
                ),
            ]
        hotel_df = infer_amounts_and_tax(
            df=hotel_df,
            logger=logger,
            connector_data=connector_data,
            date_var=HotelsModel.billing_date.name,
        )

        # Add soongo_employee_id and business unit
        hotel_df = match_soongo_employee_id(
            table_to_match=hotel_df,
            employee_table=EmployeesInputTable().get(
                connector_data=connector_data,
                logger=logger,
            )
        )
        hotel_df = self.fill_missing_cols(
            df=hotel_df,
        )

        return hotel_df[self.return_column_names()]


if __name__ == "__main__":
    logger = gen_logger('hotels_table')
    organization_name = 'Acorus'
    root_folder = '/home/matthieuglotz/Documents/Data/'
    organization_folder = os.path.join(
        root_folder,
        organization_name,
    )
    connector_data = ConnectorData(
        root_folder=root_folder,
        organization_name=organization_name,
    )
    hotel_table = HotelsInputTable()
    hotel_df = hotel_table.get(
        connector_data=connector_data,
        logger=logger,

    )
    hotel_table.check_columns(
        data_df=hotel_df,
        employees=EmployeesInputTable().get(
            connector_data=connector_data,
            logger=logger,
        ),
        logger=logger,
    )
    hotel_df.to_csv(
        os.path.join(
            organization_folder,
            'webapp_tables',
            f'{hotel_table.name}_table.csv',
        ),
        index=False,
        sep=';',
    )
