""" Script to calculate the mileage table to load in database."""
import os
import logging
import math
import typing

import pandas as pd
import numpy as np

from data_models import VehiclesModel, MileageReportsModel, SoonGoRecordsModel
from connectors.full_data import ConnectorData
from input_tables.vehicles_table import VehiclesInputTable
from input_tables.table_utils import (
    InputColumn, InputTable, add_synchronization_id
)
from utils.logging import gen_logger
from utils.dataset import series_is_nan
from sql_mappings import MileagesTable


class MileagesInputTable(InputTable):

    def __init__(self):
        super().__init__(
            name='mileages',
            sql_mapping=MileagesTable,
            date_col_name='mileage_date',
            columns=[
                InputColumn.from_data_column(
                    column=VehiclesModel.plate_number,
                    foreign_relationship=(
                        VehiclesInputTable().name,
                        VehiclesModel.plate_number.name,
                    ),
                    nullable=False,
                    is_id=True,
                ),
                InputColumn.from_data_column(
                    column=MileageReportsModel.mileage,
                    nullable=False,
                    is_id=True,
                ),
                InputColumn.from_data_column(
                    column=MileageReportsModel.mileage_date,
                    is_id=True,
                ),
                InputColumn.from_data_column(
                    column=SoonGoRecordsModel.source_connector,
                    nullable=False,
                ),
                InputColumn.from_data_column(
                    column=SoonGoRecordsModel.synchronisation_type,
                    nullable=False,
                ),
                InputColumn.from_data_column(
                    column=SoonGoRecordsModel.synchronisation_id,
                    nullable=False,
                ),
            ],
        )

    def get(
        self: typing.Self,
        connector_data: ConnectorData,
        logger: logging.Logger,
        fetch_params_dict: typing.Optional[dict] = None,
    ) -> pd.DataFrame:
        """ Get vehicle table for Go Measure inputting

        :param gac_data: GacData with all data imported from gac

        :return: pandas dataframe with all columns from the vehicle table
        """
        # Aggregate data
        combined_df = self.fetch_table_data(
            connector_data=connector_data,
            logger=logger,
            fetch_params_dict=fetch_params_dict,
        )
        combined_df = add_synchronization_id(combined_df, connector_data)
        if combined_df.empty:
            return combined_df

        combined_df = combined_df.loc[
            ~series_is_nan(combined_df[VehiclesModel.plate_number.name]) &
            ~series_is_nan(combined_df[MileageReportsModel.mileage.name]) &
            ~series_is_nan(combined_df[MileageReportsModel.mileage_date.name]),
        ]

        combined_df = self.correct_inconsistent_mileage(
            mileage_df=combined_df,
            _logger=logger,
        )
        combined_df[MileageReportsModel.mileage_date.name] = (
            combined_df[MileageReportsModel.mileage_date.name].dt.floor('d')
        )
        return combined_df[self.return_column_names()]

    @staticmethod
    def correct_inconsistent_mileage(
        mileage_df: pd.DataFrame,
        _logger: logging.Logger,
        max_mileage_per_day: int = 1000,
        max_mileage_per_week: int = 5000,
    ) -> pd.DataFrame:
        """ Correct inconsistent mileage values - i.e. lower mileage at more
        recent datetime

        :param mileage_df: Pandas Dataframe with plate_number, mileage, date
        """
        # Inefficient solution - loop across rows
        plate_col = VehiclesModel.plate_number.name
        mileage_col = MileageReportsModel.mileage.name
        date_col = MileageReportsModel.mileage_date.name
        mileage_df = mileage_df.sort_values(
            by=[plate_col, date_col, mileage_col],
        )
        error_vec = np.repeat([0], repeats=len(mileage_df))
        mileage_df.reset_index(drop=True, inplace=True)
        previous_row = mileage_df.iloc[0, :]
        for index, row in mileage_df.iterrows():
            error = False
            if (
                (row[mileage_col] < previous_row[mileage_col]) &
                (row[plate_col] == previous_row[plate_col]) &
                pd.notna(row[date_col]) &
                pd.notna(previous_row[date_col])
            ):
                error_vec[index] = 1
                error = True

            if (
                (row[plate_col] == previous_row[plate_col]) &
                pd.notna(row[date_col]) &
                pd.notna(previous_row[date_col])
            ):
                day_diff = (row[date_col] - previous_row[date_col]).days
                mileage_diff = row[mileage_col] - previous_row[mileage_col]

                if day_diff > 0:
                    mileage_per_day = mileage_diff / day_diff
                    week_count = math.ceil(day_diff / 7)
                    is_error = (
                        (mileage_per_day > max_mileage_per_day)
                        or (mileage_diff > week_count * max_mileage_per_week)
                    )

                else:  # If the two readings occured on the same day
                    is_error = mileage_diff > max_mileage_per_day

                if is_error:
                    error_vec[index] = 1
                    error = True

            if not error:
                previous_row = row

        _logger.info(
            'Dropping %d mileage readings because inconsistent with previous '
            'readings',
            np.sum(error_vec)
        )
        mileage_df = mileage_df.loc[error_vec != 1, ]

        return mileage_df


if __name__ == "__main__":
    logger = gen_logger('mileage_table')
    organization_name = 'Acorus'
    root_folder = '/home/matthieuglotz/Documents/Data/'
    organization_folder = os.path.join(
        root_folder,
        organization_name,
    )
    connector_data = ConnectorData(
        root_folder=root_folder,
        organization_name=organization_name,
    )
    mileage_table = MileagesInputTable()
    mileage_df = mileage_table.get(
        connector_data=connector_data,
        logger=logger,
    )
    mileage_table.check_columns(
        data_df=mileage_df,
        vehicles=VehiclesInputTable().get(
            connector_data=connector_data,
            logger=logger,
        ),
        logger=logger,
    )
    mileage_df.to_csv(
        os.path.join(
            organization_folder,
            'webapp_tables',
            f'{mileage_table.name}_table.csv',
        ),
        index=False,
        sep=';',
        date_format=r'%Y-%m-%d %H:%M:%S',
    )
