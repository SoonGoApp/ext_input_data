""" Script to calculate the vehicle table on which to compute impacts."""
import logging
import os
import typing

import numpy as np
import pandas as pd

from connectors.full_data import ConnectorData
from data_models import (
    CollaboratorsModel, BusinessUnitsModel, SoonGoRecordsModel
)
from input_tables.table_utils import (
    InputColumn, InputTable, get_business_units,
    regroup_dataframe, gen_soongo_emp_id, add_synchronization_id
)
from sql_mappings import CollaboratorsTable
from utils.logging import gen_logger
from utils.type import str_is_nan, series_is_nan


class EmployeesInputTable(InputTable):

    def __init__(self: typing.Self):
        super().__init__(
            name='employees',
            sql_mapping=CollaboratorsTable,
            columns=[
                InputColumn.from_data_column(
                    column=CollaboratorsModel.employee_id,
                    unique=True,
                    nullable=False,
                    is_id=True,
                ),
                InputColumn.from_data_column(
                    column=CollaboratorsModel.organization_employee_id,
                    unique=True,
                ),
                InputColumn.from_data_column(
                    column=CollaboratorsModel.employee_first_name,
                ),
                InputColumn.from_data_column(
                    column=CollaboratorsModel.employee_last_name,
                ),
                InputColumn.from_data_column(
                    column=CollaboratorsModel.employee_role,
                ),
                InputColumn.from_data_column(
                    column=CollaboratorsModel.work_location,
                ),
                InputColumn.from_data_column(
                    column=CollaboratorsModel.employee_internal_category,
                ),
                InputColumn.from_data_column(
                    column=CollaboratorsModel.employee_entry_date,
                ),
                InputColumn.from_data_column(
                    column=CollaboratorsModel.employee_exit_date,
                ),
                InputColumn.from_data_column(
                    column=BusinessUnitsModel.business_unit,
                    format=r'\w+(?: > \w+)*',
                ),
                InputColumn.from_data_column(
                    column=BusinessUnitsModel.geography,
                    format=r'\w+(?: > \w+)*',
                ),
                InputColumn.from_data_column(
                    column=CollaboratorsModel.alternative_names,
                    nullable=False,
                ),
                InputColumn.from_data_column(
                    column=SoonGoRecordsModel.source_connector,
                    nullable=False,
                ),
                InputColumn.from_data_column(
                    column=SoonGoRecordsModel.synchronisation_type,
                    nullable=False,
                ),
                InputColumn.from_data_column(
                    column=SoonGoRecordsModel.synchronisation_id,
                    nullable=False,
                ),
            ]
        )

    def get(
        self: typing.Self,
        connector_data: ConnectorData,
        logger: logging.Logger,
        fetch_params_dict: typing.Optional[dict] = None,
    ) -> pd.DataFrame:
        """ Get Employees tables

        :param gac_data: Gac Data Class with all folders
        :param havas_data: Havas Data Class with all folders
        """
        combined_df = self.fetch_table_data(
            connector_data=connector_data,
            logger=logger,
            fetch_params_dict=fetch_params_dict,
        )
        combined_df = add_synchronization_id(combined_df, connector_data)
        if combined_df.empty:
            return combined_df

        combined_df = get_business_units(
            combined_df,
            logger=logger,
            organization_name=connector_data.organization_name,
        )
        combined_df = gen_soongo_emp_id(combined_df)
        combined_df[CollaboratorsModel.alternative_names.name] = (
            combined_df[CollaboratorsModel.employee_id.name]
        )

        # Regroup based on id
        combined_df = regroup_dataframe(
            raw_df=combined_df,
            groupby_col=CollaboratorsModel.organization_employee_id.name,
            logger=logger,
        ).reset_index(drop=True)

        combined_df = self.deduplicate(combined_df=combined_df, logger=logger)
        combined_df = infer_category(combined_df)

        return self.final_format(combined_df)

    @classmethod
    def deduplicate(
        cls: typing.Self,
        combined_df: pd.DataFrame,
        logger: logging.Logger,
    ) -> pd.DataFrame:
        """ Deduplicate DataFrame

        :param combined_df: pandas DataFrame of employee names and ids
        :param logger: logger
        """
        # Drop missing ids
        missing_name_sets = str_is_nan(
            combined_df[CollaboratorsModel.employee_id.name]
        )
        combined_df = combined_df.loc[
            ~missing_name_sets,
        ]
        logger.info(
            'Dropped %d missing name set ids',
            missing_name_sets.sum(),
        )

        # Name set deduplication rule
        combined_df = cls.rebuild_from_id(
            dup_df=combined_df,
            id_col=CollaboratorsModel.employee_id.name,
            logger=logger,
        )

        # Employee matriculation deduplication rule
        combined_df = cls.rebuild_from_id(
            dup_df=combined_df,
            id_col=CollaboratorsModel.organization_employee_id.name,
            logger=logger,
        )
        combined_df[CollaboratorsModel.alternative_names.name] = (
            combined_df[CollaboratorsModel.alternative_names.name].mask(
                str_is_nan(combined_df[CollaboratorsModel.alternative_names.name]),
                combined_df[CollaboratorsModel.employee_id.name]
            )
        )

        return combined_df

    @staticmethod
    def rebuild_from_id(dup_df: pd.DataFrame, id_col: str, logger: logging.Logger):
        """ Rebuild a DataFrame from an id col as a deduplication method

        :param dup_df: duplicated dataframe
        :param id_col: string name of the column to use as id

        :return: deduplicated column id.
        """
        initial_rows = len(dup_df)
        initial_ids = set(dup_df[id_col])
        soongo_id = CollaboratorsModel.employee_id.name

        missing_id = str_is_nan(dup_df[id_col])
        missing_id_df = dup_df.loc[missing_id,]
        id_df = dup_df.loc[~missing_id]
        dedup_df = id_df[[id_col]].drop_duplicates()
        for var_col in id_df.columns:
            if var_col == id_col:
                continue

            col_df = id_df.loc[
                ~series_is_nan(id_df[var_col]),
                [id_col, var_col]
            ].drop_duplicates(subset=id_col)  # Effectively keeps first entry

            if var_col == soongo_id:  # Record the variations
                alt_names_df = id_df.groupby(
                    id_col
                )[soongo_id].agg(', '.join).reset_index()
                alt_names_df.rename(
                    columns={soongo_id: 'temp_alt_names'},
                    inplace=True,
                )
                col_df = col_df.merge(
                    right=alt_names_df,
                    on=id_col,
                    validate='1:1',
                    indicator=True,
                )
                assert (col_df._merge == 'both').all()
                col_df.drop(columns='_merge', inplace=True)

            dedup_df = dedup_df.merge(
                right=col_df,
                how='left',
                on=id_col,
                validate='1:1',
            )

        dedup_df = pd.concat([missing_id_df, dedup_df], axis=0)

        if 'temp_alt_names' in dedup_df.columns:
            augmented_alt_names = np.where(
                str_is_nan(dedup_df[CollaboratorsModel.alternative_names.name]),
                dedup_df['temp_alt_names'],
                dedup_df[CollaboratorsModel.alternative_names.name] + ', ' +
                dedup_df['temp_alt_names']
            )
            dedup_df[CollaboratorsModel.alternative_names.name] = np.where(
                ~str_is_nan(dedup_df['temp_alt_names']),
                augmented_alt_names,
                dedup_df[CollaboratorsModel.alternative_names.name]
            )
            dedup_df.drop('temp_alt_names', axis=1, inplace=True)

            # Deduplication alternative names
            dedup_df[CollaboratorsModel.alternative_names.name] = (
                dedup_df[CollaboratorsModel.alternative_names.name].str.split(
                    ', '
                ).apply(set).apply(lambda x: ', '.join(x))
            )
        assert set(dedup_df[id_col]) == initial_ids
        assert (dedup_df.columns == dup_df.columns).all()
        logger.info(
            'Deduplicated %d employee rows using column %s',
            initial_rows - len(dedup_df),
            id_col,
        )
        return dedup_df

    def final_format(self: typing.Self, combined_df: pd.DataFrame) -> pd.DataFrame:
        """Final formatting of the employee table"""
        assert combined_df[CollaboratorsModel.employee_id.name].is_unique
        assert combined_df.loc[
            pd.notna(
                combined_df[CollaboratorsModel.organization_employee_id.name]
            ),
            CollaboratorsModel.organization_employee_id.name
        ].is_unique, 'Duplicated organization employee ids in the data'
        combined_df = self.fill_missing_cols(
            df=combined_df,
        )

        for col in self.columns:
            if pd.api.types.is_string_dtype(col.dtype):
                combined_df[col.name] = (
                    combined_df[col.name].str.replace(
                        r'^nan$', '', regex=True, case=False,
                    ).fillna('')
                )

        return combined_df[self.return_column_names()]


def infer_category(
    role_df: pd.DataFrame,
) -> pd.DataFrame:
    """ Infer collaborator category from their role.

    :param role_df: pd DataFrame which must have an
        organization_collaborator column and a role column*

    :raises ValueError: if necessary cols are not available
    """
    if not (
        {
            CollaboratorsModel.employee_role.name,
            CollaboratorsModel.employee_internal_category.name,
        }.issubset(role_df.columns)
    ):
        # Nothing to infer
        return role_df

    if (
        series_is_nan(
            role_df[CollaboratorsModel.employee_internal_category.name]
        ) == series_is_nan(
            role_df[CollaboratorsModel.employee_role.name]
        )
    ).all():
        # Nothing to infer
        return role_df

    # Strategy 1: fill internal_category with that of collab with same role
    available_orga = role_df.loc[
        ~series_is_nan(
            role_df[CollaboratorsModel.employee_internal_category.name]
        ) & ~series_is_nan(
            role_df[CollaboratorsModel.employee_role.name]
        ),
        [
            CollaboratorsModel.employee_internal_category.name,
            CollaboratorsModel.employee_role.name,
        ],
    ]

    available_orga['alt_cat'] = available_orga.groupby(
        CollaboratorsModel.employee_role.name
    )[CollaboratorsModel.employee_internal_category.name].transform(
        lambda x: x.mode()[0]  # Mode returns a series even if one mode
    )
    available_orga = available_orga[
        [
            CollaboratorsModel.employee_role.name,
            'alt_cat',
        ]
    ].drop_duplicates()

    role_df = role_df.merge(
        available_orga,
        on=[CollaboratorsModel.employee_role.name],
        validate='m:1',
        how='left',
        indicator='_role_merge',
    )
    assert (role_df.loc[
        ~series_is_nan(
            role_df[CollaboratorsModel.employee_internal_category.name]
        ) & ~series_is_nan(
            role_df[CollaboratorsModel.employee_role.name]
        ),
        '_role_merge',
    ] == 'both').all()

    # Strategy 2: fill in when part of the role title matches (e.g. director)
    role_df['role_indicator'] = ''
    i = 0
    for role_pattern in (
        r'charg(?:é|e)',
        r'responsable',
        r'direct(?:eur|rice) g(?:é|e)n(?:é|e)ral',
        r'(?!.*g(?:é|e)n(?:é|e)ral.*).*direct(?:eur|rice).*',
    ):
        indicator = role_df[CollaboratorsModel.employee_role.name].str.match(
            pat=role_pattern, case=False,
        ).fillna(False)
        # Check no overlap across series
        assert series_is_nan(
            role_df.loc[indicator, 'role_indicator']
        ).all()
        role_df['role_indicator'] = (
            role_df['role_indicator'].mask(
                indicator,
                i,
            )
        )
        assert str_is_nan(
            role_df.loc[
                str_is_nan(role_df[CollaboratorsModel.employee_role.name]),
                'role_indicator',
            ]
        ).all()
        i += 1
    role_df['role_indicator'] = role_df['role_indicator'].mask(
        series_is_nan(role_df[CollaboratorsModel.employee_role.name]),
        '',
    )
    available_indicator = role_df.loc[
        ~series_is_nan(
            role_df[CollaboratorsModel.employee_internal_category.name]
        ) & ~series_is_nan(
            role_df['role_indicator']
        ),
        [
            CollaboratorsModel.employee_internal_category.name,
            'role_indicator',
        ],
    ]
    available_indicator['alt_cat2'] = available_indicator.groupby(
        'role_indicator'
    )[CollaboratorsModel.employee_internal_category.name].transform(
        lambda x: x.mode()[0]  # Mode returns a series even if one mode
    )
    available_indicator = available_indicator[
        [
            'role_indicator',
            'alt_cat2',
        ]
    ].drop_duplicates()

    role_df = role_df.merge(
        available_indicator,
        on=['role_indicator'],
        validate='m:1',
        how='left',
        indicator='_indicator_merge',
    )
    for substitute_col in ['alt_cat', 'alt_cat2']:
        role_df[CollaboratorsModel.employee_internal_category.name] = (
            role_df[CollaboratorsModel.employee_internal_category.name].mask(
                series_is_nan(
                    role_df[CollaboratorsModel.employee_internal_category.name]
                ),
                role_df[substitute_col]
            )
        )

    role_df.drop(
        ['alt_cat', 'alt_cat2', '_role_merge', '_indicator_merge'],
        axis=1,
        inplace=True,
    )
    return role_df


if __name__ == "__main__":

    logger = gen_logger('employees_table')
    organization_name = 'Acorus'
    root_folder = '/home/matthieuglotz/Documents/Data/'
    organization_folder = os.path.join(
        root_folder,
        organization_name,
    )
    connector_data = ConnectorData(
        root_folder=root_folder,
        organization_name=organization_name,
    )
    employee_table = EmployeesInputTable()
    employee_df = employee_table.get(
        connector_data=connector_data,
        logger=logger,
    )
    employee_table.check_columns(
        data_df=employee_df,
        logger=logger,
    )
    employee_df.to_csv(
        os.path.join(
            organization_folder,
            'webapp_tables',
            f'{employee_table.name}_table.csv',
        ),
        index=False,
        sep=';',
    )
