""" Script to calculate the vehicle table on which to compute impacts."""
import logging
from datetime import datetime
import os
import typing

import pandas as pd

from data_models import (
    VehiclesModel, BusinessUnitsModel, VehicleOrdersModel,
    VehicleContractsModel, VehicleStatusModel, MileageReportsModel,
    VehicleAssociationsModel, SoonGoRecordsModel
)
from connectors.greenncap.full_data import GreenNCapData, GreenNCapTables
from connectors.full_data import ConnectorData
from input_tables.table_utils import (
    InputColumn, InputTable, get_business_units, keep_duplicates,
    add_synchronization_id
)
from utils.logging import gen_logger
from utils.type import str_is_nan, series_is_nan
from utils.enums import mapper_factory, ModelCategories
from sql_mappings import VehiclesTable

pd.set_option('future.no_silent_downcasting', True)


class VehiclesInputTable(InputTable):

    def __init__(self):
        super().__init__(
            name='vehicles',
            sql_mapping=VehiclesTable,
            columns=[
                InputColumn.from_data_column(
                    column=VehiclesModel.plate_number,
                    nullable=False,
                    unique=True,
                    is_id=True,
                ),
                InputColumn.from_data_column(
                    column=VehiclesModel.make,
                ),
                InputColumn.from_data_column(
                    column=VehiclesModel.model,
                ),
                InputColumn.from_data_column(
                    column=VehiclesModel.full_model,
                ),
                InputColumn.from_data_column(
                    column=VehiclesModel.theoretical_CO2_per_km,
                ),
                InputColumn.from_data_column(
                    column=VehiclesModel.CO2_production,
                ),
                InputColumn.from_data_column(
                    column=VehiclesModel.CO2_recycling,
                ),
                InputColumn.from_data_column(
                    column=VehiclesModel.energy,
                ),
                InputColumn.from_data_column(
                    column=VehiclesModel.manufacturer_price_tax_exc,
                ),
                InputColumn.from_data_column(
                    column=VehiclesModel.rebate_rate,
                ),
                InputColumn.from_data_column(
                    column=VehiclesModel.rebate_price_ttc,
                ),
                InputColumn.from_data_column(
                    column=VehicleOrdersModel.order_reference,
                ),
                InputColumn.from_data_column(
                    column=VehicleContractsModel.lease_start_date,
                ),
                InputColumn.from_data_column(
                    column=VehicleContractsModel.lease_end_date,
                ),
                InputColumn.from_data_column(
                    column=VehicleStatusModel.vehicle_status,
                ),
                InputColumn.from_data_column(
                    column=VehicleContractsModel.lease_months,
                ),
                InputColumn.from_data_column(
                    column=VehicleContractsModel.lease_mileage,
                ),
                InputColumn.from_data_column(
                    column=VehiclesModel.vehicle_age,
                ),
                InputColumn.from_data_column(
                    column=VehiclesModel.car_supplier,
                ),
                InputColumn.from_data_column(
                    column=VehiclesModel.initial_mileage,
                ),
                InputColumn.from_data_column(
                    column=MileageReportsModel.mileage,
                ),
                InputColumn.from_data_column(
                    column=MileageReportsModel.mileage_date,
                    format=r'\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}',
                ),
                InputColumn.from_data_column(
                    column=VehiclesModel.fiscal_power,
                ),
                InputColumn.from_data_column(
                    column=VehiclesModel.fiscal_type,
                ),
                InputColumn.from_data_column(
                    column=VehiclesModel.is_air_quality_certified,
                ),
                InputColumn.from_data_column(
                    column=VehiclesModel.seat_count,
                ),
                InputColumn.from_data_column(
                    column=BusinessUnitsModel.business_unit,
                ),
                InputColumn.from_data_column(
                    column=VehiclesModel.theoretical_fuel_consumption,
                ),
                InputColumn.from_data_column(
                    column=VehicleContractsModel.contract_type,
                ),
                InputColumn.from_data_column(
                    column=VehiclesModel.entry_into_service_date,
                ),
                InputColumn.from_data_column(
                    column=VehicleAssociationsModel.assignment_type,
                ),
                InputColumn.from_data_column(
                    column=VehiclesModel.model_category,
                ),
                InputColumn.from_data_column(
                    column=SoonGoRecordsModel.source_connector,
                    nullable=False,
                ),
                InputColumn.from_data_column(
                    column=SoonGoRecordsModel.synchronisation_type,
                    nullable=False,
                ),
                InputColumn.from_data_column(
                    column=SoonGoRecordsModel.synchronisation_id,
                    nullable=False,
                ),
            ],
        )

    def get(
        self: typing.Self,
        connector_data: ConnectorData,
        logger: logging.Logger,
        fetch_params_dict: typing.Optional[dict] = None,
    ) -> pd.DataFrame:
        """ Get vehicle table for Go Measure inputting

        :param gac_data: GacData with all data imported from gac

        :return: pandas dataframe with all columns from the vehicle table
        """
        # Get rental data
        combined_df = self.fetch_table_data(
            connector_data=connector_data,
            logger=logger,
            fetch_params_dict=fetch_params_dict,
        )
        combined_df = add_synchronization_id(combined_df, connector_data)
        if combined_df.empty:
            return combined_df

        combined_df = get_business_units(
            combined_df,
            logger=logger,
            organization_name=connector_data.organization_name,
        )
        combined_df[VehiclesModel.model_category.name] = (
            mapper_factory(ModelCategories)(
                combined_df[VehiclesModel.model.name]
            )
        )

        # Deduplicate
        combined_df = self.deduplicate_vehicule(
            combined_df=combined_df,
            logger=logger,
        )
        combined_df = self.add_co2_data(
            vehicle_df=combined_df,
            co2_df=connector_data.get(
                connector_name=GreenNCapData.SOURCE_CONNECTOR,
                dataset_name=GreenNCapData.NAME,
                table_name=GreenNCapTables.carbon_per_model.value,
            ),
            logger=logger,
        )
        combined_df = self.fill_missing_cols(df=combined_df)

        return combined_df[self.return_column_names()]

    @staticmethod
    def add_co2_data(
        vehicle_df: pd.DataFrame,
        co2_df: pd.DataFrame,
        logger: logging.Logger,
    ):
        """ Complete missing CO2 information in the vehicle dataframe

        :param vehicle_df: the vehicle dataframe to complete
        :param co2_df: a source of CO2 information
        """
        co2_df = co2_df[
            [
                VehiclesModel.model.name,
                VehiclesModel.energy.name,
                VehiclesModel.CO2_production.name,
                VehiclesModel.CO2_recycling.name,
                VehiclesModel.theoretical_CO2_per_km.name,
                VehiclesModel.theoretical_fuel_consumption.name,
            ]
        ]
        co2_cols = [
            VehiclesModel.CO2_production,
            VehiclesModel.CO2_recycling,
            VehiclesModel.theoretical_CO2_per_km,
        ]
        for col in co2_cols:
            # Convert all to kg
            if col.post_processing:
                co2_df[col.name] = col.post_processing(co2_df[col.name])

        co2_df = co2_df.groupby(
            [VehiclesModel.model.name, VehiclesModel.energy.name]
        ).mean().reset_index()

        vehicle_df = vehicle_df.merge(
            right=co2_df,
            on=[VehiclesModel.model.name, VehiclesModel.energy.name],
            how='left',
            validate='m:1',
            indicator=True,
        )
        logger.info(
            '%d vehicles footprint could be found in CO2 data out of %d vehicles',
            (vehicle_df['_merge'] == 'both').sum(),
            len(vehicle_df),
        )

        # Compute energy means as second best substitute
        for co2_col, substitute_col in [
            (VehiclesModel.CO2_production.name, 'mean_energy_production'),
            (VehiclesModel.CO2_recycling.name, 'mean_energy_recycling'),
            (VehiclesModel.theoretical_CO2_per_km.name, 'mean_energy_usage'),
            (
                VehiclesModel.theoretical_fuel_consumption.name,
                'mean_energy_consumption'
            ),
        ]:
            if co2_col + '_x' in vehicle_df.columns:
                vehicle_df[co2_col] = vehicle_df[co2_col + '_x'].fillna(
                    vehicle_df[co2_col + '_y']
                )
                vehicle_df.drop(
                    columns=[co2_col + '_x', co2_col + '_y'],
                    axis=1,
                )
            vehicle_df[substitute_col] = vehicle_df.groupby(
                VehiclesModel.energy.name
            )[co2_col].transform('mean')
            vehicle_df[co2_col] = vehicle_df[co2_col].fillna(
                vehicle_df[substitute_col]
            )
            # As a last resort replace with mean
            vehicle_df[co2_col] = vehicle_df[co2_col].fillna(
                vehicle_df[co2_col].mean()
            )

        return vehicle_df

    def deduplicate_vehicule(
        self: typing.Self,
        combined_df: pd.DataFrame,
        logger: logging.Logger,
    ) -> pd.DataFrame:
        """ Deduplicate vehicule dataframe

        :param combined_df: DataFrame with licence_plate duplicates
        :param logger: logger

        :returns: deduplicated DataFrame
        """
        combined_df = combined_df[
            ~str_is_nan(combined_df[VehiclesModel.plate_number.name])
        ]
        if VehiclesModel.initial_mileage.name not in combined_df.columns:
            combined_df[VehiclesModel.initial_mileage.name] = 0
        assert pd.notna(combined_df[VehiclesModel.initial_mileage.name]).any()
        dedup_df = combined_df[[VehiclesModel.plate_number.name]].drop_duplicates()
        initial_plate_set = set(dedup_df[VehiclesModel.plate_number.name])
        record_col = SoonGoRecordsModel.record_date.name
        zero_date = datetime(year=1900, month=1, day=1)

        for col_name in self.return_column_names():

            if (
                col_name not in combined_df.columns or
                col_name == VehiclesModel.plate_number.name
            ):
                continue

            # Identify non nan values
            data_cols = [
                VehiclesModel.plate_number.name,
                col_name,
                record_col,
            ]
            subset_df = combined_df.loc[
                ~series_is_nan(combined_df[col_name]),
                data_cols,
            ].drop_duplicates(data_cols)

            # Deduplicate, keep only most recent records. Consider nan records as 0
            subset_df[record_col] = subset_df[record_col].fillna(zero_date)
            subset_df = keep_duplicates(
                duplicated_df=subset_df,
                unique_cols=[VehiclesModel.plate_number.name],
                selection_col=record_col,
                logger=logger,
            )

            # For BU or status if clash then replace with null (unknown)
            if col_name in [
                BusinessUnitsModel.business_unit.name,
                VehiclesModel.vehicle_status.name,
            ]:
                subset_df['dup_count'] = subset_df.groupby(
                    VehiclesModel.plate_number.name
                )[VehiclesModel.plate_number.name].transform('count')
                subset_df[col_name] = (
                    subset_df[col_name].mask(
                        subset_df['dup_count'] > 1,
                        ''
                    )
                )
                subset_df = subset_df.drop('dup_count', axis=1)
                subset_df = subset_df.drop_duplicates()

            # For mileage, possible multiple values for same day. Keep largest.
            mileage_cols = [
                MileageReportsModel.mileage.name,
                MileageReportsModel.mileage_date.name,
                VehiclesModel.initial_mileage.name,
            ]
            if col_name in mileage_cols:
                subset_df = keep_duplicates(
                    duplicated_df=subset_df[data_cols],
                    unique_cols=[VehiclesModel.plate_number.name],
                    selection_col=col_name,
                    logger=logger,
                )

            # For entry_into_service date or lease_start_date, keep earliest.
            if col_name in (
                VehiclesModel.entry_into_service_date.name,
                VehicleContractsModel.lease_start_date.name,
            ):
                subset_df = keep_duplicates(
                    duplicated_df=subset_df[data_cols],
                    unique_cols=[VehiclesModel.plate_number.name],
                    selection_col=col_name,
                    logger=logger,
                    selection_func='min',
                )

            # For end dates, keep latest.
            if col_name in (
                VehicleContractsModel.contract_end_date.name,
                VehicleContractsModel.lease_end_date.name,
            ):
                subset_df = keep_duplicates(
                    duplicated_df=subset_df[data_cols],
                    unique_cols=[VehiclesModel.plate_number.name],
                    selection_col=col_name,
                    logger=logger,
                    selection_func='max',
                )

            # For source_connector, dataset, and type, keep any
            if col_name in (
                SoonGoRecordsModel.source_connector.name,
                SoonGoRecordsModel.synchronisation_type.name,
                SoonGoRecordsModel.synchronisation_id.name,
            ):
                subset_df = subset_df.drop_duplicates(
                    subset=[col for col in subset_df.columns if col != col_name]
                )

            dup_plates = subset_df[VehiclesModel.plate_number.name].duplicated(
                keep=False,
            )
            if dup_plates.any():
                raise ValueError(
                    f'Duplicated values for {col_name}: '
                    f'{subset_df[VehiclesModel.plate_number.name].loc[dup_plates]}'
                )

            # Merge deduplicated column back into deduplicated df
            dedup_df = dedup_df.merge(
                right=subset_df[[VehiclesModel.plate_number.name, col_name]],
                on=VehiclesModel.plate_number.name,
                how='outer',
                indicator=True,
                validate='1:1',
            )
            assert dedup_df['_merge'].isin(['left_only', 'both']).all()
            dedup_df.drop('_merge', axis=1, inplace=True)

        assert dedup_df[VehiclesModel.plate_number.name].is_unique

        final_plate_set = set(dedup_df[VehiclesModel.plate_number.name])
        assert pd.notna(combined_df[VehiclesModel.initial_mileage.name]).any()
        assert final_plate_set == initial_plate_set
        return dedup_df


if __name__ == "__main__":
    logger = gen_logger('vehicle_table')
    organization_name = 'Acorus'
    root_folder = '/home/matthieuglotz/Documents/Data/'
    organization_folder = os.path.join(
        root_folder,
        organization_name,
    )
    connector_data = ConnectorData(
        root_folder=root_folder,
        organization_name=organization_name,
    )
    vehicle_table = VehiclesInputTable()
    vehicle_df = vehicle_table.get(
        connector_data=connector_data,
        logger=logger,
    )

    vehicle_table.check_columns(
        data_df=vehicle_df,
        logger=logger,
    )

    vehicle_df.to_csv(
        os.path.join(
            organization_folder,
            'webapp_tables',
            f'{vehicle_table.name}_table.csv',
        ),
        index=False,
        sep=';',
    )
