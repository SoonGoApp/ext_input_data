""" Script to calculate the incident table to load in database."""
import logging
import os
import typing

import pandas as pd

from data_models import (
    AccidentsModel, VehiclesModel, CollaboratorsModel, BusinessUnitsModel,
    SoonGoRecordsModel
)
from connectors.full_data import ConnectorData
from input_tables.vehicles_table import VehiclesInputTable
from input_tables.employees_table import EmployeesInputTable
from input_tables.table_utils import (
    InputColumn, InputTable, get_business_units, match_soongo_employee_id,
    add_synchronization_id
)
from sql_mappings import AccidentsTable
from utils.logging import gen_logger


class AccidentsInputTable(InputTable):

    def __init__(self: typing.Self):
        super().__init__(
            name='accidents',
            sql_mapping=AccidentsTable,
            date_col_name='accident_date',
            columns=[
                InputColumn.from_data_column(
                    column=AccidentsModel.accident_date,
                    format=r'\d{4}-\d{2}-\d{2}',
                    nullable=False,
                    is_id=True,
                ),
                InputColumn.from_data_column(
                    column=AccidentsModel.accident_ref,
                    is_id=True,
                ),
                InputColumn.from_data_column(
                    column=VehiclesModel.plate_number,
                    foreign_relationship=(
                        VehiclesInputTable().name,
                        VehiclesModel.plate_number.name,
                    ),
                    nullable=False,
                    is_id=True,
                ),
                InputColumn.from_data_column(
                    column=AccidentsModel.accident_type,  # ENUM capitalized
                ),
                InputColumn.from_data_column(
                    column=AccidentsModel.accident_context,  # ENUM capitalized
                ),
                InputColumn.from_data_column(
                    column=AccidentsModel.responsibility,  # ENUM capitalized
                ),
                InputColumn.from_data_column(
                    column=AccidentsModel.third_party,
                ),
                InputColumn.from_data_column(
                    column=AccidentsModel.insurer,
                ),
                InputColumn.from_data_column(
                    column=CollaboratorsModel.employee_id,
                    foreign_relationship=(
                        EmployeesInputTable().name,
                        CollaboratorsModel.employee_id.name,
                    ),
                    is_id=True,
                ),
                InputColumn.from_data_column(
                    column=BusinessUnitsModel.business_unit,
                    format=r'\w+(?: > \w+)*'
                ),
                InputColumn.from_data_column(
                    column=AccidentsModel.insurer_cost,
                    nullable=False,
                ),
                InputColumn.from_data_column(
                    column=AccidentsModel.self_insurance_cost,
                    nullable=False,
                ),
                InputColumn.from_data_column(
                    column=AccidentsModel.insurance_deductible_cost,
                ),
                InputColumn.from_data_column(
                    column=AccidentsModel.accident_status,
                ),
                InputColumn.from_data_column(
                    column=AccidentsModel.commute_accident,
                ),
                InputColumn.from_data_column(
                    column=AccidentsModel.weekend_accident,
                ),
                InputColumn.from_data_column(
                    column=AccidentsModel.accident_location,
                ),
                InputColumn.from_data_column(
                    column=SoonGoRecordsModel.source_connector,
                    nullable=False,
                ),
                InputColumn.from_data_column(
                    column=SoonGoRecordsModel.synchronisation_type,
                    nullable=False,
                ),
                InputColumn.from_data_column(
                    column=SoonGoRecordsModel.synchronisation_id,
                    nullable=False,
                ),
            ]
        )

    def get(
        self: typing.Self,
        connector_data: ConnectorData,
        logger: logging.Logger,
        fetch_params_dict: typing.Optional[dict] = None,
    ) -> pd.DataFrame:
        """ Get vehicle table for Go Measure inputting

        :param gac_data: GacData with all data imported from gac

        :return: pandas dataframe with all columns from the vehicle table
        """
        # Get rental data
        accident_df = self.fetch_table_data(
            connector_data=connector_data,
            logger=logger,
            fetch_params_dict=fetch_params_dict,
        )
        accident_df = add_synchronization_id(accident_df, connector_data)
        if accident_df.empty:
            return accident_df

        # Add soongo_employee_id and business unit
        accident_df = match_soongo_employee_id(
            table_to_match=accident_df,
            employee_table=EmployeesInputTable().get(
                connector_data=connector_data,
                logger=logger,
            )
        )
        if AccidentsModel.self_insurance_cost.name not in accident_df.columns:
            accident_df[AccidentsModel.self_insurance_cost.name] = 0.0
        if (
            AccidentsModel.insurance_deductible_cost.name
            not in accident_df.columns
        ):
            accident_df[AccidentsModel.insurance_deductible_cost.name] = (
                accident_df[AccidentsModel.organization_cost.name] -
                accident_df[AccidentsModel.self_insurance_cost.name]
            )

        if AccidentsModel.insurer_cost.name not in accident_df.columns:
            accident_df[AccidentsModel.insurer_cost.name] = (
                accident_df[AccidentsModel.total_accident_cost.name] -
                accident_df[AccidentsModel.organization_cost.name]
            )
        accident_df = get_business_units(
            accident_df,
            logger=logger,
            organization_name=connector_data.organization_name,
        )
        self.fill_missing_cols(df=accident_df)
        return accident_df[self.return_column_names()]


if __name__ == "__main__":
    logger = gen_logger('accident_table')
    organization_name = 'Acorus'
    root_folder = '/home/matthieuglotz/Documents/Data/'
    organization_folder = os.path.join(
        root_folder,
        organization_name,
    )
    connector_data = ConnectorData(
        root_folder=root_folder,
        organization_name=organization_name,
    )
    accident_table = AccidentsInputTable()
    accident_df = accident_table.get(
        connector_data=connector_data,
        logger=logger,
    )
    employee_table = EmployeesInputTable().get(
        connector_data=connector_data,
        logger=logger,
    )
    accident_table.check_columns(
        data_df=accident_df,
        employees=employee_table,
        vehicles=VehiclesInputTable().get(
            connector_data=connector_data,
            logger=logger,
        ),
        logger=logger,
    )
    accident_df.to_csv(
        os.path.join(
            organization_folder,
            'webapp_tables',
            f'{accident_table.name}_table.csv',
        ),
        index=False,
        sep=';',
    )
