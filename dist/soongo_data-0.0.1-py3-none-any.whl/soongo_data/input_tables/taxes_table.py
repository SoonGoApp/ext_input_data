""" Script to calculate the taxes table to load in database."""
import logging
import os
import typing

import pandas as pd

from data_models import (
    CollaboratorsModel, VehiclesModel, TaxesModel, BusinessUnitsModel,
    SoonGoRecordsModel
)
from connectors.full_data import ConnectorData
from input_tables.vehicles_table import VehiclesInputTable
from input_tables.employees_table import EmployeesInputTable
from input_tables.table_utils import (
    InputColumn, InputTable, get_business_units, match_soongo_employee_id,
    add_synchronization_id
)
from utils.logging import gen_logger
from sql_mappings import TaxesTable


class TaxesInputTable(InputTable):
    def __init__(self):
        super().__init__(
            name='taxes',
            sql_mapping=TaxesTable,
            date_col_name='billing_date',
            columns=[
                InputColumn.from_data_column(
                    column=CollaboratorsModel.employee_id,
                    foreign_relationship=(
                        EmployeesInputTable().name,
                        CollaboratorsModel.employee_id.name,
                    ),
                    is_id=True,
                ),
                InputColumn.from_data_column(
                    column=BusinessUnitsModel.business_unit,
                    format=r'\w+(?: > \w+)*',
                ),
                InputColumn.from_data_column(
                    column=VehiclesModel.plate_number,
                    foreign_relationship=(
                        VehiclesInputTable().name,
                        VehiclesModel.plate_number.name,
                    ),
                    is_id=True,
                ),
                InputColumn.from_data_column(
                    column=TaxesModel.billing_date,
                    is_id=True,
                ),
                InputColumn.from_data_column(
                    column=TaxesModel.declared_non_deductible_amortization,
                    is_id=True,
                ),
                InputColumn.from_data_column(
                    column=TaxesModel.tax_vehicle_age,
                    is_id=True,
                ),
                InputColumn.from_data_column(
                    column=TaxesModel.tax_corporate_vehicles,
                    is_id=True,
                ),
                InputColumn.from_data_column(
                    column=TaxesModel.tax_CO2_emission,
                    is_id=True,
                ),
                InputColumn.from_data_column(
                    column=SoonGoRecordsModel.source_connector,
                    nullable=False,
                ),
                InputColumn.from_data_column(
                    column=SoonGoRecordsModel.synchronisation_type,
                    nullable=False,
                ),
                InputColumn.from_data_column(
                    column=SoonGoRecordsModel.synchronisation_id,
                    nullable=False,
                ),
            ],
        )

    def get(
        self: typing.Self,
        connector_data: ConnectorData,
        logger: logging.Logger,
        fetch_params_dict: typing.Optional[dict] = None,
    ) -> pd.DataFrame:
        """ Get vehicle table for Go Measure inputting

        :param gac_data: GacData with all data imported from gac

        :return: pandas dataframe with all columns from the vehicle table
        """
        tax_cols = self.return_column_names()
        employee_table = EmployeesInputTable().get(
            connector_data=connector_data,
            logger=logger,
            fetch_params_dict=fetch_params_dict,
        )
        # Get tax data
        combined_df = self.fetch_table_data(
            connector_data=connector_data,
            logger=logger,
        )
        combined_df = add_synchronization_id(combined_df, connector_data)
        if combined_df.empty:
            return combined_df

        combined_df = get_business_units(
            combined_df,
            logger=logger,
            organization_name=connector_data.organization_name,
        )
        combined_df = match_soongo_employee_id(
            table_to_match=combined_df,
            employee_table=employee_table,
        )

        combined_df[TaxesModel.billing_date.name] = self.gen_billing_date(
            combined_df
        )

        # Some rows have no taxes (year was specified but no info)
        combined_df = self.fill_missing_cols(
            df=combined_df,
        )
        combined_df = combined_df.loc[
            pd.notna(combined_df[[
                TaxesModel.declared_non_deductible_amortization.name,
                TaxesModel.tax_vehicle_age.name,
                TaxesModel.tax_corporate_vehicles.name,
                TaxesModel.tax_CO2_emission.name,
            ]]).any(axis=1)
        ]
        return combined_df[tax_cols]

    @staticmethod
    def gen_billing_date(tax_df: pd.DataFrame) -> pd.Series:
        """ Returns the last day of the year for the years in Series."""
        if TaxesModel.billing_date.name not in tax_df.columns:
            tax_df[TaxesModel.billing_date.name] = pd.NaT

        if TaxesModel.ikb_period_start.name in tax_df.columns:
            tax_df[TaxesModel.billing_date.name] = (
                tax_df[TaxesModel.billing_date.name].fillna(
                    tax_df[TaxesModel.ikb_period_start.name]
                )
            )
            assert pd.notna(
                tax_df.loc[
                    pd.notna(tax_df[TaxesModel.ikb_period_start.name]),
                    TaxesModel.billing_date.name
                ]
            ).all()

        if TaxesModel.quarter.name in tax_df.columns:
            assert TaxesModel.year.name in tax_df.columns
            quarter_dict = {
                'Trimestre 1': '01',
                'Trimestre 2': '04',
                'Trimestre 3': '07',
                'Trimestre 4': '10',
            }
            tax_df[TaxesModel.billing_date.name] = (
                tax_df[TaxesModel.billing_date.name].fillna(
                    pd.to_datetime(
                        (
                            tax_df[TaxesModel.year.name].fillna('').astype(str)
                            + '-' +
                            tax_df[TaxesModel.quarter.name].map(quarter_dict) +
                            '-01'
                        ),
                        format=r'%Y-%m-%d',
                    ),
                )
            )
            assert pd.notna(
                tax_df.loc[
                    pd.notna(tax_df[TaxesModel.quarter.name]) &
                    pd.notna(tax_df[TaxesModel.year.name]),
                    TaxesModel.billing_date.name
                ]
            ).all()

        if TaxesModel.year.name in tax_df.columns:
            tax_df[TaxesModel.billing_date.name] = (
                tax_df[TaxesModel.billing_date.name].fillna(
                    pd.to_datetime(
                        tax_df[TaxesModel.year.name].astype(str) + '-12-31',
                        format=r'%Y-%m-%d',
                    ),
                )
            )
            assert pd.notna(
                tax_df.loc[
                    pd.notna(tax_df[TaxesModel.year.name]),
                    TaxesModel.billing_date.name
                ]
            ).all()

        return tax_df[TaxesModel.billing_date.name]


if __name__ == "__main__":
    logger = gen_logger('taxes_table')
    organization_name = 'Domino'
    root_folder = '/home/matthieuglotz/Documents/Data/'
    organization_folder = os.path.join(
        root_folder,
        organization_name,
    )
    connector_data = ConnectorData(
        root_folder=root_folder,
        organization_name=organization_name,
    )
    taxes_table = TaxesInputTable()
    taxes_df = taxes_table.get(
        connector_data=connector_data,
        logger=logger,
    )
    taxes_table.check_columns(
        data_df=taxes_df,
        employees=EmployeesInputTable(
            connector_data=connector_data,
            logger=logger,
        ),
        vehicles=VehiclesInputTable(
            connector_data=connector_data,
            logger=logger,
        ),
        logger=logger,
    )
    taxes_df.to_csv(
        os.path.join(
            organization_folder,
            'webapp_tables',
            f'{taxes_table.name}_table.csv',
        ),
        index=False,
        sep=';',
    )
