""" Script to calculate the baseline kpis on which to compute impacts."""
import logging
import os
import typing

import pandas as pd

from data_models import (
    ExpensesModel, VehiclesModel, CollaboratorsModel, BusinessUnitsModel,
    FuelCardsModel, SoonGoRecordsModel
)
from connectors.full_data import ConnectorData
from input_tables.employees_table import EmployeesInputTable
from input_tables.expense_utils import infer_amounts_and_tax
from input_tables.table_utils import (
    InputColumn, InputTable, get_business_units, match_soongo_employee_id,
    add_synchronization_id
)
from input_tables.vehicles_table import VehiclesInputTable
from sql_mappings import ExpensesTable

from utils.logging import gen_logger


class ExpensesInputTable(InputTable):

    def __init__(self):
        super().__init__(
            name='expenses',
            sql_mapping=ExpensesTable,
            date_col_name='billing_date',
            columns=[
                InputColumn.from_data_column(
                    column=ExpensesModel.expense_reference,
                    is_id=True,
                ),
                InputColumn.from_data_column(
                    column=ExpensesModel.supplier,
                ),
                InputColumn.from_data_column(
                    column=ExpensesModel.billing_date,
                    nullable=False,
                    format=r'\d{4}-\d{2}-\d{2}',
                    is_id=True,
                ),
                InputColumn.from_data_column(
                    column=ExpensesModel.amount_tax_exc,
                    nullable=False,
                    is_id=True,
                ),
                InputColumn.from_data_column(
                    column=ExpensesModel.net_amount,
                    nullable=False,
                ),
                InputColumn.from_data_column(
                    column=VehiclesModel.plate_number,
                    foreign_relationship=(
                        VehiclesInputTable().name,
                        VehiclesModel.plate_number.name,
                    ),
                    is_id=True,
                ),
                InputColumn.from_data_column(
                    column=ExpensesModel.vat_amount,
                ),
                InputColumn.from_data_column(
                    column=ExpensesModel.deductible_vat,
                    nullable=False,
                ),
                InputColumn.from_data_column(
                    column=CollaboratorsModel.employee_id,
                    foreign_relationship=(
                        EmployeesInputTable().name,
                        CollaboratorsModel.employee_id.name,
                    ),
                    is_id=True,
                ),
                InputColumn.from_data_column(
                    column=BusinessUnitsModel.business_unit,
                    format=r'\w+(?: > \w+)*',
                ),
                InputColumn.from_data_column(
                    column=ExpensesModel.expense_category,
                    nullable=False,
                    is_id=True,
                ),
                InputColumn.from_data_column(
                    column=ExpensesModel.quantity,
                    nullable=True,
                ),
                InputColumn.from_data_column(
                    column=FuelCardsModel.fuel_card_ref,
                ),
                InputColumn.from_data_column(
                    column=SoonGoRecordsModel.source_connector,
                    nullable=False,
                ),
                InputColumn.from_data_column(
                    column=SoonGoRecordsModel.synchronisation_type,
                    nullable=False,
                ),
                InputColumn.from_data_column(
                    column=SoonGoRecordsModel.synchronisation_id,
                    nullable=False,
                ),
            ],
        )

    def get(
        self: typing.Self,
        connector_data: ConnectorData,
        logger: logging.Logger,
        fetch_params_dict: typing.Optional[dict] = None,
    ) -> pd.DataFrame:
        """ Get baseline fleet kpis for impact calculation

        :param gac_data: GacData with all data imported from gac
        :param havas_data: HavasData with all data imported from Havas
        :param logger: logger

        :return: pandas dataframe with kpis at vehicule level
        """
        expenses_df = self.fetch_table_data(
            connector_data=connector_data,
            logger=logger,
            fetch_params_dict=fetch_params_dict,
        )
        expenses_df = add_synchronization_id(expenses_df, connector_data)
        if expenses_df.empty:
            return expenses_df

        expenses_df = infer_amounts_and_tax(
            df=expenses_df,
            logger=logger,
            connector_data=connector_data,
            date_var=ExpensesModel.billing_date.name,
        )
        expenses_df = get_business_units(
            expenses_df,
            logger=logger,
            organization_name=connector_data.organization_name,
        )
        expenses_df = match_soongo_employee_id(
            table_to_match=expenses_df,
            employee_table=EmployeesInputTable().get(
                connector_data=connector_data,
                logger=logger,
            ),
        )
        expenses_df = self.fill_missing_cols(df=expenses_df)

        return expenses_df[self.return_column_names()]


if __name__ == "__main__":

    logger = gen_logger('expense_table')
    organization_name = 'Domino'
    root_folder = '/home/matthieuglotz/Documents/Data/'
    organization_folder = os.path.join(
        root_folder,
        organization_name,
    )
    connector_data = ConnectorData(
        root_folder=root_folder,
        organization_name=organization_name,
    )

    expense_table = ExpensesInputTable()
    expense_df = expense_table.get(
        connector_data=connector_data,
        logger=logger,
    )
    expense_table.check_columns(
        data_df=expense_df,
        employees=EmployeesInputTable().get(
            connector_data=connector_data,
            logger=logger,
        ),
        vehicles=VehiclesInputTable().get(
            connector_data=connector_data,
            logger=logger,
        ),
        logger=logger,
    )
    expense_df.to_csv(
        os.path.join(
            organization_folder,
            'webapp_tables',
            f'{expense_table.name}_table.csv',
        ),
        index=False,
        sep=';',
    )
