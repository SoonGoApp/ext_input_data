""" Script to calculate the incident table to load in database."""
import logging
import os
import typing

import pandas as pd

from connectors.full_data import ConnectorData
from data_models import RentalCarsModel, CollaboratorsModel, SoonGoRecordsModel
from input_tables.expense_utils import infer_amounts_and_tax
from input_tables.employees_table import EmployeesInputTable
from input_tables.table_utils import (
    InputColumn, InputTable, match_soongo_employee_id, add_synchronization_id
)
from utils.logging import gen_logger
from utils.enums import TravelTypes
from sql_mappings import RentalCarsTable


class RentalCarsInputTable(InputTable):
    def __init__(self: typing.Self):
        super().__init__(
            name='rental_cars',
            sql_mapping=RentalCarsTable,
            date_col_name='billing_date',
            columns=[
                InputColumn.from_data_column(
                    column=RentalCarsModel.expense_id,
                    unique=True,
                    is_id=True,
                ),
                InputColumn.from_data_column(
                    column=RentalCarsModel.booking_date,
                    format=r'\d{4}-\d{2}-\d{2}',
                    nullable=False,
                    is_id=True,
                ),
                InputColumn.from_data_column(
                    column=RentalCarsModel.billing_date,
                    format=r'\d{4}-\d{2}-\d{2}',
                ),
                InputColumn.from_data_column(
                    column=CollaboratorsModel.employee_id,
                    foreign_relationship=(
                        EmployeesInputTable().name,
                        CollaboratorsModel.employee_id.name,
                    ),
                    is_id=True,
                ),
                InputColumn.from_data_column(
                    column=RentalCarsModel.supplier,
                ),
                InputColumn.from_data_column(
                    column=RentalCarsModel.car_segment,
                ),
                InputColumn.from_data_column(
                    column=RentalCarsModel.car_type,
                ),
                InputColumn.from_data_column(
                    column=RentalCarsModel.start_city,
                    nullable=False,
                ),
                InputColumn.from_data_column(
                    column=RentalCarsModel.start_country_name,
                    nullable=False,
                ),
                InputColumn.from_data_column(
                    column=RentalCarsModel.arrival_city,
                    nullable=False,
                ),
                InputColumn.from_data_column(
                    column=RentalCarsModel.arrival_country_name,
                    nullable=False,
                ),
                InputColumn.from_data_column(
                    column=RentalCarsModel.start_datetime,
                    nullable=False,
                    format=r'\d{4}-\d{2}-\d{2}',
                ),
                InputColumn.from_data_column(
                    column=RentalCarsModel.end_datetime,
                    nullable=False,
                    format=r'\d{4}-\d{2}-\d{2}',
                ),
                InputColumn.from_data_column(
                    column=RentalCarsModel.amount_tax_exc,
                    is_id=True,
                ),
                InputColumn.from_data_column(
                    column=RentalCarsModel.deductible_vat,
                ),
                InputColumn.from_data_column(
                    column=RentalCarsModel.net_amount,
                ),
                InputColumn.from_data_column(
                    column=RentalCarsModel.amount_fees,
                ),
                InputColumn.from_data_column(
                    column=SoonGoRecordsModel.source_connector,
                    nullable=False,
                ),
                InputColumn.from_data_column(
                    column=SoonGoRecordsModel.synchronisation_type,
                    nullable=False,
                ),
                InputColumn.from_data_column(
                    column=SoonGoRecordsModel.synchronisation_id,
                    nullable=False,
                ),
            ],
        )

    def get(
        self: typing.Self,
        connector_data: ConnectorData,
        logger: logging.Logger,
        fetch_params_dict: typing.Optional[dict] = None,
    ) -> pd.DataFrame:
        """ Get vehicle table for Go Measure inputting

        :param gac_data: GacData with all data imported from gac

        :return: pandas dataframe with all columns from the vehicle table
        """
        # Get rental data
        rental_car_df = self.fetch_table_data(
            connector_data=connector_data,
            logger=logger,
            fetch_params_dict=fetch_params_dict,
        )
        rental_car_df = add_synchronization_id(rental_car_df, connector_data)
        if rental_car_df.empty:
            return rental_car_df

        rental_car_df = infer_amounts_and_tax(
            df=rental_car_df,
            logger=logger,
            connector_data=connector_data,
            date_var=RentalCarsModel.billing_date.name,
        )
        if RentalCarsModel.travel_type.name in rental_car_df.columns:
            rental_car_df = rental_car_df.loc[
                (
                    rental_car_df[RentalCarsModel.travel_type.name] ==
                    TravelTypes.rental_car.value
                ),
            ]

        # Add soongo_employee_id and business unit
        rental_car_df = match_soongo_employee_id(
            table_to_match=rental_car_df,
            employee_table=EmployeesInputTable().get(
                connector_data=connector_data,
                logger=logger,
            )
        )
        rental_car_df = self.fill_missing_cols(
            df=rental_car_df,
        )

        return rental_car_df[self.return_column_names()]


if __name__ == "__main__":
    logger = gen_logger('rental_cars_table')
    organization_name = 'Acorus'
    root_folder = '/home/matthieuglotz/Documents/Data/'
    organization_folder = os.path.join(
        root_folder,
        organization_name,
    )
    connector_data = ConnectorData(
        root_folder=root_folder,
        organization_name=organization_name,
    )
    rental_car_table = RentalCarsInputTable()
    rental_car_df = rental_car_table.get(
        connector_data=connector_data,
        logger=logger,
    )
    rental_car_table.check_columns(
        data_df=rental_car_df,
        employees=EmployeesInputTable().get(
            connector_data=connector_data,
            logger=logger,
        ),
        logger=logger,
    )
    rental_car_df.to_csv(
        os.path.join(
            organization_folder,
            'webapp_tables',
            f'{rental_car_table.name}_table.csv',
        ),
        index=False,
        sep=';',
    )
