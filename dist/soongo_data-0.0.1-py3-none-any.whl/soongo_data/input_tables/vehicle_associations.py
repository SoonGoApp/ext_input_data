""" Script to calculate the vehicle association table."""
import os
import logging
from datetime import date
import typing

import numpy as np
import pandas as pd

from connectors.full_data import ConnectorData
from data_models import (
    VehicleAssociationsModel, VehiclesModel, VehicleContractsModel,
    CollaboratorsModel, ExpensesModel, SoonGoRecordsModel
)
from input_tables.employees_table import EmployeesInputTable
from input_tables.table_utils import (
    InputColumn, InputTable, match_soongo_employee_id,
    fetch_organization_params, combine_connector_data,
    NoMatchedTable, add_synchronization_id
)
from input_tables.vehicles_table import VehiclesInputTable
from utils.logging import gen_logger
from utils.type import series_is_nan
from utils.enums import CostCategory
from sql_mappings import VehicleAttributionsTable

pd.set_option('future.no_silent_downcasting', True)

# Define abbreviations (purely stylistic)
PLATE_COL = VehiclesModel.plate_number.name
EMPLOYEE_COL = CollaboratorsModel.employee_id.name
ASSOCIATION_START = VehicleAssociationsModel.association_start_date.name
ASSOCIATION_END = VehicleAssociationsModel.association_end_date.name
ASSOCIATION_COLS = [
    PLATE_COL,
    EMPLOYEE_COL,
]


class VehicleAssociationsInputTable(InputTable):

    def __init__(self):
        super().__init__(
            name='vehicle_associations',
            sql_mapping=VehicleAttributionsTable,
            date_col_name='billing_date',
            columns=[
                InputColumn.from_data_column(
                    column=VehiclesModel.plate_number,
                    nullable=False,
                    foreign_relationship=(
                        VehiclesInputTable().name,
                        PLATE_COL,
                    ),
                    is_id=True,
                ),
                InputColumn.from_data_column(
                    column=CollaboratorsModel.employee_id,
                    foreign_relationship=(
                        EmployeesInputTable().name,
                        EMPLOYEE_COL,
                    ),
                    is_id=True,
                ),
                InputColumn.from_data_column(
                    column=VehicleAssociationsModel.assigned_service,
                ),
                InputColumn.from_data_column(
                    column=VehicleAssociationsModel.association_start_date,
                    is_id=True,
                ),
                InputColumn.from_data_column(
                    column=VehicleAssociationsModel.association_end_date,
                    is_id=True,
                ),
                InputColumn.from_data_column(
                    column=VehicleAssociationsModel.daily_participation,
                ),
                InputColumn.from_data_column(
                    column=SoonGoRecordsModel.source_connector,
                    nullable=False,
                ),
                InputColumn.from_data_column(
                    column=SoonGoRecordsModel.synchronisation_type,
                    nullable=False,
                ),
                InputColumn.from_data_column(
                    column=SoonGoRecordsModel.synchronisation_id,
                    nullable=False,
                ),
            ],
        )

    def get(
        self: typing.Self,
        connector_data: ConnectorData,
        logger: logging.Logger,
        fetch_params_dict: typing.Optional[dict] = None,
    ) -> pd.DataFrame:
        """ Get vehicle assignment table.

        Works by first fetch all data on financial rent, checking if a collaborator
        was associated with a plate on that rent, deducting from this data the
        start date and end date for which the car was assigned to the collaborator.
        It then combines that data with other association start and end date source
        from the connectors. Information which specifies the name of the driver
        takes priority over information for which it is unknown or unassigned.

        :param connector_data: full connector data

        :return: pandas dataframe with all columns from the vehicle table
        """
        # Fetch data
        org_associations_params = fetch_organization_params(
            connector_data.organization_name
        )['vehicle_associations']
        association_df = self.fetch_table_data(
            connector_data=connector_data,
            logger=logger,
            fetch_params_dict=fetch_params_dict,
        )
        if association_df.empty:
            return association_df
        association_df = association_df[~series_is_nan(association_df[PLATE_COL])]

        # Add soongo employee id and daily participation data
        employee_table = EmployeesInputTable().get(
            connector_data=connector_data,
            logger=logger,
        )
        association_df = match_soongo_employee_id(
            table_to_match=association_df,
            employee_table=employee_table,
        )
        association_df.drop(
            columns=[
                CollaboratorsModel.employee_full_name.name,
                CollaboratorsModel.organization_employee_id.name,
            ],
            inplace=True,
        )

        # Get association start_date first from financial rent
        if org_associations_params.get('infer'):
            rent_df = self.get_rent_df(association_df, logger=logger)

            # Complete missing associations with association from rent df
            for col in [ASSOCIATION_START, ASSOCIATION_END]:
                if col in association_df.columns:
                    association_df = association_df.loc[
                        ~series_is_nan(association_df[col]),
                    ]
                else:
                    association_df[col] = pd.NaT

            association_df = self.redress_rent_data(
                rent_df=rent_df,
                association_df=association_df,
            )

        # Redress series which follow one other
        association_df['unique_drivers'] = association_df.groupby(
            PLATE_COL
        )[EMPLOYEE_COL].transform(lambda x: x.nunique(dropna=False))
        association_df['min_start_date'] = association_df.groupby(
            PLATE_COL
        )[ASSOCIATION_START].transform('min')
        end_date_filler = pd.Timestamp(date.today())
        association_df['temp_end_date'] = association_df[ASSOCIATION_END].fillna(end_date_filler)
        association_df['max_end_date'] = association_df.groupby(
            PLATE_COL
        )['temp_end_date'].transform('max')
        association_df[ASSOCIATION_START] = association_df[ASSOCIATION_START].mask(
            association_df['unique_drivers'] == 1,
            association_df['min_start_date'],
        )
        association_df[ASSOCIATION_END] = association_df[ASSOCIATION_END].mask(
            association_df['unique_drivers'] == 1,
            association_df['max_end_date'].mask(
                association_df['max_end_date'] == end_date_filler,
                pd.NaT,
            ),
        )

        # Cap using lease_date
        if org_associations_params.get('cap_lease_end_date'):
            vehicle_df = VehiclesInputTable().get(
                connector_data=connector_data,
                logger=logger,
            )
            association_df = association_df.merge(
                right=vehicle_df[
                    [PLATE_COL, VehicleContractsModel.lease_end_date.name]
                ],
                on=PLATE_COL,
                how='left',
                validate='m:1',
                indicator=False
            )
            association_df[ASSOCIATION_END] = (
                association_df[ASSOCIATION_END].mask(
                    ~series_is_nan(association_df[ASSOCIATION_END]) &
                    ~series_is_nan(
                        association_df[CollaboratorsModel.employee_id.name]
                    ) &
                    (
                        association_df[VehicleContractsModel.lease_end_date.name] <
                        association_df[ASSOCIATION_END]
                    ),
                    association_df[VehicleContractsModel.lease_end_date.name]
                )
            )

        if (
            VehicleAssociationsModel.daily_participation.name
            not in association_df.columns
        ):
            association_df = self.get_daily_participation_data(
                association_df=association_df,
                connector_data=connector_data,
                logger=logger,
                employee_table=employee_table,
            )

        # Check data
        association_df = add_synchronization_id(association_df, connector_data)
        association_df = self.fill_missing_cols(
            df=association_df,
        )
        unique_associations = association_df[
            self.return_column_names()
        ].drop_duplicates(
            ASSOCIATION_COLS + [
                ASSOCIATION_START,
                ASSOCIATION_END,
                VehicleAssociationsModel.assigned_service.name,
                VehicleAssociationsModel.daily_participation.name,
                ]
        )

        self.check_dates(unique_associations)

        inconsistent_dates = (
            unique_associations[ASSOCIATION_START] >
            unique_associations[ASSOCIATION_END]
        )

        if inconsistent_dates.any():
            inconsistent_ids = unique_associations[
                inconsistent_dates
            ].drop_duplicates()
            raise ValueError(
                'Incoherent association values for the following association ids'
                f' {inconsistent_ids}'
            )

        return unique_associations.loc[
            ~series_is_nan(unique_associations[ASSOCIATION_START]),  # mandatory
            self.return_column_names()
        ]

    @staticmethod
    def consolidate_associations(
        association_df: pd.DataFrame
    ) -> pd.DataFrame:
        """ Consolidate_associations when same employee and car appear several
        times consecutively.

        :param associations_df: Dataframe with an association_start_date and
        end_date

        :returns: association_df
        """
        # Inefficient solution - loop across rows
        association_df = association_df.sort_values(
            by=[PLATE_COL, EMPLOYEE_COL, ASSOCIATION_START, ASSOCIATION_END],
        )
        true_start = pd.repeat([pd.NaT], repeats=len(association_df))
        true_start.index = association_df.index
        true_end = pd.repeat([pd.NaT], repeats=len(association_df))
        true_end.index = association_df.index
        previous_row = association_df.iloc[0, :]
        for index, row in association_df.iterrows():

            # Correct current row
            if (
                (row[ASSOCIATION_START] <= previous_row[ASSOCIATION_END]) &
                (row[PLATE_COL] == previous_row[PLATE_COL]) &
                (row[EMPLOYEE_COL] == previous_row[EMPLOYEE_COL]) &
                pd.notna(row[ASSOCIATION_START]) &
                pd.notna(previous_row[ASSOCIATION_END])
            ):
                true_start[index] = previous_row[ASSOCIATION_START]
                true_end[index] = row[ASSOCIATION_END]
                true_start[index-1] = previous_row[ASSOCIATION_START]
                true_end[index-1] = row[ASSOCIATION_END]

            previous_row = row

        for date_col, true_col in [
            (ASSOCIATION_START, true_start),
            (ASSOCIATION_END, true_end),
        ]:
            association_df[date_col] = association_df[date_col].where(
                pd.isna(true_col),
                true_col,
            )
        return association_df.drop_duplicates()

    @staticmethod
    def get_daily_participation_data(
        association_df: pd.DataFrame,
        connector_data: ConnectorData,
        logger: logging.Logger,
        employee_table: pd.DataFrame,
    ) -> pd.DataFrame:
        """ Get daily participation data and add it to the dataframe

        :param association_df: pd.DataFrame with all association information
        :param connector_data: connector_data object for the organization
        :param logger: logger
        """
        organization_params = fetch_organization_params(
            connector_data.organization_name,
        )
        table_params = organization_params['vehicle_associations']
        try:
            daily_participation_df = combine_connector_data(
                connector_data=connector_data,
                logger=logger,
                **table_params['daily_participation_params'],
            )
        except NoMatchedTable:
            return association_df
        if (
            VehicleAssociationsModel.daily_participation.name
            not in daily_participation_df.columns
        ):
            return association_df

        daily_participation_df = match_soongo_employee_id(
            table_to_match=daily_participation_df,
            employee_table=employee_table,
        )
        daily_participation_df.dropna(
            subset=[
                VehicleAssociationsModel.daily_participation.name,
                EMPLOYEE_COL,
            ],
            inplace=True,
        )
        association_df = association_df.merge(
            right=daily_participation_df[
                ASSOCIATION_COLS +
                [VehicleAssociationsModel.daily_participation.name]
            ],
            on=ASSOCIATION_COLS,
            how='left',
            validate='m:1',
            indicator=False,
        )
        return association_df

    @classmethod
    def get_rent_df(
        cls: typing.Self,
        association_df: pd.DataFrame,
        logger: logging.Logger,
    ) -> pd.DataFrame:
        """ Deduct assocation start and end date from financial rent payments

        :param association_df: DataFrame with all association information

        :return: DataFrame with updated start and end date information
        """
        # TODO: consider dropping financial rent entries which sum to 0 for the
        # same period start period end, driver, and car - possible error correction
        if not (
            {
                ExpensesModel.amount_tax_exc.name,
                ExpensesModel.amount_tax_inc,
            }.intersection(association_df.columns)
        ):
            raise ValueError(
                'Need at least one amount column amongst amount_tax_exc and '
                'amount_tax_inc.'
            )
        if ExpensesModel.amount_tax_exc.name in association_df.columns:
            amount_series = association_df[ExpensesModel.amount_tax_exc.name]
        if ExpensesModel.amount_tax_inc in association_df.columns:
            amount_series = amount_series.fillna(
                association_df[ExpensesModel.amount_tax_inc.name]
            )

        association_df = cls.get_rent_dates(association_df)

        rent_df = association_df.loc[
            (
                association_df[ExpensesModel.expense_category.name] ==
                CostCategory.financial_rent.value
            ) & (amount_series > 0)
        ]
        rent_df.sort_values(
            by=[
                PLATE_COL,
                'temp_rent_start',
            ],
            ascending=True,
            inplace=True,
        )
        rent_df['previous_driver'] = rent_df.groupby(
            PLATE_COL
        )[EMPLOYEE_COL].shift()
        rent_df['driver_change'] = np.where(
            (rent_df[EMPLOYEE_COL] == rent_df['previous_driver']).fillna(False) |
            (pd.isna(rent_df['previous_driver']) & pd.isna(rent_df[PLATE_COL])),
            0,
            1,
        )
        rent_df['association_id'] = rent_df.groupby(
            PLATE_COL
        )['driver_change'].cumsum()
        rent_df['association_id'] = (
            rent_df[PLATE_COL] + '_' + rent_df['association_id'].astype(str)
        )
        rent_df[ASSOCIATION_START] = rent_df.groupby(
            'association_id'
        )['temp_rent_start'].transform('min')

        rent_df[ASSOCIATION_END] = rent_df.groupby(
            'association_id'
        )['temp_rent_end'].transform('max')

        rent_df = rent_df.drop_duplicates(
            subset=ASSOCIATION_COLS + [ASSOCIATION_START, ASSOCIATION_END]
        )

        # Drop inconsistencies in rent period if driver is not specified
        previous_plate = rent_df[PLATE_COL].shift()
        previous_end_date = rent_df[ASSOCIATION_END].shift()
        inconsistent_mask = (
            series_is_nan(rent_df[EMPLOYEE_COL]) &
            (previous_plate == rent_df[PLATE_COL]) &
            (previous_end_date > rent_df[ASSOCIATION_START])
        )
        logger.warning(
            'Dropping %d inconsistent rent entries',
            inconsistent_mask.sum()
        )

        return rent_df.loc[~inconsistent_mask, ]

    @staticmethod
    def redress_rent_data(
        rent_df: pd.DataFrame,
        association_df: pd.DataFrame,
    ) -> pd.DataFrame:
        """ Enrich rent_data using all other recorded association_dates

        TODO: have a priority rule so that financial rent if emp not specified
        is not a priority over specified associations

        :param rent_df: Association dataframe built on rent data
        :param association_df: association_df with all association_data
        """
        rent_df['min_rent_date'] = rent_df.groupby(
            PLATE_COL
        )[ASSOCIATION_START].transform('min')
        rent_df['max_rent_date'] = rent_df.groupby(
            PLATE_COL
        )[ASSOCIATION_END].transform('max')
        rent_associations = rent_df[
            [PLATE_COL, 'min_rent_date', 'max_rent_date']
        ].drop_duplicates()
        association_df = association_df.merge(
            right=rent_associations,
            how='left',
            on=PLATE_COL,
            validate='m:1',
            indicator=True,
        )
        association_df = association_df.loc[
            (association_df['_merge'] == 'left_only') |
            (association_df[ASSOCIATION_START] < association_df['min_rent_date']) |
            (association_df[ASSOCIATION_END] > association_df['max_rent_date'])
        ]

        # Handle conflicts - financial rent information prevails.
        # If association start is after rent start, then association_end must be after
        # rent end, and association_start is moved to after the period covered by rent
        # Reciprocally when association_end is before rend end, then it is moved
        # to before the period covered by the rent
        association_df[ASSOCIATION_START] = association_df[ASSOCIATION_START].mask(
            association_df[ASSOCIATION_START] > association_df['min_rent_date'],
            association_df['max_rent_date']
        )
        association_df[ASSOCIATION_END] = association_df[ASSOCIATION_END].mask(
            association_df[ASSOCIATION_END] < association_df['max_rent_date'],
            association_df['min_rent_date']
        )

        # Handle association A interval fully contained in association B case
        association_df = pd.concat(
            [rent_df, association_df]
        )
        association_df.sort_values(
            by=[
                PLATE_COL,
                ASSOCIATION_START,
                ASSOCIATION_END,
            ],
            ascending=True,
            inplace=True,
        )
        errors = True
        i = 0
        while errors and i < 13:
            previous_row_df = association_df.shift(1)
            next_row_df = association_df.shift(-1)

            # Update based on the previous row
            same_previous_plate = (
                (previous_row_df[PLATE_COL] == association_df[PLATE_COL]) &
                ~series_is_nan(previous_row_df[PLATE_COL]) &
                ~series_is_nan(association_df[PLATE_COL])
            ) | (
                series_is_nan(previous_row_df[PLATE_COL]) &
                series_is_nan(association_df[PLATE_COL])
            )

            same_previous_employee = (
                (previous_row_df[EMPLOYEE_COL] == association_df[EMPLOYEE_COL]) &
                ~series_is_nan(previous_row_df[EMPLOYEE_COL]) &
                ~series_is_nan(association_df[EMPLOYEE_COL])
            ) | (
                series_is_nan(previous_row_df[EMPLOYEE_COL]) &
                series_is_nan(association_df[EMPLOYEE_COL])
            )

            start_before_previous_end = (
                (association_df[ASSOCIATION_START] <= previous_row_df[ASSOCIATION_END]) |
                series_is_nan(previous_row_df[ASSOCIATION_END])
            )

            start_after_previous_start = (
                association_df[ASSOCIATION_START] < previous_row_df[ASSOCIATION_START]
            )

            # Combine associations when same car / employee pair
            same_previous = same_previous_plate & same_previous_employee
            association_df.loc[
                same_previous & start_before_previous_end,
                ASSOCIATION_START,
            ] = previous_row_df.loc[
                same_previous & start_before_previous_end,
                ASSOCIATION_START,
            ]

            # Start ends up < previous start only when previous start updated
            # by the end date of the last change of driver. Update start date
            association_df.loc[
                same_previous & start_after_previous_start,
                ASSOCIATION_START,
            ] = previous_row_df.loc[
                same_previous & start_after_previous_start,
                ASSOCIATION_START,
            ]

            # Create to update based on the previous row
            same_future_plate = (
                (next_row_df[PLATE_COL] == association_df[PLATE_COL]) &
                ~series_is_nan(next_row_df[PLATE_COL]) &
                ~series_is_nan(association_df[PLATE_COL])
            ) | (
                series_is_nan(next_row_df[PLATE_COL]) &
                series_is_nan(association_df[PLATE_COL])
            )

            same_future_employee = (
                (next_row_df[EMPLOYEE_COL] == association_df[EMPLOYEE_COL]) &
                ~series_is_nan(next_row_df[EMPLOYEE_COL]) &
                ~series_is_nan(association_df[EMPLOYEE_COL])
            ) | (
                series_is_nan(next_row_df[EMPLOYEE_COL]) &
                series_is_nan(association_df[EMPLOYEE_COL])
            )

            end_after_future_start = (
                (association_df[ASSOCIATION_END] > next_row_df[ASSOCIATION_START]) |
                series_is_nan(association_df[ASSOCIATION_END])
            )

            # If same as future column and end_date after the next start
            # Then update the end date
            same_future = (
                same_future_employee & same_future_plate
            )
            association_df.loc[
                same_future & end_after_future_start,
                ASSOCIATION_END,
            ] = next_row_df.loc[
                same_future & end_after_future_start,
                ASSOCIATION_END,
            ]

            # Change start_date when same car but different employee
            update_mask = (
                same_previous_plate &
                ~same_previous_employee &
                start_before_previous_end
            )
            association_df.loc[update_mask, ASSOCIATION_START] = previous_row_df.loc[
                update_mask,
                ASSOCIATION_END,
            ]
            errors_vec = (
                same_previous_plate &
                (association_df[ASSOCIATION_START] < previous_row_df[ASSOCIATION_END])
            )

            errors = errors_vec.any()
            i += 1

        return association_df.drop_duplicates(
            subset=ASSOCIATION_COLS + [ASSOCIATION_START, ASSOCIATION_END]
        )

    @staticmethod
    def check_dates(association_df: pd.DataFrame) -> None:
        """ Ensure that start and end dates are consistent within a DataFrame

        :param association_df: DataFrame with association data

        :raises ValueError: if there are inconsistent start / end dates
        """
        unique_associations = association_df.loc[
            pd.notna(association_df[ASSOCIATION_START]),
            [
                PLATE_COL,
                EMPLOYEE_COL,
                ASSOCIATION_START,
                ASSOCIATION_END,
            ],
        ].drop_duplicates()

        # Validate with Quartus for EMPLOYEES with multiple cars
        unique_associations = unique_associations.sort_values(
            by=[PLATE_COL, ASSOCIATION_START, ASSOCIATION_END],
            ascending=True,
        )

        # Check if start_date when previous end_date priority is greater
        unique_associations['previous_end_date'] = unique_associations.groupby(
            PLATE_COL
        ).shift()[ASSOCIATION_END].fillna(
            unique_associations[ASSOCIATION_START]
        )  # When no previous, consider True
        dates_aligned = (
            unique_associations[ASSOCIATION_START] >=
            unique_associations['previous_end_date']
        ) | series_is_nan(unique_associations[ASSOCIATION_START])

        # Raise error if erroneous records
        incorrect_values = unique_associations.loc[
            ~dates_aligned,
            PLATE_COL
        ].unique()
        if len(incorrect_values):
            raise ValueError(
                f'There are {len(incorrect_values)} start_date / previous '
                f'end date incoherence in the data for col '
                f'{PLATE_COL}: {incorrect_values}'
            )

        # Check if end_date when next start priority is greater
        unique_associations['next_start_date'] = unique_associations.groupby(
            PLATE_COL
        ).shift(-1)[ASSOCIATION_START].fillna(
            unique_associations[ASSOCIATION_END]
        )  # When no previous, consider True

        # If no association_start available no correct order available.
        dates_aligned = (
            unique_associations[ASSOCIATION_END] <=
            unique_associations['next_start_date']
        ) | series_is_nan(unique_associations[ASSOCIATION_END])

        # Raise if erroneous records
        incorrect_values = unique_associations.loc[
            ~dates_aligned,
            PLATE_COL
        ].unique()
        if len(incorrect_values):
            raise ValueError(
                f'There are {len(incorrect_values)} end_date / next start'
                f' date incoherence in the data given plate_number:'
                f' {incorrect_values}'
            )

    @staticmethod
    def get_rent_dates(
        df: pd.DataFrame,
    ) -> pd.DataFrame:
        """ Produce a Series with the required column values, if available

        :param df: pandas DataFrame with some of the columns listed in opt_cols
        :param opt_cols: list of str column names to build the series from;
            we first attempt with the first column name, and fill in with the
            following if column not existant or nullable.

        :raises ValueError: if none of the passed opt_cols are available in
            the dataFrame

        :returns: Series of the requested values, consolidated
        """
        if ExpensesModel.billing_start_date.name in df.columns:
            df['temp_rent_start'] = df[ExpensesModel.billing_start_date.name]
            df['temp_rent_start'] = df['temp_rent_start'].fillna(
                df[ExpensesModel.billing_date.name].dt.to_period('M').dt.to_timestamp()
            )
        else:
            df['temp_rent_start'] = (
                df[ExpensesModel.billing_date.name].dt.to_period('M').dt.to_timestamp()
            )

        if ExpensesModel.billing_start_date.name in df.columns:
            df['temp_rent_end'] = df[ExpensesModel.billing_end_date.name]
            df['temp_rent_end'] = df['temp_rent_end'].fillna(
                df[ExpensesModel.billing_date.name] + pd.offsets.MonthEnd(0)
            )
        else:
            df['temp_rent_end'] = (
                df[ExpensesModel.billing_date.name] + pd.offsets.MonthEnd(0)
            )

        return df


if __name__ == "__main__":
    logger = gen_logger('associations_table')
    organization_name = 'Quartus'
    root_folder = '/home/matthieuglotz/Documents/Data/'
    organization_folder = os.path.join(
        root_folder,
        organization_name,
    )
    connector_data = ConnectorData(
        root_folder=root_folder,
        organization_name=organization_name,
    )
    association_table = VehicleAssociationsInputTable()
    association_df = association_table.get(
        connector_data=connector_data,
        logger=logger,
    )
    association_table.check_columns(
        data_df=association_df,
        employees=EmployeesInputTable().get(
            connector_data=connector_data,
            logger=logger,
        ),
        vehicles=VehiclesInputTable().get(
            connector_data=connector_data,
            logger=logger,
        ),
        logger=logger,
    )
    association_df.to_csv(
        os.path.join(
            organization_folder,
            'webapp_tables',
            f'{association_table.name}_table.csv',
        ),
        index=False,
        sep=';',
    )
