"""
Script and logic to upload an input table information to db
"""
import typing
import argparse
import os
import logging

import pandas as pd
from sqlalchemy import select
from sqlalchemy.engine import Engine
from sqlalchemy.orm.session import Session
from sqlalchemy.ext.declarative import DeclarativeMeta

from connectors.full_data import ConnectorData
from data_models import (
    VehiclesModel, CollaboratorsModel
)
from input_tables.table_utils import InputTable
from input_tables.accident_table import AccidentsInputTable
from input_tables.employees_table import EmployeesInputTable
from input_tables.expense_claims import ExpenseClaimsInputTable
from input_tables.expense_table import ExpensesInputTable
from input_tables.hotels_table import HotelsInputTable
from input_tables.mileage_table import MileagesInputTable
from input_tables.rental_cars import RentalCarsInputTable
from input_tables.taxes_table import TaxesInputTable
from input_tables.train_plane import TravelInputTable
from input_tables.vehicle_associations import VehicleAssociationsInputTable
from input_tables.vehicles_table import VehiclesInputTable
from utils.db import session_scope, get_organization_id
from utils.type import convert_string
from utils.logging import gen_logger
from utils.uploads import fetch_collaborator_ids, fetch_vehicle_ids

arg_dict = {
    AccidentsInputTable().name: AccidentsInputTable(),
    EmployeesInputTable().name: EmployeesInputTable(),
    ExpenseClaimsInputTable().name: ExpenseClaimsInputTable(),
    ExpensesInputTable().name: ExpensesInputTable(),
    HotelsInputTable().name: HotelsInputTable(),
    MileagesInputTable().name: MileagesInputTable(),
    RentalCarsInputTable().name: RentalCarsInputTable(),
    TaxesInputTable().name: TaxesInputTable(),
    TravelInputTable().name: TravelInputTable(),
    VehicleAssociationsInputTable().name: VehicleAssociationsInputTable(),
    VehiclesInputTable().name: VehiclesInputTable(),
}


def main(
    input_table: InputTable,
    connector_data: ConnectorData,
    logger: logging.Logger,
    db_username: typing.Optional[str] = None,
    db_password: typing.Optional[str] = None,
    db_host: typing.Optional[str] = None,
    db_port: typing.Optional[str] = None,
    db_name: typing.Optional[str] = None,
    fetch_params_dict: typing.Optional[dict] = None,
) -> None:
    """ Runs the insertion operation. First fetch the connector data,
    then filters the row already in database, lastly inserts the remainder.

    :param input_table: InputTable being inserted into db
    :param connector_data: ConnectorData object collecting all connector
        datasets for this organization
    :param table_func: function collecting the table data from the ConnectorData
    :param logger: logger
    :param fetch_params_dict: optional params to override the
        input_table_config
    """
    organization_id = get_organization_id(connector_data.organization_name)
    data_df = input_table.get(
        connector_data=connector_data,
        logger=logger,
        fetch_params_dict=fetch_params_dict,
    )
    logger.info(
        'Fetched %d rows from connectors for table %s',
        len(data_df),
        input_table.name,
    )

    with session_scope(
        db_username=db_username,
        db_password=db_password,
        db_host=db_host,
        db_port=db_port,
        db_name=db_name,
    ) as session:
        engine = session.get_bind()
        filtered_df = filter_duplicates(
            data_df=data_df,
            input_table=input_table,
            engine=engine,
            organization_id=organization_id,
        )
        logger.info(
            'After deduplication only %d rows remain. '
            'Attemping to insert into db',
            len(filtered_df),
        )
        insert_to_db(
            input_table=input_table,
            filtered_df=filtered_df,
            organization_id=organization_id,
            session=session,
            logger=logger,
        )
        logger.info(
            'Successfully inserted %d rows into db',
            len(filtered_df)
        )


def filter_duplicates(
    data_df: pd.DataFrame,
    input_table: InputTable,
    engine: Engine,
    organization_id: str,
) -> pd.DataFrame:
    """ Filter duplicates

    :param data_df: DataFrame containing the raw connector data, some of which
    may be already in database
    :param input_table: Input table this dataframe corresponds to
    :param engine: SQLAlchemy engine connected to the target db
    :param organization_id: organization uuid

    :returns: dataframe with only the rows not already contained in db
    """

    start_date, end_date = None, None
    if input_table.date_col_name:
        start_date = data_df[input_table.date_col_name].min()
        end_date = data_df[input_table.date_col_name].max()

    db_df = fetch_db_data(
        input_table=input_table,
        engine=engine,
        organization_id=organization_id,
        start_date=start_date,
        end_date=end_date,
    )

    merge_cols = []
    for col_name in db_df.columns:
        if pd.api.types.is_numeric_dtype(db_df[col_name].dtype):
            db_df[col_name] = convert_string(db_df[col_name].round(2))
            db_df.rename(
                {col_name: '_temp_' + col_name},
                axis=1,
                inplace=True,
            )

        if col_name == VehiclesModel.vehicle_id.name:
            data_df = fetch_vehicle_ids(
                vehicle_df=data_df,
                organization_id=organization_id,
                engine=engine,
            )
            merge_cols.append(col_name)
            continue

        if col_name == 'collaborator_id':
            data_df = fetch_collaborator_ids(
                collab_df=data_df,
                organization_id=organization_id,
                engine=engine,
            )
            merge_cols.append(col_name)
            continue

        if pd.api.types.is_numeric_dtype(data_df[col_name].dtype):
            data_df['_temp_' + col_name] = convert_string(
                data_df[col_name].round(2)
            )
            merge_cols.append('_temp_' + col_name)
        else:
            merge_cols.append(col_name)

    data_df = data_df.merge(
        how='left',
        right=db_df,
        on=merge_cols,
        indicator='_temp_indicator',
    )

    return data_df.loc[
        data_df['_temp_indicator'] == 'left_only',
        [col for col in data_df.columns if not col.startswith('_temp_')]
    ]


def insert_to_db(
    input_table: InputTable,
    filtered_df: pd.DataFrame,
    organization_id: str,
    session: Session,
    logger: logging.Logger,
) -> None:
    """ Inserts filtered, deduplicated data into db.

    :param input_table: InputTable whose data is to be inserted
    :param filtered_df: pandas DataFrame containing the data to load
    :param organization_id: uuid of the organization
    :param session: SQLAlchemy session to query the data from
    :param logger: logger

    :returns: None but inserts data in db
    """
    try:
        input_table.to_sql(
            data_df=filtered_df,
            organization_id=organization_id,
            session=session,
            logger=logger,
        )
    except Exception:
        session.rollback()
        raise


def fetch_db_data(
    input_table: InputTable,
    engine: Engine,
    organization_id: typing.Optional[str] = None,
    start_date: typing.Optional[pd.Timestamp] = None,
    end_date: typing.Optional[pd.Timestamp] = None,
) -> pd.DataFrame:
    """ Fetch database data, with all the rows at risk of duplication from
    the insert.

    :param input_table: InputTable whose data is being inserted into db
    :param engine: SQLAlchemy engine to that db
    :param organization_id: organization uuid
    """
    # TODO: Handle the special cases of associations / date_to date_from cols
    select_cols = [
        getattr(input_table.sql_mapping, column_name)
        for column_name in get_id_cols(input_table)
    ]
    where_conds = []
    if 'organization_id' in get_mapping_col_names(input_table.sql_mapping):
        where_conds.append(
            input_table.sql_mapping.organization_id == organization_id
        )
    if start_date is not None and end_date is not None:
        where_conds.append(
            getattr(
                input_table.sql_mapping,
                input_table.date_col_name,
            ).between(
                start_date,
                end_date,
            )
        )

    return pd.read_sql(
        sql=select(
            *select_cols
        ).select_from(input_table.sql_mapping).where(
            *where_conds
        ),
        con=engine,
    )


def parse_args() -> argparse.Namespace:
    """ Parse execution params

    :returns: execution params as attributes of a namespace
    """
    parser = argparse.ArgumentParser()
    parser.add_argument(
        '-o',
        '--org-name',
        type=str,
        help='The name of the organization',
    )
    parser.add_argument(
        '-t',
        '--table-names',
        type=str,
        nargs='+',
        help='List of table names',
        default=['*'],
    )
    parser.add_argument(
        '-f',
        '--folder',
        type=str,
        help='Path to the data folder storing all organization data',
        default='/home/matthieuglotz/Documents/Data/',
    )
    args = parser.parse_args()

    if not (
        set(args.table_names).issubset(arg_dict.keys())
        or '*' in args.table_names
    ):
        raise ValueError(
            f'The only accepted values for table_names are * or '
            f'{arg_dict.keys()}'
        )

    if not os.path.isdir(args.folder):
        raise FileNotFoundError(
            f'The passed folder {args.folder} does not exists',
        )

    return args


def get_id_cols(input_table: InputTable) -> typing.List[str]:
    """ Get id column names, i.e. the name of the columns which will be used
    to uniquely identify entries on this table

    :param input_table: InputTable to insert data from

    :returns: list of column names to be used as ids
    """
    conversion_dict = {}
    if input_table != EmployeesInputTable().name:
        conversion_dict = {
            CollaboratorsModel.employee_id.name: 'collaborator_id',
        }
    if input_table != VehiclesInputTable().name:
        conversion_dict.update(
            {VehiclesModel.plate_number.name: VehiclesModel.vehicle_id.name}
        )
    return [
        conversion_dict.get(col.name, col.name)
        for col in input_table.columns if col.is_id
    ]


def get_mapping_col_names(sql_mapping: DeclarativeMeta) -> typing.List[str]:
    """ Get the str column name of the sql_mapping

    :param sql_mapping: SQLAlchemy declarative table mapping

    :returns: list of mapping column names
    """
    return [col.name for col in sql_mapping.__table__.columns]


if __name__ == '__main__':
    args = parse_args()
    logger = gen_logger('insert to db')
    logger.info(
        'Starting to collect connector data for organization %s',
        args.org_name,
    )
    connector_data = ConnectorData(
        root_folder=args.folder,
        organization_name=args.org_name,
    )

    tables_to_fetch = arg_dict.keys() if '*' in args.table_names else args.table_names
    for table in tables_to_fetch:
        input_table = arg_dict[table]
        logger.info(
            'Starting data fetch and insert process for table %s',
            input_table.name,
        )
        main(
            input_table=input_table,
            connector_data=connector_data,
            logger=logger,
        )
